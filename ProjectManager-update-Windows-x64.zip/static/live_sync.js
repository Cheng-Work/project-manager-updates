'use strict';

const liveVersionMetadata=document.querySelector('meta[name="pm-ui-version"]')?.content?.trim()||'';
const liveReleaseMetadata=document.querySelector('meta[name="pm-release"]')?.content?.trim()||'';
const liveVersionState={initial:/^[a-f0-9]{64}$/i.test(liveVersionMetadata)?liveVersionMetadata.toLowerCase():'',release:liveReleaseMetadata,pending:null,request:null,ready:false,reloaded:false};

function liveVersionHasDrafts(){
  if(typeof hasUnsavedChanges!=='function')return true;
  try{return !!hasUnsavedChanges();}catch{return true;}
}

function showLiveVersionNotice(message=''){
  const notice=document.getElementById('liveVersionNotice');
  if(!notice||!liveVersionState.pending)return;
  const dialogs=[...document.querySelectorAll('dialog[open]')],destination=document.activeElement?.closest('dialog[open]')||dialogs[dialogs.length-1]||document.body;
  if(notice.parentElement!==destination)destination.appendChild(notice);
  document.getElementById('liveVersionMessage').textContent=message||(liveVersionState.ready?'有新版可使用。請先儲存或取消編輯，完成後會自動載入。':'偵測到新版。請先儲存目前內容，連線準備好後會載入。');
  document.getElementById('liveVersionReload').disabled=!liveVersionState.ready;
  notice.hidden=false;
}

function clearLiveVersionNotice(){
  liveVersionState.pending=null;
  const notice=document.getElementById('liveVersionNotice');if(notice)notice.hidden=true;
}

function maybeReloadLiveVersion(){
  if(!liveVersionState.initial||!liveVersionState.pending||!liveVersionState.ready||liveVersionState.reloaded||document.hidden)return false;
  if(liveVersionHasDrafts()){showLiveVersionNotice();return false;}
  liveVersionState.reloaded=true;
  try{if(typeof prepareLiveReload==='function')prepareLiveReload();}catch{/* A browser storage restriction must not cause a reload loop. */}
  location.reload();return true;
}

async function checkLiveVersion(){
  if(!liveVersionState.initial||liveVersionState.reloaded||document.hidden)return false;
  if(liveVersionState.request)return liveVersionState.request;
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),4500);
  const pending=(async()=>{
    try{
      const response=await fetch('/api/health',{cache:'no-store',credentials:'same-origin',signal:controller.signal});
      if(!response.ok)throw new Error('Health check unavailable');
      const health=await response.json(),version=typeof health.ui_version==='string'?health.ui_version.toLowerCase():'';
      liveVersionState.ready=health.accepting_requests===true;
      if(!/^[a-f0-9]{64}$/.test(version)){liveVersionState.ready=false;return false;}
      if(version===liveVersionState.initial&&(!liveVersionState.release||health.release===liveVersionState.release)){clearLiveVersionNotice();return false;}
      if(liveVersionState.ready)liveVersionState.pending=version;
      if(!liveVersionState.ready){if(liveVersionState.pending)showLiveVersionNotice();return false;}
      return maybeReloadLiveVersion();
    }catch{
      liveVersionState.ready=false;if(liveVersionState.pending)showLiveVersionNotice();return false;
    }finally{
      clearTimeout(timeout);if(liveVersionState.request===pending)liveVersionState.request=null;
    }
  })();
  liveVersionState.request=pending;return pending;
}

document.getElementById('liveVersionReload')?.addEventListener('click',async()=>{
  await checkLiveVersion();
  if(liveVersionState.pending&&!liveVersionState.reloaded&&liveVersionHasDrafts())showLiveVersionNotice('仍有未儲存的內容，請先儲存或取消編輯，再載入新版。');
});
window.addEventListener('focus',checkLiveVersion);
window.addEventListener('online',checkLiveVersion);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkLiveVersion();});
setInterval(checkLiveVersion,3000);
checkLiveVersion();
