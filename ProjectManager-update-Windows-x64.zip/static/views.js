'use strict';

const workspaceViews={matching:[],draggingId:null,queued:false,boardKey:'',timelineKey:'',timelineStart:null,userId:null,busy:new Set()};
const workspaceViewNames=['list','board','timeline'];
const boardStatuses=['not_started','in_progress','pending_review','on_hold','completed'];
const TIMELINE_DAY_MS=86400000,TIMELINE_DAYS=14;

function workspaceViewItems(items){
  const seen=new Set();
  return (items||[]).map(value=>({item:value.item||value,context:!!(value.context||value.contextOnly||value.context_only||value.item?.context_only)})).filter(value=>value.item?.level==='task'&&!seen.has(value.item.id)&&seen.add(value.item.id));
}

function applyWorkspaceView(){
  if(!workspaceViewNames.includes(state.view))state.view='list';
  for(const name of workspaceViewNames){
    const active=state.view===name,tab=document.querySelector(`[data-workspace-view="${name}"]`);
    tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;
    $(name+'View').hidden=!active;
  }
  $('collapseAll').hidden=state.view!=='list';$('expandAll').hidden=state.view!=='list';
  $('workspaceViewDescription').textContent=state.view==='list'?'專案、內容與任務，一目了然':state.view==='board'?'依任務狀態整理，拖曳卡片即可調整':'今天至完成日；10 天以上綠色，2 天內紅色';
}

function setWorkspaceView(view){
  if(!workspaceViewNames.includes(view))return;
  endWorkspaceDrag(false);state.view=view;
  try{localStorage.setItem('pm-workspace-view',view);}catch{}
  applyWorkspaceView();render();
}

function resetWorkspaceViews(){
  endWorkspaceDrag(false);workspaceViews.matching=[];workspaceViews.boardKey='';workspaceViews.timelineKey='';workspaceViews.timelineStart=null;workspaceViews.queued=false;workspaceViews.busy.clear();workspaceViews.userId=null;
  $('boardView').replaceChildren();$('timelineCanvas').replaceChildren();$('timelineUnscheduled').replaceChildren();
}
function resetViews(){resetWorkspaceViews();}

function renderViews(matchingItems){
  const userId=state.user?.id??null;
  if(workspaceViews.userId!==userId){resetWorkspaceViews();workspaceViews.userId=userId;}
  workspaceViews.matching=workspaceViewItems(matchingItems);
  applyWorkspaceView();
  if(workspaceViews.draggingId!==null){workspaceViews.queued=true;return;}
  if(state.view==='board')renderWorkspaceBoard();
  if(state.view==='timeline')renderWorkspaceTimeline();
}

function workProjectName(item){
  const content=itemById(item.parent_id),project=content?.level==='work'?itemById(content.parent_id):content?.level==='project'?content:null;
  return (project?.name||'未指定專案')+' / '+(content?.level==='work'?content.name:'未指定內容');
}

function workCanMove(entry){
  return !entry.context&&!workspaceViews.busy.has(entry.item.id)&&canChangeStatus(entry.item);
}

function workCard(entry){
  const item=entry.item,movable=workCanMove(entry);
  const options=allowedStatuses(item).map(value=>`<option value="${value}"${value===item.status?' selected':''}>${labels[value]}</option>`).join('');
  return `<article class="work-card${entry.context?' context-work':''}${workspaceViews.busy.has(item.id)?' work-busy':''}" data-work-card="${item.id}" draggable="${movable}"><p class="work-card-project">${esc(workProjectName(item))}${entry.context?'<span>相關任務</span>':''}</p><button type="button" class="work-card-title" data-work-details="${item.id}" aria-controls="detailsPanel">${esc(item.name)}</button><div class="work-card-meta"><span>${esc(ownerName(item.owner_id)||'未指派')}</span><span class="priority ${item.priority}">${labels[item.priority]}</span></div><div class="work-card-footer"><span class="work-card-date${overdue(item)?' overdue':''}">${icon('calendar')}${item.due_date?esc(item.due_date.replaceAll('-','/')):'未設定日期'}</span>${movable?`<select class="work-card-status" data-work-status="${item.id}" aria-label="${esc(item.name)}的狀態">${options}</select>`:`<span class="work-context-note">${entry.context?'僅供查看':labels[item.status]}</span>`}</div></article>`;
}

function renderWorkspaceBoard(){
  const entries=workspaceViews.matching;
  const key=JSON.stringify([state.user?.role,state.today,entries.map(entry=>[entry.item,entry.context,workCanMove(entry),workProjectName(entry.item),ownerName(entry.item.owner_id)])]);
  if(key===workspaceViews.boardKey)return;
  workspaceViews.boardKey=key;
  $('boardView').innerHTML=`<div class="work-board">${boardStatuses.map(status=>{
    const column=entries.filter(entry=>entry.item.status===status);
    return `<section class="work-board-column ${status}" data-work-column="${status}" aria-label="${labels[status]}"><header><span class="board-state-marker"></span><h3>${labels[status]}</h3><span class="board-column-count">${column.length}</span></header><div class="work-board-cards">${column.map(workCard).join('')||'<p class="board-empty">沒有符合篩選的任務</p>'}</div></section>`;
  }).join('')}</div>`;
}

function timelineDay(value){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))return null;
  const [year,month,day]=value.split('-').map(Number);return Math.floor(Date.UTC(year,month-1,day)/TIMELINE_DAY_MS);
}
function timelineTodayDay(){
  if(state.today)return timelineDay(state.today);
  const now=new Date();return Math.floor(Date.UTC(now.getFullYear(),now.getMonth(),now.getDate())/TIMELINE_DAY_MS);
}
function timelineMonday(day){return day-((new Date(day*TIMELINE_DAY_MS).getUTCDay()+6)%7);}
function timelineDate(day){return new Date(day*TIMELINE_DAY_MS).toISOString().slice(0,10);}
function timelineShortDate(day){return timelineDate(day).slice(5).replace('-','/');}

function timelineRemainingLine(item,start,today){
  const due=timelineDay(item.due_date),past=due<today,done=item.status==='completed',over=past&&!done,end=start+TIMELINE_DAYS-1;
  const first=Math.max(today,start),last=Math.min(due,end),remaining=Math.max(2,Math.min(10,due-today));
  const title=`${item.name}：${item.due_date}（${done?'已完成':over?'已逾期 '+(today-due)+' 天':due===today?'今天到期':'剩餘 '+(due-today)+' 天'}）`;
  const line=due>today&&first<=last?Array.from({length:last-first+1},(_,index)=>{
    const day=first+index,offset=day-start;
    return `<button type="button" tabindex="-1" class="timeline-remaining-line timeline-col-${offset} remaining-${remaining}${day===today?' line-start':''}${day===due?' line-end':''}${done?' completed':''}" data-work-details="${item.id}" title="${esc(title)}" aria-label="${esc(title)}"><span></span></button>`;
  }).join(''):'';
  const marker=due>=start&&due<=end?`<button type="button" class="timeline-due-node timeline-col-${due-start} remaining-${remaining}${done?' completed':over?' overdue':''}" data-work-details="${item.id}" title="${esc(title)}" aria-label="${esc(title)}"><span></span></button>`:'';
  if(line||marker)return line+marker;
  const position=due<start?'← 在本區間之前':'在本區間之後 →';
  return `<span class="timeline-outside ${due<start?'before':'after'}">${esc(item.due_date.replaceAll('-','/'))} ${position}</span>`;
}

function renderWorkspaceTimeline(){
  if(workspaceViews.timelineStart===null)workspaceViews.timelineStart=timelineMonday(timelineTodayDay());
  const start=workspaceViews.timelineStart,end=start+TIMELINE_DAYS-1,today=timelineTodayDay();
  const entries=workspaceViews.matching,scheduled=entries.filter(entry=>timelineDay(entry.item.due_date)!==null),unscheduled=entries.filter(entry=>timelineDay(entry.item.due_date)===null);
  const key=JSON.stringify([start,today,entries.map(entry=>[entry.item,entry.context,workProjectName(entry.item),ownerName(entry.item.owner_id)])]);
  if(key===workspaceViews.timelineKey)return;
  workspaceViews.timelineKey=key;
  $('timelineRange').textContent=timelineDate(start).replaceAll('-','/')+' — '+timelineDate(end).replaceAll('-','/');
  const header=`<div class="timeline-grid timeline-ruler"><span class="timeline-name-heading">任務 / 到期日</span>${Array.from({length:TIMELINE_DAYS},(_,index)=>{
    const day=start+index,weekDay=new Date(day*TIMELINE_DAY_MS).getUTCDay();
    return `<div class="timeline-day${day===today?' is-today':''}${weekDay===0||weekDay===6?' weekend':''}"><span>${timelineShortDate(day)}</span><small>${'日一二三四五六'[weekDay]}</small></div>`;
  }).join('')}</div>`;
  const rows=scheduled.map(entry=>{
    const item=entry.item,due=timelineDay(item.due_date),remaining=due-today;
    return `<div class="timeline-grid timeline-work-row"><button type="button" class="timeline-work-name" data-work-details="${item.id}" aria-controls="detailsPanel"><strong>${esc(item.name)}</strong><span>${esc(workProjectName(item))} · ${esc(ownerName(item.owner_id)||'未指派')}</span><small>${esc(item.due_date.replaceAll('-','/'))} · ${item.status==='completed'?'已完成':remaining<0?'已逾期 '+(-remaining)+' 天':remaining===0?'今天到期':'剩餘 '+remaining+' 天'}${entry.context?' · 相關任務':''}</small></button>${Array.from({length:TIMELINE_DAYS},(_,index)=>`<span class="timeline-grid-cell timeline-col-${index}${start+index===today?' is-today':''}" aria-hidden="true"></span>`).join('')}${timelineRemainingLine(item,start,today)}</div>`;
  }).join('');
  $('timelineCanvas').innerHTML=header+(rows||'<p class="timeline-empty">此篩選下沒有已設定日期的任務。</p>');
  $('timelineUnscheduledSection').hidden=!unscheduled.length;
  $('timelineUnscheduled').innerHTML=unscheduled.map(entry=>`<button type="button" class="unscheduled-work" data-work-details="${entry.item.id}"><strong>${esc(entry.item.name)}</strong><span>${esc(workProjectName(entry.item))} · ${esc(ownerName(entry.item.owner_id)||'未指派')}</span><span class="status-label ${entry.item.status}">${labels[entry.item.status]}</span></button>`).join('');
}

function moveWorkspaceTimeline(weeks){
  if(workspaceViews.timelineStart===null)workspaceViews.timelineStart=timelineMonday(timelineTodayDay());
  workspaceViews.timelineStart+=weeks*7;workspaceViews.timelineKey='';renderWorkspaceTimeline();
}

function endWorkspaceDrag(flush=true){
  workspaceViews.draggingId=null;
  for(const surface of $('boardView').querySelectorAll('.dragging,.drop-allowed')){surface.classList.remove('dragging');surface.classList.remove('drop-allowed');}
  if(flush&&workspaceViews.queued){workspaceViews.queued=false;workspaceViews.boardKey='';renderWorkspaceBoard();}
}

async function changeWorkCardStatus(id,status){
  const generation=state.authGeneration;
  const entry=workspaceViews.matching.find(value=>value.item.id===Number(id));
  if(!entry||entry.context||workspaceViews.busy.has(entry.item.id))return;
  const current=itemById(entry.item.id)||entry.item;
  if(!canChangeStatus(current)||!allowedStatuses(current).includes(status)||current.status===status)return;
  workspaceViews.busy.add(current.id);workspaceViews.boardKey='';renderWorkspaceBoard();
  let accepted=true;
  try{if(await saveWorkStatus(current,status)===false)accepted=false;}catch(error){if(generation===state.authGeneration)toast(error.message||'狀態更新失敗，請稍後重試。',true);}
  finally{if(generation===state.authGeneration){workspaceViews.busy.delete(current.id);workspaceViews.boardKey='';if(accepted&&state.user)render();}}
}

for(const tab of document.querySelectorAll('[data-workspace-view]')){
  tab.addEventListener('click',()=>setWorkspaceView(tab.dataset.workspaceView));
  tab.addEventListener('keydown',event=>{
    const current=workspaceViewNames.indexOf(tab.dataset.workspaceView);
    let next=event.key==='ArrowRight'?(current+1)%3:event.key==='ArrowLeft'?(current+2)%3:event.key==='Home'?0:event.key==='End'?2:null;
    if(next===null)return;event.preventDefault();setWorkspaceView(workspaceViewNames[next]);document.querySelector(`[data-workspace-view="${workspaceViewNames[next]}"]`).focus();
  });
}
for(const container of [$('boardView'),$('timelineView')])container.addEventListener('click',event=>{
  if(workspaceViews.draggingId!==null)return;
  const button=event.target.closest('[data-work-details]');if(!button)return;
  const item=itemById(button.dataset.workDetails);if(item)openDetails(item,button);
});
$('boardView').addEventListener('change',event=>{const select=event.target.closest('[data-work-status]');if(select)changeWorkCardStatus(select.dataset.workStatus,select.value);});
$('boardView').addEventListener('dragstart',event=>{
  const card=event.target.closest('[data-work-card]'),entry=card&&workspaceViews.matching.find(value=>value.item.id===Number(card.dataset.workCard));
  if(!entry||!workCanMove(entry)||event.target.closest('select')){event.preventDefault();return;}
  workspaceViews.draggingId=entry.item.id;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',String(entry.item.id));card.classList.add('dragging');
});
$('boardView').addEventListener('dragover',event=>{
  const column=event.target.closest('[data-work-column]'),item=itemById(workspaceViews.draggingId);
  if(!column||!item||!canChangeStatus(item)||!allowedStatuses(item).includes(column.dataset.workColumn))return;
  event.preventDefault();event.dataTransfer.dropEffect='move';
  for(const surface of $('boardView').querySelectorAll('.drop-allowed'))if(surface!==column)surface.classList.remove('drop-allowed');
  column.classList.add('drop-allowed');
});
$('boardView').addEventListener('dragleave',event=>{const column=event.target.closest('[data-work-column]');if(column&&!column.contains(event.relatedTarget))column.classList.remove('drop-allowed');});
$('boardView').addEventListener('drop',async event=>{
  const column=event.target.closest('[data-work-column]'),id=workspaceViews.draggingId;
  if(!column||id===null)return;event.preventDefault();const status=column.dataset.workColumn;endWorkspaceDrag(false);await changeWorkCardStatus(id,status);
});
$('boardView').addEventListener('dragend',()=>endWorkspaceDrag());
$('timelinePrevious').addEventListener('click',()=>moveWorkspaceTimeline(-1));
$('timelineNext').addEventListener('click',()=>moveWorkspaceTimeline(1));
$('timelineToday').addEventListener('click',()=>{workspaceViews.timelineStart=timelineMonday(timelineTodayDay());workspaceViews.timelineKey='';renderWorkspaceTimeline();});
try{const preference=localStorage.getItem('pm-workspace-view');if(workspaceViewNames.includes(preference))state.view=preference;}catch{}
applyWorkspaceView();
