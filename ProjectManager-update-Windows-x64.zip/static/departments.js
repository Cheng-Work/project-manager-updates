'use strict';

const departmentDrafts=new Map(),departmentSaves=new Set();
let departmentRowsKey='',registrationDepartmentsRequest=null,registrationDepartmentsGeneration=null,departmentSessionGeneration=state.authGeneration;
const departmentId=value=>value!==''&&value!==null&&value!==undefined&&Number.isInteger(Number(value))&&Number(value)>0?Number(value):null;
const departmentList=()=>Array.isArray(state.departments)?state.departments:[];
const departmentName=id=>departmentList().find(department=>department.id===departmentId(id))?.name||'未指定部門';

function fillDepartmentSelect(select,placeholder,departments=departmentList(),selected=select.value){
  const value=selected===null||selected===undefined?'':String(selected);
  const markup=`<option value="">${esc(placeholder)}</option>`+departments.map(department=>`<option value="${department.id}">${esc(department.name)}</option>`).join('');
  if(select.innerHTML!==markup)select.innerHTML=markup;
  select.value=departments.some(department=>String(department.id)===value)?value:'';
}

function selectedDepartmentGrants(){
  return [...$('accountVisibleDepartments').querySelectorAll('input:checked')].map(input=>departmentId(input.value)).filter(id=>id!==null);
}
function selectedEditableDepartmentGrants(){
  return [...$('accountEditableDepartments').querySelectorAll('input:checked')].map(input=>departmentId(input.value)).filter(id=>id!==null);
}

function renderAccountDepartmentGrants(selected=selectedDepartmentGrants(),editable=selectedEditableDepartmentGrants()){
  const role=$('accountRole').value,own=departmentId($('accountDepartment').value),editGrants=new Set(editable.map(departmentId).filter(id=>id!==own)),grants=new Set([...selected.map(departmentId),...editGrants]);
  $('accountVisibleDepartmentsField').hidden=role!=='supervisor';
  $('accountEditableDepartmentsField').hidden=role!=='supervisor';
  const choices=departmentList().filter(department=>department.id!==own);
  const markup=role==='supervisor'?choices.map(department=>`<label class="department-grant${editGrants.has(department.id)?' department-grant-required':''}"><input type="checkbox" value="${department.id}"${grants.has(department.id)?' checked':''}${editGrants.has(department.id)?' disabled':''}><span>${esc(department.name)}${editGrants.has(department.id)?'<small>可修改，已自動開啟查看</small>':''}</span></label>`).join(''):'';
  const editableMarkup=role==='supervisor'?choices.map(department=>`<label class="department-grant"><input type="checkbox" value="${department.id}"${editGrants.has(department.id)?' checked':''}><span>${esc(department.name)}</span></label>`).join(''):'';
  if($('accountVisibleDepartments').innerHTML!==markup)$('accountVisibleDepartments').innerHTML=markup;
  if($('accountEditableDepartments').innerHTML!==editableMarkup)$('accountEditableDepartments').innerHTML=editableMarkup;
}

function updateAccountDepartmentRules(clearGrants=false){
  const role=$('accountRole').value,select=$('accountDepartment'),selected=clearGrants?[]:selectedDepartmentGrants(),editable=clearGrants?[]:selectedEditableDepartmentGrants();
  select.disabled=role==='admin';select.required=role==='supervisor';
  if(role==='admin')select.value='';
  $('accountDepartmentHint').textContent=role==='admin'?'管理員可管理所有部門，不指定所屬部門。':role==='supervisor'?'主管必須指定一個本部門。':'一般使用者可選擇所屬部門。';
  renderAccountDepartmentGrants(role==='supervisor'?selected:[],role==='supervisor'?editable:[]);
}

function prepareAccountDepartments(user=null){
  fillDepartmentSelect($('accountDepartment'),'未指定部門',departmentList(),user?.department_id??null);
  updateAccountDepartmentRules(true);
  renderAccountDepartmentGrants($('accountRole').value==='supervisor'?user?.visible_department_ids||[]:[],$('accountRole').value==='supervisor'?user?.editable_department_ids||[]:[]);
}

function accountDepartmentPayload(){
  const role=$('accountRole').value,own=role==='admin'?null:departmentId($('accountDepartment').value);
  const editable=role==='supervisor'?selectedEditableDepartmentGrants().filter(id=>id!==own):[];
  return {department_id:own,visible_department_ids:role==='supervisor'?[...new Set([...selectedDepartmentGrants(),...editable])].filter(id=>id!==own):[],editable_department_ids:editable};
}

function effectiveParentDepartment(parent){
  const visited=new Set();let current=parent;
  while(current&&!visited.has(current.id)){
    visited.add(current.id);
    if(current.effective_department_id!==undefined&&current.effective_department_id!==null)return departmentId(current.effective_department_id);
    if(current.department_id!==undefined&&current.department_id!==null)return departmentId(current.department_id);
    current=(state.items||[]).find(item=>item.id===current.parent_id);
  }
  return null;
}

function itemDepartmentParent(parent=null){
  if(parent)return parent;
  const id=departmentId($('itemParent').value);
  return (state.items||[]).find(item=>item.id===id)||null;
}

function updateItemDepartmentOptions(selected=$('itemDepartment').value,parent=null){
  const select=$('itemDepartment'),actualParent=itemDepartmentParent(parent),parentDepartment=effectiveParentDepartment(actualParent),supervisor=state.user?.role==='supervisor',own=departmentId(state.user?.department_id);
  const editDepartments=new Set([own,...(state.user?.editable_department_ids||[]).map(departmentId)].filter(id=>id!==null));
  const options=supervisor?departmentList().filter(department=>editDepartments.has(department.id)):departmentList();
  const canInherit=!supervisor||!!actualParent&&editDepartments.has(parentDepartment);
  const placeholder=actualParent?'沿用父層'+(parentDepartment?'（'+departmentName(parentDepartment)+'）':'／未指定'):'未指定部門';
  fillDepartmentSelect(select,placeholder,options,selected);
  select.required=supervisor&&!canInherit;
  select.disabled=!!state.user&&state.user.role==='member';
  if(supervisor&&!canInherit&&!select.value)select.value=own===null?'':String(own);
  if(select.options?.[0])select.options[0].disabled=supervisor&&!canInherit;
  $('itemDepartmentHint').textContent=supervisor?'可指定本部門或授權可修改的部門；父層屬於可修改部門時，也可沿用父層。':'未指定時沿用父層部門；專案未指定則不歸屬任何部門。';
}

function prepareItemDepartment(item=null,parent=null){
  const actualParent=parent||(state.items||[]).find(value=>value.id===item?.parent_id)||null;
  updateItemDepartmentOptions(item?.department_id??'',actualParent);
}
function itemDepartmentValue(){return departmentId($('itemDepartment').value);}
function registrationDepartmentValue(){return departmentId($('registerDepartment').value);}

function renderDepartments(){
  if(departmentSessionGeneration!==state.authGeneration){
    departmentSessionGeneration=state.authGeneration;departmentDrafts.clear();departmentSaves.clear();departmentRowsKey='';$('newDepartmentName').value='';$('departmentFeedback').textContent='';$('addDepartment').disabled=false;
  }
  $('manageDepartments').hidden=state.user?.role!=='admin';
  if(state.user?.role!=='admin'&&$('departmentsDialog').open)$('departmentsDialog').close();
  fillDepartmentSelect($('registerDepartment'),'未指定部門');
  fillDepartmentSelect($('departmentFilter'),'全部部門');
  fillDepartmentSelect($('accountsDepartmentFilter'),'全部部門');
  const grants=selectedDepartmentGrants(),editable=selectedEditableDepartmentGrants();
  fillDepartmentSelect($('accountDepartment'),'未指定部門');
  updateAccountDepartmentRules();renderAccountDepartmentGrants(grants,editable);
  $('profileDepartment').value=state.user?.role==='admin'?'不指定（管理員）':departmentName(state.user?.department_id);
  if($('itemDialog').open)updateItemDepartmentOptions();
  if($('departmentsDialog').open)renderDepartmentRows();
}

function renderDepartmentRows(force=false){
  if(!force&&document.activeElement?.closest('[data-department-row] input'))return;
  const markup=departmentList().map(department=>{
    const draft=departmentDrafts.get(department.id),name=draft?.name??department.name,version=draft?.version??department.version,busy=departmentSaves.has(department.id);
    return `<div class="department-row" data-department-row="${department.id}"><div><label class="department-row-label" for="department-name-${department.id}">部門名稱</label><input id="department-name-${department.id}" data-department-name="${department.id}" data-version="${version}" value="${esc(name)}" maxlength="60" ${busy?'disabled':''}>${draft&&draft.version!==department.version?`<span class="field-hint department-conflict">目前名稱：${esc(department.name)}；請確認後再儲存。</span>`:''}</div><button type="button" class="secondary" data-save-department="${department.id}" ${busy?'disabled':''}>${busy?'儲存中…':'儲存'}</button></div>`;
  }).join('')||'<p class="department-empty">尚未建立部門。</p>';
  if(markup!==departmentRowsKey||force){$('departmentRows').innerHTML=markup;departmentRowsKey=markup;}
}

async function loadRegistrationDepartments(){
  if(state.user)return;
  const generation=state.authGeneration;
  if(registrationDepartmentsRequest&&registrationDepartmentsGeneration===generation)return registrationDepartmentsRequest;
  registrationDepartmentsGeneration=generation;
  const pending=(async()=>{
    try{
      const result=await api('/api/auth/departments');
      if(generation!==state.authGeneration||state.user)return;
      state.departments=result.departments;renderDepartments();$('registerDepartmentHint').textContent='部門可由管理員協助調整。';
    }catch{
      if(generation===state.authGeneration&&!state.user)$('registerDepartmentHint').textContent='暫時無法取得部門，可先不指定。';
    }finally{if(registrationDepartmentsRequest===pending)registrationDepartmentsRequest=null;}
  })();
  registrationDepartmentsRequest=pending;return pending;
}

$('accountRole').addEventListener('change',()=>updateAccountDepartmentRules(true));
$('accountDepartment').addEventListener('change',()=>updateAccountDepartmentRules());
$('accountVisibleDepartments').addEventListener('change',()=>renderAccountDepartmentGrants());
$('accountEditableDepartments').addEventListener('change',()=>renderAccountDepartmentGrants());
for(const id of ['itemParent','itemLevel'])$(id).addEventListener('change',()=>updateItemDepartmentOptions());
$('manageDepartments').addEventListener('click',async()=>{
  if(state.user?.role!=='admin')return;
  departmentDrafts.clear();departmentRowsKey='';$('departmentFeedback').textContent='';$('departmentsDialog').showModal();renderDepartmentRows(true);
  const generation=state.authGeneration;
  try{const result=await api('/api/departments');if(generation===state.authGeneration&&state.user?.role==='admin'){state.departments=result.departments;renderDepartments();}}
  catch(error){if(generation===state.authGeneration)$('departmentFeedback').textContent=error.message;}
});
$('closeDepartments').addEventListener('click',()=>$('departmentsDialog').close());
$('departmentForm').addEventListener('submit',async event=>{
  event.preventDefault();if(state.user?.role!=='admin'||!$('departmentForm').reportValidity())return;
  const draftName=$('newDepartmentName').value,name=draftName.trim(),generation=state.authGeneration;if(!name){$('departmentFeedback').textContent='請輸入部門名稱。';return;}
  $('addDepartment').disabled=true;$('departmentFeedback').textContent='';
  try{
    const department=await api('/api/departments',{method:'POST',body:JSON.stringify({name})});
    if(generation!==state.authGeneration)return;
    state.departments=departmentList().filter(value=>value.id!==department.id).concat(department);if($('newDepartmentName').value===draftName)$('newDepartmentName').value='';renderDepartments();saved('部門已新增');await loadState(true);
  }catch(error){if(generation===state.authGeneration)$('departmentFeedback').textContent=error.message;}
  finally{if(generation===state.authGeneration)$('addDepartment').disabled=false;}
});
$('departmentRows').addEventListener('input',event=>{
  const input=event.target.closest('[data-department-name]');if(!input)return;
  departmentDrafts.set(Number(input.dataset.departmentName),{name:input.value,version:Number(input.dataset.version)});
});
$('departmentRows').addEventListener('click',async event=>{
  const button=event.target.closest('[data-save-department]');if(!button||state.user?.role!=='admin')return;
  const id=Number(button.dataset.saveDepartment),department=departmentList().find(value=>value.id===id),input=$('departmentRows').querySelector(`[data-department-name="${id}"]`);
  if(!department||!input||departmentSaves.has(id))return;
  const name=input.value.trim(),draft=departmentDrafts.get(id),displayedVersion=Number(input.dataset.version),generation=state.authGeneration;
  if(!name){$('departmentFeedback').textContent='部門名稱不可空白。';return;}
  let version=displayedVersion;
  if(draft&&displayedVersion!==department.version){if(!confirm(`部門目前名稱為「${department.name}」，要改成「${name}」嗎？`))return;version=department.version;}
  departmentSaves.add(id);$('departmentFeedback').textContent='';renderDepartmentRows(true);
  try{
    const updated=await api('/api/departments/'+id,{method:'PATCH',body:JSON.stringify({name,version})});
    if(generation!==state.authGeneration)return;
    state.departments=departmentList().map(value=>value.id===id?updated:value);departmentDrafts.delete(id);renderDepartments();saved('部門名稱已更新');await loadState(true);
  }catch(error){if(generation===state.authGeneration)$('departmentFeedback').textContent=error.message;}
  finally{if(generation===state.authGeneration){departmentSaves.delete(id);renderDepartmentRows(true);}}
});
renderDepartments();
if(!state.user)loadRegistrationDepartments();
