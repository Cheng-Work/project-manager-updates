@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
"%~dp0ProjectManager.exe" open
if errorlevel 1 pause
