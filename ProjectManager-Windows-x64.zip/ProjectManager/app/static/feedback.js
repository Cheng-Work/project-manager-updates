'use strict';

const feedbackMailbox={session:null,role:null,items:[],selectedId:null,request:null,serial:0,sending:false,loaded:false,historyKey:null,previewKey:null,renderedId:null};
const feedbackSession=()=>state.user?state.authGeneration+':'+state.user.id:null;

function renderFeedbackAccess(){
  const session=feedbackSession(),role=state.user?.role||null;
  if(feedbackMailbox.session!==session){
    feedbackMailbox.session=session;feedbackMailbox.role=role;feedbackMailbox.items=[];feedbackMailbox.selectedId=null;feedbackMailbox.request=null;feedbackMailbox.serial++;feedbackMailbox.sending=false;
    feedbackMailbox.loaded=false;feedbackMailbox.historyKey=null;feedbackMailbox.previewKey=null;feedbackMailbox.renderedId=null;
    if($('feedbackDialog').open)$('feedbackDialog').close();
    $('feedbackSubject').value='';$('feedbackBody').value='';$('feedbackMessage').textContent='';$('feedbackHistoryMessage').textContent='';$('feedbackHistory').replaceChildren();
    $('feedbackPreview').hidden=true;$('feedbackPreviewEmpty').hidden=true;
    for(const id of ['feedbackPreviewSubject','feedbackPreviewMeta','feedbackPreviewBody'])$(id).textContent='';
    $('sendFeedback').disabled=false;$('sendFeedback').textContent='送出反饋';$('refreshFeedback').disabled=false;
  }else if(feedbackMailbox.role!==role){
    feedbackMailbox.role=role;feedbackMailbox.items=[];feedbackMailbox.selectedId=null;feedbackMailbox.request=null;feedbackMailbox.serial++;
    feedbackMailbox.loaded=false;feedbackMailbox.historyKey=null;feedbackMailbox.previewKey=null;feedbackMailbox.renderedId=null;
    renderFeedbackHistory();if($('feedbackDialog').open&&state.user)loadFeedbackHistory();
  }
  $('openFeedback').hidden=!state.user;
  $('feedbackDialog').classList.toggle('feedback-admin',role==='admin');
  $('feedbackForm').hidden=role==='admin';
  $('feedbackTitle').textContent='意見反饋';
  $('feedbackDescription').textContent=role==='admin'?'查看團隊建議與問題':'將建議或問題寄給管理員，送出後會保留寄件紀錄。';
  $('feedbackHistoryTitle').textContent=role==='admin'?'全部反饋':'我的寄件備份';
}

function feedbackTime(value){
  const date=new Date(value);return Number.isNaN(date.getTime())?'':date.toLocaleString('zh-TW',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
}

function renderFeedbackHistory(){
  const items=[...feedbackMailbox.items].sort((left,right)=>String(right.created_at).localeCompare(String(left.created_at))||right.id-left.id),admin=state.user?.role==='admin';
  if(admin&&!items.some(item=>item.id===feedbackMailbox.selectedId))feedbackMailbox.selectedId=items[0]?.id??null;
  const historyKey=JSON.stringify([admin,feedbackMailbox.selectedId,items.map(item=>[item.id,item.subject,item.author_name,item.department_name,item.created_at])]);
  if(historyKey!==feedbackMailbox.historyKey){
    const scroll=$('feedbackHistory').scrollTop;
    $('feedbackHistory').innerHTML=items.map(item=>`<button type="button" class="feedback-history-item${item.id===feedbackMailbox.selectedId?' selected':''}" data-feedback-id="${item.id}" aria-pressed="${item.id===feedbackMailbox.selectedId}"><strong>${esc(item.subject)}</strong><span>${esc(item.author_name)}${admin?' · '+esc(item.department_name||'未指定部門'):''}</span><time datetime="${esc(item.created_at)}">${esc(feedbackTime(item.created_at))}</time></button>`).join('')||`<p class="feedback-empty">${admin?'收件匣目前沒有反饋。':'你還沒有送出反饋。'}</p>`;
    $('feedbackHistory').scrollTop=scroll;feedbackMailbox.historyKey=historyKey;
  }
  const selected=items.find(item=>item.id===feedbackMailbox.selectedId);
  $('feedbackPreview').hidden=!selected;
  $('feedbackPreviewEmpty').hidden=!admin||!!selected;
  const previewKey=JSON.stringify(selected||null);
  if(previewKey!==feedbackMailbox.previewKey){
    const scroll=$('feedbackPreview').scrollTop,bodyScroll=$('feedbackPreviewBody').scrollTop,changed=feedbackMailbox.renderedId!==selected?.id;
    $('feedbackPreviewSubject').textContent=selected?.subject||'';
    $('feedbackPreviewMeta').textContent=selected?`寄件人：${selected.author_name}（${selected.author_username}）\n部門：${selected.department_name||'未指定部門'}\n日期：${feedbackTime(selected.created_at)}`:'';
    $('feedbackPreviewBody').textContent=selected?.body||'';
    $('feedbackPreview').scrollTop=changed?0:scroll;$('feedbackPreviewBody').scrollTop=changed?0:bodyScroll;
    feedbackMailbox.renderedId=selected?.id??null;feedbackMailbox.previewKey=previewKey;
  }
}

async function loadFeedbackHistory(showLoading=false){
  if(!state.user)return;
  if(feedbackMailbox.request)return feedbackMailbox.request;
  const session=feedbackSession(),serial=++feedbackMailbox.serial;
  $('refreshFeedback').disabled=true;if(showLoading||!feedbackMailbox.loaded)$('feedbackHistoryMessage').textContent='正在讀取紀錄…';
  const pending=(async()=>{
    try{
      const result=await api('/api/feedback');
      if(session!==feedbackSession()||serial!==feedbackMailbox.serial)return;
      feedbackMailbox.items=result.feedback;feedbackMailbox.loaded=true;$('feedbackHistoryMessage').textContent='';renderFeedbackHistory();
    }catch(error){if(session===feedbackSession()&&serial===feedbackMailbox.serial)$('feedbackHistoryMessage').textContent=error.message;}
    finally{
      if(feedbackMailbox.request===pending)feedbackMailbox.request=null;
      if(session===feedbackSession())$('refreshFeedback').disabled=false;
      if(session===feedbackSession()&&serial!==feedbackMailbox.serial&&$('feedbackDialog').open&&!feedbackMailbox.request)loadFeedbackHistory();
    }
  })();
  feedbackMailbox.request=pending;return pending;
}

$('openFeedback').addEventListener('click',()=>{
  if(!state.user)return;renderFeedbackAccess();if(typeof rememberForm==='function')rememberForm('feedbackForm');$('feedbackDialog').showModal();loadFeedbackHistory();
});
$('closeFeedback').addEventListener('click',()=>$('feedbackDialog').close());
$('refreshFeedback').addEventListener('click',()=>loadFeedbackHistory(true));
$('feedbackHistory').addEventListener('click',event=>{
  const button=event.target.closest('[data-feedback-id]');if(!button)return;
  feedbackMailbox.selectedId=Number(button.dataset.feedbackId);renderFeedbackHistory();
});
$('feedbackForm').addEventListener('submit',async event=>{
  event.preventDefault();if(!state.user||state.user.role==='admin'||feedbackMailbox.sending||!$('feedbackForm').reportValidity())return;
  const originalSubject=$('feedbackSubject').value,originalBody=$('feedbackBody').value,subject=originalSubject.trim(),body=originalBody.trim(),session=feedbackSession();
  if(!subject||!body){$('feedbackMessage').textContent='請填寫主旨與內文。';return;}
  if(subject.length>150||body.length>10000){$('feedbackMessage').textContent='主旨最多 150 個字，內文最多 10,000 個字。';return;}
  feedbackMailbox.sending=true;$('sendFeedback').disabled=true;$('sendFeedback').textContent='送出中…';$('feedbackMessage').textContent='';
  try{
    const item=await api('/api/feedback',{method:'POST',body:JSON.stringify({subject,body})});
    if(session!==feedbackSession())return;
    feedbackMailbox.serial++;feedbackMailbox.items=feedbackMailbox.items.filter(value=>value.id!==item.id).concat(item);feedbackMailbox.selectedId=item.id;
    if($('feedbackSubject').value===originalSubject)$('feedbackSubject').value='';
    if($('feedbackBody').value===originalBody)$('feedbackBody').value='';
    $('feedbackMessage').textContent='已送給管理員，寄件紀錄已保留。';renderFeedbackHistory();
  }catch(error){if(session===feedbackSession())$('feedbackMessage').textContent=error.message;}
  finally{if(session===feedbackSession()){feedbackMailbox.sending=false;$('sendFeedback').disabled=false;$('sendFeedback').textContent='送出反饋';}}
});
renderFeedbackAccess();
