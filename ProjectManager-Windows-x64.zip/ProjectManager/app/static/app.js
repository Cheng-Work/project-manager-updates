'use strict';

const $ = id => document.getElementById(id);
const labels = {project:'專案',work:'內容',task:'任務',urgent:'緊急',high:'高',medium:'中',low:'低',not_started:'未開始',in_progress:'進行中',pending_review:'待審核',on_hold:'擱置',completed:'已完成',developing:'開發中',maintenance:'維護中',closed:'結案',abandoned:'廢案'};
const state = {items:[],owners:[],departments:[],revision:null,today:'',connected:false,loading:false,editing:null,saving:false,collapsed:new Set(),lastSaved:null,user:null,csrf:null,authGeneration:0,detailsId:null};
try { state.collapsed = new Set(JSON.parse(localStorage.getItem('pm-collapsed') || '[]')); } catch { /* 私密瀏覽仍可操作。 */ }
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const ownerName = id => state.owners.find(o=>o.id===id)?.name || '';
const itemById = id => state.items.find(i=>i.id===Number(id));
const overdue = item => item.level === 'task' && !!item.due_date && item.due_date < state.today && item.status !== 'completed';
const isRoot = () => state.user?.username?.toLowerCase() === 'root';
const isAdmin = () => state.user?.role === 'admin';
const roleName = role => ({admin:'管理員',supervisor:'主管',member:'一般人員'}[role]||'一般人員');
const departmentLabel = id => state.departments.find(d=>d.id===id)?.name||'未指定部門';
const canEditProjects = () => isAdmin() || state.user?.role === 'supervisor';
const canEditItem = item => !!item && (isAdmin() || (state.user?.role==='supervisor' && item.can_edit===true));
const canAddChildren = item => !!item && item.level!=='task' && (isAdmin() || (state.user?.role==='supervisor' && item.can_add_child===true));
const statuses = ['not_started','in_progress','pending_review','on_hold','completed'];
const lifecycleStatuses = ['not_started','developing','maintenance','closed','abandoned'];
const effectiveDue = item => item.level==='work'?(item.effective_due_date||item.due_date):item.due_date;
const statusSaving = new Set();
const canChangeStatus = item => !!state.user && !!item && (canEditItem(item) || (state.user.role==='member'&&item.level==='task'&&item.can_change_status===true&&item.status!=='completed'));
const allowedStatuses = item => item?.level !== 'task' ? canEditItem(item)?lifecycleStatuses:[] : canEditItem(item) ? statuses : canChangeStatus(item) ? statuses.filter(value=>value!=='completed') : [];
let toastTimer;
let detailsReturnFocus=null,detailsRenderedKey='';
const discussionRecords=new Map(),commentDrafts=new Map();
let discussionVisibleId=null;

async function api(path, options={}) {
  const generation=state.authGeneration;
  let response;
  try {
    response = await fetch(path, {...options, credentials:'same-origin', headers:{'Content-Type':'application/json', ...(state.csrf?{'X-CSRF-Token':state.csrf}:{}), ...options.headers}});
  } catch {
    if(generation===state.authGeneration)setConnection(false);
    throw new Error('無法連接 server，請確認伺服器仍在執行。');
  }
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || '操作失敗，請重試。');
    error.code = data.code;
    if (error.code === 'AUTH_REQUIRED'&&generation===state.authGeneration) showLogin('登入已到期或帳號已更新，請重新登入。');
    if (error.code === 'CONFLICT'&&generation===state.authGeneration) await loadState(true);
    throw error;
  }
  if(generation===state.authGeneration)setConnection(true);
  return data;
}

function setConnection(connected) {
  state.connected = connected;
  $('connectionText').textContent = connected ? '已連線' : '連線中斷';
  $('connectionDot').classList.toggle('offline', !connected);
  $('connectionError').hidden = connected;
}

async function loadState(force=false) {
  if (state.loading || !state.user) return;
  state.loading = true;
  const generation = state.authGeneration;
  try {
    const query = !force && state.revision !== null ? '?since='+state.revision : '';
    const data = await api('/api/state'+query);
    if (generation !== state.authGeneration) return;
    if (data.current_user) setUser(data.current_user);
    if (!data.unchanged) {
      state.items = data.items;
      state.owners = data.owners;
      state.departments = data.departments || [];
      state.today = data.today;
      state.revision = data.revision;
      const filter = $('ownerFilter').value;
      $('ownerFilter').innerHTML = '<option value="">全部負責人</option><option value="unassigned">未指派</option>' + state.owners.map(o=>`<option value="${o.id}">${esc(o.name)}${o.active?'':'（停用）'}</option>`).join('');
      $('ownerFilter').value = filter;
      if(typeof renderDepartments==='function')renderDepartments();
      render();
      if ($('ownersDialog').open && !document.activeElement?.closest('.owner-entry')) renderOwners();
    }
  } catch (error) {
    if (!state.items.length) $('itemRows').innerHTML = `<tr><td colspan="7" class="empty-cell">${esc(error.message)}</td></tr>`;
  } finally { state.loading = false; }
}

function refreshProjectFilter() {
  const selected=$('projectFilter').value;
  $('projectFilter').innerHTML='<option value="">全部專案</option>'+state.items.filter(i=>i.level==='project').sort(compareItems).map(i=>`<option value="${i.id}">${esc(i.name)}</option>`).join('');
  $('projectFilter').value=state.items.some(i=>i.level==='project'&&String(i.id)===selected)?selected:'';
}

function refreshContentFilter() {
  const control=$('contentFilter'),selected=control.value,project=$('projectFilter').value;
  const contents=state.items.filter(item=>item.level==='work'&&(!project||String(item.parent_id)===project)).sort(compareItems);
  control.innerHTML='<option value="">全部內容</option>'+contents.map(item=>`<option value="${item.id}">${esc(project?item.name:(itemById(item.parent_id)?.name||'專案')+' / '+item.name)}</option>`).join('');
  control.value=contents.some(item=>String(item.id)===selected)?selected:'';
  control.hidden=state.view!=='board'&&state.view!=='timeline';
}

function compareItems(a,b) {
  const sort=$('sortBy').value;
  let result=0;
  if(sort==='due_date'&&a.level!=='project'&&b.level!=='project') result=(effectiveDue(a)||'9999').localeCompare(effectiveDue(b)||'9999');
  if(sort==='priority'&&a.level==='task'&&b.level==='task') result=({urgent:0,high:1,medium:2,low:3}[a.priority])-({urgent:0,high:1,medium:2,low:3}[b.priority]);
  if(sort==='name') result=a.name.localeCompare(b.name,'zh-TW');
  return result || a.position-b.position || a.id-b.id;
}

function matchingItems() {
  const byId=new Map(state.items.map(i=>[i.id,i]));
  const query=$('search').value.trim().toLocaleLowerCase(), status=$('statusFilter').value, owner=$('ownerFilter').value, project=$('projectFilter').value;
  const content=state.view==='board'||state.view==='timeline'?$('contentFilter').value:'';
  const department=$('departmentFilter').value;
  return state.items.filter(item=>{
    const ancestors=[];let current=item;
    while(current){ancestors.push(current);current=byId.get(current.parent_id);}
    if(project&&!ancestors.some(i=>i.level==='project'&&String(i.id)===project))return false;
    if(content&&!ancestors.some(i=>i.level==='work'&&String(i.id)===content))return false;
    if(department&&String(item.effective_department_id)!==department)return false;
    const haystack=ancestors.map(i=>`${i.name} ${ownerName(i.owner_id)}`).join(' ').toLocaleLowerCase();
    if(query && !haystack.includes(query)) return false;
    if(status && item.status!==status) return false;
    if(owner && (owner==='unassigned' ? item.owner_id!==null : item.owner_id!==Number(owner))) return false;
    return true;
  });
}

function visibleItems(matches=matchingItems()) {
  const byId=new Map(state.items.map(i=>[i.id,i])),children=new Map(),included=new Set();
  for(const item of state.items){
    if(!children.has(item.parent_id))children.set(item.parent_id,[]);
    children.get(item.parent_id).push(item);
  }
  for(const list of children.values())list.sort(compareItems);
  for(const item of matches){
    let current=item;
    while(current){included.add(current.id);current=byId.get(current.parent_id);}
  }
  const rows=[];
  function visit(item,depth) {
    if(!included.has(item.id)) return;
    const kids=children.get(item.id)||[];
    rows.push({item,depth,hasChildren:kids.length>0});
    if(!state.collapsed.has(item.id)) kids.forEach(child=>visit(child,depth+1));
  }
  (children.get(null)||[]).forEach(i=>visit(i,0));
  return rows;
}

function render() {
  refreshProjectFilter();
  refreshContentFilter();
  const tasks=state.items.filter(i=>i.level==='task'), projects=state.items.filter(i=>i.level==='project');
  $('totalTasks').textContent=tasks.length;
  $('activeTasks').textContent=tasks.filter(i=>i.status==='in_progress').length;
  $('doneTasks').textContent=tasks.filter(i=>i.status==='completed').length;
  $('reviewTasks').textContent=tasks.filter(i=>i.status==='pending_review').length;
  $('overdueTasks').textContent=tasks.filter(overdue).length;
  $('projectCount').textContent=projects.length;
  $('ownerCount').textContent=state.owners.filter(o=>o.active).length;
  $('overviewCount').textContent=`${projects.length} 個專案 · ${state.items.filter(i=>i.level==='work').length} 項內容 · ${tasks.length} 個任務`;
  const matches=matchingItems(),rows=visibleItems(matches),taskMatches=matches.filter(i=>i.level==='task').sort(compareItems);
  $('visibleCount').textContent=state.view&&state.view!=='list'?`顯示 ${taskMatches.length} 個任務`:`顯示 ${rows.length} 筆，共 ${state.items.length} 筆項目`;
  const editor=document.activeElement?.closest('#itemRows [data-inline-field]');
  if(!editor||editor.disabled||!canEditItem(itemById(editor.dataset.inlineId)))$('itemRows').innerHTML=rows.length ? rows.map(renderRow).join('') : `<tr><td colspan="7" class="empty-cell">${state.items.length?'沒有符合條件的項目，請調整篩選。':canEditProjects()?'還沒有專案，按右上方「新增」建立第一個專案。':'目前尚未建立專案。'}</td></tr>`;
  if(typeof renderViews==='function')renderViews(taskMatches.map(item=>({item,context:!!item.context_only})));
  renderDetails();
}

function renderRow({item:i,depth,hasChildren}) {
  const editable=canEditItem(i),isTask=i.level==='task';
  const owner=ownerName(i.owner_id), isOverdue=overdue(i);
  const toggle=hasChildren ? `<button class="tree-toggle ${state.collapsed.has(i.id)?'':'expanded'}" data-action="toggle" data-id="${i.id}" aria-label="${state.collapsed.has(i.id)?'展開':'收合'}${esc(i.name)}" aria-expanded="${!state.collapsed.has(i.id)}">${icon('chevron')}</button>` : '<span class="tree-spacer"></span>';
  const dateText=effectiveDue(i) ? `<span class="due-cell ${isOverdue?'overdue':''}">${effectiveDue(i).replaceAll('-','/')}${i.due_date_inherited?'<span class="inherited-date">依任務日期</span>':''}${isOverdue?'<span class="overdue-note">已逾期</span>':''}</span>` : '<span class="muted">未設定</span>';
  const statusOptions=allowedStatuses(i).map(s=>`<option value="${s}" ${i.status===s?'selected':''}>${labels[s]}</option>`).join('');
  const add=!canAddChildren(i) ? '' : `<button class="icon-button" data-action="child" data-id="${i.id}" title="新增${i.level==='project'?'內容':'任務'}" aria-label="在${esc(i.name)}下新增${i.level==='project'?'內容':'任務'}">${icon('plus')}</button>`;
  const remove=isRoot()?`<button class="icon-button danger-icon" data-action="delete" data-id="${i.id}" title="永久刪除" aria-label="永久刪除${esc(i.name)}">${icon('trash')}</button>`:'';
  return `<tr class="${i.level}-row depth-${depth}${hasChildren?' branch-row':''}${state.detailsId===i.id?' selected-item':''}" data-item-id="${i.id}"${hasChildren?` data-branch-id="${i.id}"`:''}>
    <td><div class="item-title">${toggle}<span class="type-label">${labels[i.level]}</span><div><button class="item-name" data-action="view" data-id="${i.id}" aria-controls="detailsPanel" aria-expanded="${state.detailsId===i.id}">${esc(i.name)}</button></div></div></td>
    <td>${editable?inlineField(i,'owner_id'):owner?`<span class="owner-cell">${esc(owner)}</span>`:'<span class="muted">未指派</span>'}</td>
    <td>${editable?inlineField(i,'department_id'):esc(departmentLabel(i.effective_department_id))}</td>
    <td>${i.level==='project'?'':editable?inlineField(i,'due_date'):dateText}</td><td>${isTask?(editable?inlineField(i,'priority'):`<span class="priority ${i.priority}">${labels[i.priority]}</span>`):''}</td>
    <td>${canChangeStatus(i)?`<select class="status-select ${i.status}" data-status-id="${i.id}" ${statusSaving.has(i.id)?'disabled':''} aria-label="${esc(i.name)}的狀態" title="${editable?'更新狀態':'完成由管理員確認'}">${statusOptions}</select>`:`<span class="status-label ${i.status}">${labels[i.status]}</span>`}</td>
    <td><div class="row-actions"><button class="icon-button" data-action="view" data-id="${i.id}" title="查看詳情" aria-label="查看${esc(i.name)}" aria-controls="detailsPanel">${icon('list')}</button>${editable?`${add}<button class="icon-button" data-action="edit" data-id="${i.id}" title="編輯" aria-label="編輯${esc(i.name)}">${icon('edit')}</button>`:''}${isAdmin()?`<button class="icon-button" data-action="archive" data-id="${i.id}" title="封存" aria-label="封存${esc(i.name)}">${icon('archive')}</button>${remove}`:''}</div></td></tr>`;
}

function inlineField(item,field) {
  const fieldName={owner_id:'負責人',department_id:'部門',due_date:'預計完成日期',priority:'優先度'}[field];
  const attributes=`data-inline-id="${item.id}" data-inline-field="${field}" data-version="${item.version}" aria-label="${esc(item.name)}的${fieldName}" ${statusSaving.has(item.id)?'disabled':''}`;
  if(field==='due_date')return `<input type="date" class="inline-field inline-date${overdue(item)?' overdue':''}" ${attributes} value="${esc(effectiveDue(item)||'')}">${item.due_date_inherited?'<span class="inherited-date">依任務自動帶入</span>':''}`;
  if(field==='owner_id')return `<select class="inline-field inline-owner" ${attributes}><option value="">未指派</option>${state.owners.filter(o=>o.active||o.id===item.owner_id).map(o=>`<option value="${o.id}"${o.id===item.owner_id?' selected':''}>${esc(o.name)}${o.active?'':'（停用）'}</option>`).join('')}</select>`;
  if(field==='department_id'){
    const parent=itemById(item.parent_id),inherited=parent?.effective_department_id??null,supervisor=state.user?.role==='supervisor';
    const choices=state.departments.filter(d=>!supervisor||d.id===state.user.department_id);
    const blankDisabled=supervisor&&inherited!==state.user.department_id;
    return `<select class="inline-field inline-department" ${attributes}><option value=""${item.department_id===null?' selected':''}${blankDisabled?' disabled':''}>${parent?'沿用：'+esc(departmentLabel(inherited)):'未指定部門'}</option>${choices.map(d=>`<option value="${d.id}"${d.id===item.department_id?' selected':''}>${esc(d.name)}</option>`).join('')}</select>`;
  }
  return `<select class="inline-field inline-priority priority ${item.priority}" ${attributes}>${['urgent','high','medium','low'].map(value=>`<option value="${value}"${value===item.priority?' selected':''}>${labels[value]}</option>`).join('')}</select>`;
}

function renderDetailFields(item) {
  const isTask=item.level==='task';
  $('detailsDueRow').hidden=item.level==='project';$('detailsPriorityRow').hidden=!isTask;$('detailsStatusRow').hidden=false;
  const focused=document.activeElement?.closest('#detailsPanel [data-inline-field]');
  if(canEditItem(item)){
    if(focused&&!focused.disabled&&Number(focused.dataset.inlineId)===item.id)return;
    $('detailsOwner').innerHTML=inlineField(item,'owner_id');
    $('detailsDepartment').innerHTML=inlineField(item,'department_id');
    $('detailsDue').innerHTML=item.level!=='project'?inlineField(item,'due_date'):'';
    $('detailsPriority').className='';$('detailsPriority').innerHTML=isTask?inlineField(item,'priority'):'';
  }else{
    $('detailsOwner').textContent=ownerName(item.owner_id)||'未指派';
    $('detailsDepartment').textContent=departmentLabel(item.effective_department_id);
    $('detailsDue').textContent=effectiveDue(item)?effectiveDue(item).replaceAll('-','/')+(item.due_date_inherited?'（依任務）':''):'未設定';
    $('detailsPriority').textContent=labels[item.priority];$('detailsPriority').className='priority '+item.priority;
  }
  $('detailsDue').classList.toggle('overdue',overdue(item));
}

async function saveInlineField(control) {
  if(!canEditProjects()||control.disabled)return;
  const item=itemById(control.dataset.inlineId),field=control.dataset.inlineField,generation=state.authGeneration;
  if(!canEditItem(item)||!['owner_id','department_id','due_date','priority'].includes(field))return;
  if((item.level==='project'&&!['owner_id','department_id'].includes(field))||(item.level==='work'&&field==='priority'))return;
  if(control.reportValidity&&!control.reportValidity())return;
  const value=['owner_id','department_id'].includes(field)?(control.value?Number(control.value):null):control.value||null;
  if(item[field]===value)return;
  if(statusSaving.has(item.id)){toast('此項目正在儲存，請稍候。',true);return;}
  statusSaving.add(item.id);control.disabled=true;render();
  try{
    const updated=await api('/api/items/'+item.id,{method:'PATCH',body:JSON.stringify({version:Number(control.dataset.version),[field]:value})});
    if(generation!==state.authGeneration)return;
    updateLocal(updated);if(['due_date','department_id'].includes(field))await loadState(true);if(generation!==state.authGeneration)return;saved('已更新'+{owner_id:'負責人',department_id:'部門',due_date:'預計完成日期',priority:'優先度'}[field]);
  }catch(error){if(generation===state.authGeneration)toast(error.message,true);}
  finally{if(generation===state.authGeneration){statusSaving.delete(item.id);render();}}
}

function persistCollapse() {
  try{localStorage.setItem('pm-collapsed',JSON.stringify([...state.collapsed]));}catch{}
}

function toast(message,error=false) {
  clearTimeout(toastTimer);$('toast').hidden=false;$('toast').classList.toggle('error',error);$('toast').querySelector('span').textContent=message;
  toastTimer=setTimeout(()=>$('toast').hidden=true,4000);
}

function saved(message) {
  state.lastSaved=Date.now();$('lastSaved').textContent='剛剛已儲存';toast(message);
}

function updateLocal(item) {
  const index=state.items.findIndex(i=>i.id===item.id);
  if(index<0) state.items.push(item);else state.items[index]={...state.items[index],...item};
  let parent=item.parent_id;
  while(parent!==null){state.collapsed.delete(parent);parent=itemById(parent)?.parent_id??null;}
  render();
}

function openDetails(item,trigger=document.activeElement) {
  if(!state.user||!item)return;
  const panel=$('detailsPanel');
  if(panel.hidden||!panel.contains(trigger))detailsReturnFocus=trigger;
  const changed=state.detailsId!==item.id;
  if(changed)saveCommentDraft();
  state.detailsId=item.id;
  panel.hidden=false;$('workspace').classList.add('has-details');
  if(changed){detailsRenderedKey='';$('detailsFeedback').textContent='';}
  render();
  if(!document.querySelector('dialog[open]'))$('detailsTitle').focus({preventScroll:true});
}

function closeDetails(restoreFocus=true) {
  saveCommentDraft();discussionVisibleId=null;
  $('commentBody').value='';
  const previousId=state.detailsId;
  state.detailsId=null;detailsRenderedKey='';
  $('detailsPanel').hidden=true;$('workspace').classList.remove('has-details');$('workspace').classList.remove('details-push');
  for(const row of $('itemRows').querySelectorAll('.selected-item'))row.classList.remove('selected-item');
  for(const button of $('itemRows').querySelectorAll('.item-name[data-action="view"]'))button.setAttribute('aria-expanded','false');
  if(restoreFocus){
    const fallback=$('itemRows').querySelector(`[data-action="view"][data-id="${previousId}"]`);
    const target=detailsReturnFocus?.isConnected&&!detailsReturnFocus.closest('#detailsPanel')?detailsReturnFocus:fallback||$('search');
    target.focus({preventScroll:true});
  }
  detailsReturnFocus=null;
}

function renderDetails() {
  if(state.detailsId===null)return;
  const item=itemById(state.detailsId);
  if(!item){closeDetails($('detailsPanel').contains(document.activeElement));return;}
  const ancestors=[];let parent=itemById(item.parent_id);
  while(parent){ancestors.unshift(parent);parent=itemById(parent.parent_id);}
  $('detailsLevel').textContent=labels[item.level];
  $('detailsTitle').textContent=item.name;
  $('detailsBreadcrumb').textContent=ancestors.length?ancestors.map(i=>i.name).join(' / '):'專案總覽';
  renderDetailFields(item);
  $('detailsNotes').textContent=item.notes||'尚無說明';
  $('detailsNotes').classList.toggle('empty-description',!item.notes);
  $('editDetails').hidden=!canEditItem(item);
  const status=$('detailsStatus'),key=`${item.id}:${item.version}:${state.user?.role}:${canEditItem(item)}:${canChangeStatus(item)}`;
  if(key!==detailsRenderedKey){
    const options=allowedStatuses(item);
    status.innerHTML=options.length?options.map(value=>`<option value="${value}"${value===item.status?' selected':''}>${labels[value]}</option>`).join(''):`<option value="${item.status}" selected disabled>${labels[item.status]}</option>`;
    status.value=item.status;
    detailsRenderedKey=key;
  }
  status.disabled=!canChangeStatus(item)||statusSaving.has(item.id);
  status.className='status-select details-status '+item.status;
  $('detailsStatusHint').textContent=state.user?.role==='supervisor'&&!canEditItem(item)?'此項目僅供查看，主管只能修改本部門項目。':item.level!=='task'?'專案與內容的狀態由管理員或本部門主管調整。':canEditItem(item)?'待審核任務可確認為已完成。':item.status==='completed'?'此任務已完成，僅管理員或本部門主管可以調整。':canChangeStatus(item)?'完成任務後請設為待審核，也可將任務設為擱置。':'此項目僅供查看。';
  const children=state.items.filter(i=>i.parent_id===item.id).sort(compareItems);
  $('detailsChildrenSection').hidden=!children.length;
  $('detailsChildren').innerHTML=children.map(child=>`<button type="button" class="details-child" data-detail-id="${child.id}"><span><span class="details-child-type">${labels[child.level]}</span><strong>${esc(child.name)}</strong></span><span class="status-label ${child.status}">${labels[child.status]}</span>${icon('chevron')}</button>`).join('');
  updateDetailsPosition();
  syncDiscussionItem(item.id);
}

function updateDetailsPosition() {
  const panel=$('detailsPanel'),workspace=$('workspace'),main=document.querySelector('.main'),filters=document.querySelector('.filter-row');
  if(panel.hidden||!main||!filters)return;
  const width=panel.getBoundingClientRect().width,mainStyle=getComputedStyle(main),filterStyle=getComputedStyle(filters);
  const controls=[...filters.querySelectorAll('select')].filter(control=>control.getClientRects().length);
  const controlsWidth=controls.reduce((sum,control)=>sum+control.getBoundingClientRect().width,0);
  const gap=parseFloat(filterStyle.columnGap)||0;
  const minimum=Math.max(640,controlsWidth+gap*Math.max(0,controls.length-1));
  const available=workspace.clientWidth-main.getBoundingClientRect().left-(parseFloat(mainStyle.paddingLeft)||0)-(parseFloat(mainStyle.paddingRight)||0)-width;
  const push=window.innerWidth>1200&&available>=minimum;
  const nextWidth=Math.round(width)+'px';
  if(workspace.style.getPropertyValue('--details-width')!==nextWidth)workspace.style.setProperty('--details-width',nextWidth);
  if(workspace.classList.contains('details-push')!==push)workspace.classList.toggle('details-push',push);
  if(panel.style.getPropertyValue('--details-top')!=='0px')panel.style.setProperty('--details-top','0px');
}

function discussionRecord(id) {
  if(!discussionRecords.has(id))discussionRecords.set(id,{comments:[],loaded:false,error:'',fetchedAt:0,fetching:null,request:0,commentSending:false,commentFeedback:'',deleting:new Set(),commentsMarkup:null});
  return discussionRecords.get(id);
}

function saveCommentDraft() {
  if(discussionVisibleId===null)return;
  const value=$('commentBody').value;
  if(value)commentDrafts.set(discussionVisibleId,value);else commentDrafts.delete(discussionVisibleId);
}

function resetDiscussion() {
  discussionRecords.clear();commentDrafts.clear();discussionVisibleId=null;
  $('commentBody').value='';
  $('commentList').replaceChildren();
  $('commentFeedback').textContent='';
}

function syncDiscussionItem(id) {
  if(discussionVisibleId!==id){
    saveCommentDraft();discussionVisibleId=id;
    $('commentBody').value=commentDrafts.get(id)||'';
    const record=discussionRecord(id);record.commentsMarkup=null;
    renderDiscussion(id);loadDiscussion(id);
  }else renderDiscussion(id);
}

function discussionTime(value) {
  const parsed=new Date(typeof value==='number'?value*1000:value);
  return Number.isNaN(parsed.getTime())?'':parsed.toLocaleString('zh-TW',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
}

function renderDiscussion(id) {
  if(!state.user||state.detailsId!==id||discussionVisibleId!==id||$('detailsPanel').hidden)return;
  const record=discussionRecord(id);
  const placeholder=record.error||(!record.loaded?'正在載入…':'');
  const comments=[...record.comments].sort((a,b)=>String(a.created_at).localeCompare(String(b.created_at))||a.id-b.id);
  const commentMarkup=comments.map(comment=>`<article class="comment-entry"><div class="comment-heading"><strong>${esc(comment.author_name)}</strong><time datetime="${esc(comment.created_at)}">${esc(discussionTime(comment.created_at))}</time>${comment.can_delete?`<button type="button" class="icon-button danger-icon" data-delete-comment="${comment.id}" ${record.deleting.has('comment:'+comment.id)?'disabled':''} aria-label="刪除${esc(comment.author_name)}的留言" title="刪除留言">${icon('trash')}</button>`:''}</div><p class="comment-body">${esc(comment.body)}</p></article>`).join('')+(placeholder?`<p class="collaboration-empty ${record.error?'collaboration-error':''}">${esc(placeholder)}</p>`:!comments.length?'<p class="collaboration-empty">還沒有留言，開始和團隊討論吧。</p>':'');
  if(record.commentsMarkup!==commentMarkup){$('commentList').innerHTML=commentMarkup;record.commentsMarkup=commentMarkup;}
  renderDiscussionControls(id);
}

function renderDiscussionControls(id) {
  if(state.detailsId!==id||discussionVisibleId!==id)return;
  const record=discussionRecord(id);
  $('sendComment').disabled=record.commentSending||!(commentDrafts.get(id)||'').trim();
  $('sendComment').textContent=record.commentSending?'送出中…':'送出留言';
  $('commentFeedback').textContent=record.commentFeedback;
}

async function loadDiscussion(id,force=false) {
  if(!state.user||!itemById(id))return;
  const record=discussionRecord(id);
  if(record.fetching)return record.fetching;
  if(!force&&record.loaded&&Date.now()-record.fetchedAt<4500)return;
  const generation=state.authGeneration,request=++record.request;
  const pending=(async()=>{
    try{
      const result=await api('/api/items/'+id+'/discussion');
      if(generation!==state.authGeneration||request!==record.request)return;
      record.comments=result.comments;record.loaded=true;record.error='';record.fetchedAt=Date.now();
      renderDiscussion(id);
    }catch(error){
      if(generation===state.authGeneration&&request===record.request){record.error=error.message;record.fetchedAt=Date.now();renderDiscussion(id);}
    }finally{
      if(record.fetching===pending)record.fetching=null;
      if(generation===state.authGeneration&&request!==record.request&&state.detailsId===id)loadDiscussion(id,true);
    }
  })();
  record.fetching=pending;return pending;
}

$('commentBody').addEventListener('input',()=>{
  saveCommentDraft();
  if(discussionVisibleId!==null){discussionRecord(discussionVisibleId).commentFeedback='';renderDiscussionControls(discussionVisibleId);}
});
$('commentBody').addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key==='Enter'&&!e.isComposing){e.preventDefault();$('commentForm').requestSubmit();}
});
$('commentForm').addEventListener('submit',async e=>{
  e.preventDefault();const id=discussionVisibleId;
  if(!state.user||id===null||!itemById(id))return;
  saveCommentDraft();
  const record=discussionRecord(id),draft=commentDrafts.get(id)||'',body=draft.trim(),generation=state.authGeneration;
  if(record.commentSending)return;
  if(!body){record.commentFeedback='請先輸入留言。';renderDiscussionControls(id);return;}
  if(body.length>8000){record.commentFeedback='留言最多 8,000 個字。';renderDiscussionControls(id);return;}
  record.commentSending=true;record.commentFeedback='';renderDiscussionControls(id);
  try{
    const comment=await api('/api/items/'+id+'/comments',{method:'POST',body:JSON.stringify({body})});
    if(generation!==state.authGeneration)return;
    record.request++;record.comments=record.comments.filter(old=>old.id!==comment.id).concat(comment);record.loaded=true;record.error='';
    if(commentDrafts.get(id)===draft){commentDrafts.delete(id);if(discussionVisibleId===id)$('commentBody').value='';}
    record.commentFeedback='留言已送出。';renderDiscussion(id);
  }catch(error){if(generation===state.authGeneration){record.commentFeedback=error.message;renderDiscussionControls(id);}}
  finally{record.commentSending=false;if(generation===state.authGeneration)renderDiscussionControls(id);}
});

async function deleteComment(entryId) {
  const id=discussionVisibleId;if(!state.user||id===null)return;
  const record=discussionRecord(id),entry=record.comments.find(value=>value.id===entryId),generation=state.authGeneration;
  if(!entry?.can_delete||record.deleting.has('comment:'+entryId))return;
  if(!confirm('確定刪除這則留言？刪除後無法復原。'))return;
  record.deleting.add('comment:'+entryId);renderDiscussion(id);
  try{
    await api('/api/comments/'+entryId,{method:'DELETE',body:'{}'});
    if(generation!==state.authGeneration)return;
    record.request++;record.comments=record.comments.filter(value=>value.id!==entryId);
    renderDiscussion(id);
  }catch(error){if(generation===state.authGeneration){record.commentFeedback=error.message;renderDiscussionControls(id);}}
  finally{record.deleting.delete('comment:'+entryId);if(generation===state.authGeneration)renderDiscussion(id);}
}
$('commentList').addEventListener('click',e=>{const button=e.target.closest('[data-delete-comment]');if(button)deleteComment(Number(button.dataset.deleteComment));});

async function saveWorkStatus(item,value) {
  const current=itemById(item?.id),generation=state.authGeneration;
  if(!current||!allowedStatuses(current).includes(value)||!canChangeStatus(current))throw new Error('只能調整自己負責且尚未完成的項目；完成須由管理員確認。');
  if(statusSaving.has(current.id))throw new Error('此項目正在儲存，請稍候。');
  if(current.status===value)return false;
  statusSaving.add(current.id);render();
  try{
    const updated=await api('/api/items/'+current.id,{method:'PATCH',body:JSON.stringify({version:current.version,status:value})});
    if(generation!==state.authGeneration)return false;
    updateLocal(updated);
    saved(value==='pending_review'?'已送交管理員審核':'狀態已更新');
    return true;
  }finally{
    if(generation===state.authGeneration){statusSaving.delete(current.id);render();}
  }
}

async function saveItemStatus(item,value,select,feedback=null) {
  const generation=state.authGeneration;
  if(feedback)feedback.textContent='正在儲存狀態…';
  try{
    const changed=await saveWorkStatus(item,value);
    if(changed&&feedback&&state.detailsId===item.id)feedback.textContent='狀態已儲存。';
  }catch(error){
    if(generation!==state.authGeneration)return;
    select.value=itemById(item.id)?.status||item.status;
    if(feedback&&state.detailsId===item.id)feedback.textContent=error.message;
    toast(error.message,true);
  }
}

$('closeDetails').addEventListener('click',()=>closeDetails());
$('editDetails').addEventListener('click',()=>{
  if(!canEditProjects())return;
  const item=itemById(state.detailsId);if(item)openItem({item});
});
$('detailsChildren').addEventListener('click',e=>{
  const button=e.target.closest('[data-detail-id]');if(!button)return;
  const item=itemById(button.dataset.detailId);if(item)openDetails(item,button);
});
$('detailsStatus').addEventListener('change',async e=>{
  const item=itemById(state.detailsId);if(item)await saveItemStatus(item,e.target.value,e.target,$('detailsFeedback'));
});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&!e.defaultPrevented&&!$('detailsPanel').hidden&&!document.querySelector('dialog[open]')){
    e.preventDefault();closeDetails();
  }
});

function updateTaskFields() {
  const level=$('itemLevel').value,isTask=level==='task',current=$('itemStatus').value,options=isTask?statuses:lifecycleStatuses;
  $('itemDueField').hidden=level==='project';$('itemPriorityField').hidden=!isTask;
  $('itemDueField').parentElement?.classList.toggle('single-column',level==='project');
  $('itemTaskFields').classList.toggle('single-column',!isTask);
  $('itemDue').disabled=level==='project';$('itemPriority').disabled=!isTask;$('itemStatus').disabled=false;
  $('itemDueHint').hidden=level!=='work';
  $('itemStatus').innerHTML=options.map(value=>`<option value="${value}">${labels[value]}</option>`).join('');
  $('itemStatus').value=options.includes(current)?current:'not_started';
}

function updateParentOptions(selected='') {
  const level=$('itemLevel').value, expected=level==='work'?'project':level==='task'?'work':null;
  $('parentLabel').textContent=level==='work'?'所屬專案':level==='task'?'所屬內容':'上層';
  $('parentRequired').hidden=!expected;
  $('itemParent').disabled=!expected;$('itemParent').required=!!expected;
  const placeholder=expected ? `選擇${labels[expected]}` : '專案不需上層';
  $('itemParent').innerHTML=`<option value="">${placeholder}</option>`+state.items.filter(i=>i.level===expected&&(canAddChildren(i)||i.id===state.editing?.parent_id)).map(i=>{
    const parent=itemById(i.parent_id);
    return `<option value="${i.id}">${esc(parent?parent.name+' / '+i.name:i.name)}</option>`;
  }).join('');
  $('itemParent').value=String(selected??'');
  updateTaskFields();
}

function openItem({item=null,parent=null}={}) {
  if(!canEditProjects()||(item&&!canEditItem(item))||(parent&&!canAddChildren(parent)))return;
  state.editing=item;state.saving=false;
  $('itemForm').reset();$('formFeedback').textContent='';$('formFeedback').classList.remove('error');
  $('saveItem').disabled=false;$('saveItem').classList.remove('saving');
  $('itemDialogTitle').textContent=item?'編輯項目':'新增項目';
  $('itemDialogSubtitle').textContent=item?'修改父級會連同子項目一起移動。':'選擇層級及所屬專案或內容。';
  $('saveItem').querySelector('span').textContent=item?'儲存變更':'新增';
  $('saveItem').querySelector('svg').toggleAttribute('hidden',!!item);
  const level=item?.level || (parent ? parent.level==='project'?'work':'task' : state.items.some(i=>i.level==='work'&&canAddChildren(i))?'task':state.items.some(i=>i.level==='project'&&canAddChildren(i))?'work':'project');
  $('itemLevel').value=level;$('itemLevel').disabled=!!item;
  updateParentOptions(item?.parent_id??parent?.id??'');
  $('itemOwner').innerHTML='<option value="">未指派</option>'+state.owners.filter(o=>o.active||o.id===item?.owner_id).map(o=>`<option value="${o.id}">${esc(o.name)}${o.active?'':'（停用）'}</option>`).join('');
  $('itemName').value=item?.name||'';$('itemOwner').value=String(item?.owner_id??'');
  $('itemDue').value=item?.due_date||'';$('itemPriority').value=item?.priority||'medium';
  $('itemStatus').value=item?.status||'not_started';$('itemNotes').value=item?.notes||'';
  for(const id of ['itemName','itemDue','itemNotes'])$(id).readOnly=false;
  for(const id of ['itemOwner','itemPriority','itemStatus'])$(id).disabled=false;
  updateTaskFields();
  prepareItemDepartment(item,parent);
  $('saveItem').hidden=false;$('cancelItem').textContent='取消';
  $('itemDialog').showModal();
  $('itemName').focus();
}

$('itemLevel').addEventListener('change',()=>updateParentOptions());
$('addItem').addEventListener('click',()=>openItem());
$('cancelItem').addEventListener('click',()=>$('itemDialog').close());
$('closeItemDialog').addEventListener('click',()=>$('itemDialog').close());
$('itemDialog').addEventListener('cancel',e=>{if(state.saving)e.preventDefault();});
$('itemForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!canEditProjects()||state.saving||!$('itemForm').reportValidity())return;
  if(state.editing&&!canEditItem(itemById(state.editing.id))){$('formFeedback').textContent='目前沒有修改此項目的權限，請關閉視窗後重新確認。';return;}
  state.saving=true;$('saveItem').disabled=true;$('saveItem').classList.add('saving');
  $('saveItem').querySelector('span').textContent='儲存中…';$('formFeedback').textContent='正在儲存到 server…';$('formFeedback').classList.remove('error');
  $('cancelItem').disabled=true;$('closeItemDialog').disabled=true;
  const payload={level:$('itemLevel').value,parent_id:$('itemParent').value?Number($('itemParent').value):null,name:$('itemName').value,owner_id:$('itemOwner').value?Number($('itemOwner').value):null,notes:$('itemNotes').value};
  payload.status=$('itemStatus').value;payload.department_id=itemDepartmentValue();
  if(payload.level!=='project')payload.due_date=$('itemDue').value||null;
  if(payload.level==='task')payload.priority=$('itemPriority').value;
  if(state.editing)payload.version=state.editing.version;
  try {
    const result=await api(state.editing?'/api/items/'+state.editing.id:'/api/items',{method:state.editing?'PATCH':'POST',body:JSON.stringify(payload)});
    updateLocal(result);await loadState(true);$('itemDialog').close();saved(state.editing?'變更已儲存':'已新增「'+result.name+'」');
  } catch(error) {
    $('formFeedback').textContent=error.code==='CONFLICT'?'其他人已更新這筆資料，請關閉視窗後重新編輯。':error.message;
    $('formFeedback').classList.add('error');
    $('saveItem').disabled=error.code==='CONFLICT';
  } finally {
    state.saving=false;$('saveItem').classList.remove('saving');$('saveItem').querySelector('span').textContent=state.editing?'儲存變更':'新增';
    if(!$('formFeedback').classList.contains('error')||!$('formFeedback').textContent.includes('其他人'))$('saveItem').disabled=false;
    $('cancelItem').disabled=false;$('closeItemDialog').disabled=false;
  }
});

function branchIds(id) {
  const result=[id];for(const item of state.items)if(item.parent_id===id)result.push(...branchIds(item.id));return result;
}

function toggleBranch(id) {
  if(!state.items.some(item=>item.parent_id===id))return;
  state.collapsed.has(id)?state.collapsed.delete(id):state.collapsed.add(id);
  persistCollapse();render();
}

$('itemRows').addEventListener('click',async e=>{
  const button=e.target.closest('button[data-action]');
  if(!button){
    if(e.defaultPrevented||e.target.closest('button,a,input,select,textarea,label,[contenteditable],[role="button"],[role="link"]')||window.getSelection?.()?.toString())return;
    const row=e.target.closest('tr[data-branch-id]');
    if(row)toggleBranch(Number(row.dataset.branchId));
    return;
  }
  const item=itemById(button.dataset.id);if(!item)return;
  if(button.dataset.action==='toggle'){
    toggleBranch(item.id);
  }
  if(button.dataset.action==='view')openDetails(item,button);
  if(!canEditProjects())return;
  if(button.dataset.action==='edit')openItem({item});
  if(button.dataset.action==='child')openItem({parent:item});
  if(button.dataset.action==='archive'||button.dataset.action==='delete'){
    if(!isAdmin())return;
    const permanent=button.dataset.action==='delete';
    if(permanent&&!isRoot())return;
    const ids=branchIds(item.id), suffix=ids.length>1?`及其${permanent?'目前顯示的':''} ${ids.length-1} 個子項目`:'';
    if(!confirm(permanent?`永久刪除「${item.name}」${suffix}？\n\n所有下層資料（包含已封存的項目）也會刪除，這項操作無法復原。`:`要封存「${item.name}」${suffix}嗎？`))return;
    button.disabled=true;
    try{
      await api('/api/items/'+item.id,{method:'DELETE',body:JSON.stringify({version:item.version,cascade:true,...(permanent?{permanent:true}:{})})});
      state.items=state.items.filter(i=>!ids.includes(i.id));await loadState(true);render();saved(permanent?'項目已永久刪除':'項目已封存');
    }catch(error){toast(error.message,true);button.disabled=false;}
  }
});

$('itemRows').addEventListener('change',async e=>{
  const inline=e.target.closest('[data-inline-field]');
  if(inline){await saveInlineField(inline);return;}
  const select=e.target.closest('select[data-status-id]');if(!select)return;
  const item=itemById(select.dataset.statusId);if(item)await saveItemStatus(item,select.value,select);
});
$('detailsPanel').addEventListener('change',async e=>{
  const inline=e.target.closest('[data-inline-field]');if(inline)await saveInlineField(inline);
});
for(const container of [$('itemRows'),$('detailsPanel')])container.addEventListener('focusout',e=>{
  if(e.target.closest('[data-inline-field]'))setTimeout(()=>{if(state.user)render();},0);
});

for(const id of ['search','statusFilter','ownerFilter','projectFilter','contentFilter','departmentFilter'])$(id).addEventListener(id==='search'?'input':'change',()=>{state.collapsed.clear();render();});
$('sortBy').addEventListener('change',render);
$('collapseAll').addEventListener('click',()=>{state.collapsed=new Set(state.items.filter(i=>i.level!=='task').map(i=>i.id));persistCollapse();render();});
$('expandAll').addEventListener('click',()=>{state.collapsed.clear();persistCollapse();render();});
$('refresh').addEventListener('click',async()=>{await loadState(true);if(state.connected)toast('已同步最新資料');});
$('overview').addEventListener('click',()=>{window.scrollTo({top:0,behavior:'smooth'});});

function renderOwners(){
  $('ownersAccounts').hidden=state.user?.role!=='admin';
  const rank={admin:0,supervisor:1,member:2};
  const people=[...state.owners].sort((a,b)=>(rank[a.role]??2)-(rank[b.role]??2)||a.name.localeCompare(b.name,'zh-TW')||a.id-b.id);
  $('ownerRows').innerHTML=people.map(o=>`<div class="person-entry"><div class="account-identity"><strong>${esc(o.name)}</strong><span>${esc(o.username||'')}${o.role==='admin'?'':' · '+esc(departmentLabel(o.department_id))}</span></div><span class="role-badge ${esc(o.role)}">${roleName(o.role)}</span><span class="account-state ${o.active?'':'inactive'}">${o.active?'啟用':'停用'}</span></div>`).join('')||'<p class="muted">尚無人員。</p>';
}
$('manageOwners').addEventListener('click',()=>{renderOwners();$('ownerFeedback').textContent='';$('ownersDialog').showModal();});
$('closeOwners').addEventListener('click',()=>$('ownersDialog').close());
$('ownersAccounts').addEventListener('click',()=>{$('ownersDialog').close();$('manageAccounts').click();});

function setUser(user) {
  const previousRole=state.user?.role;
  state.user=user;
  $('addItem').hidden=!canEditProjects();
  if(previousRole&&previousRole!==user.role){
    if($('itemDialog').open)$('itemDialog').close();
    render();
  }
  $('signedInName').textContent=user.display_name;
  $('myAccount').title=`${user.username} · ${roleName(user.role)}`;
  $('manageAccounts').hidden=user.role!=='admin';
  $('systemUpdates').hidden=user.role!=='admin';
  if(typeof renderDepartments==='function')renderDepartments();
  if(typeof renderFeedbackAccess==='function')renderFeedbackAccess();
}

function showLogin(message='') {
  closeDetails(false);
  state.authGeneration++;
  statusSaving.clear();
  resetDiscussion();
  state.user=null;state.csrf=null;state.items=[];state.owners=[];state.departments=[];state.revision=null;state.editing=null;
  state.lastSaved=null;accounts=[];editingAccount=null;
  for(const dialog of document.querySelectorAll('dialog[open]')) dialog.close();
  for(const id of ['itemForm','accountForm','passwordForm','profileForm','registerForm']) $(id).reset();
  $('itemRows').replaceChildren();$('ownerRows').replaceChildren();$('accountsRows').replaceChildren();
  if(typeof resetViews==='function')resetViews();
  $('ownerFilter').innerHTML='<option value="">全部負責人</option>';
  $('contentFilter').innerHTML='<option value="">全部內容</option>';$('contentFilter').value='';$('contentFilter').hidden=true;
  $('lastSaved').textContent='資料儲存在 server';
  $('toast').hidden=true;$('workspace').hidden=true;$('authLoading').hidden=true;$('loginPanel').hidden=false;
  $('loginFeedback').textContent=message;$('loginPassword').value='';
  $('manageAccounts').hidden=true;
  $('systemUpdates').hidden=true;
  setAuthMode(false);
  stopUpdatePolling();
  if(typeof renderDepartments==='function')renderDepartments();
  if(typeof renderFeedbackAccess==='function')renderFeedbackAccess();
  if(typeof loadRegistrationDepartments==='function')loadRegistrationDepartments();
}

async function enterWorkspace(session) {
  state.authGeneration++;
  state.csrf=session.csrf_token;setUser(session.user);
  $('loginPanel').hidden=true;$('authLoading').hidden=true;$('workspace').hidden=false;
  $('loginPassword').value='';
  $('registerPassword').value='';$('registerConfirm').value='';
  await loadState(true);
}

$('loginForm').addEventListener('submit',async e=>{
  e.preventDefault();const button=$('loginSubmit');button.disabled=true;button.textContent='登入中…';$('loginFeedback').textContent='';
  try {
    const username=$('loginUsername').value.trim(),remember=$('rememberLogin').checked;
    const session=await api('/api/auth/login',{method:'POST',body:JSON.stringify({username,password:$('loginPassword').value,remember})});
    rememberAccount(username,remember);
    await enterWorkspace(session);
  }catch(error){$('loginFeedback').textContent=error.message;}
  finally{button.disabled=false;button.textContent='登入';}
});

$('myAccount').addEventListener('click',()=>{
  if(!state.user)return;
  $('profileInfo').textContent=`${state.user.display_name}（${state.user.username}） · ${roleName(state.user.role)}`;
  $('profileUsername').value=state.user.username;$('profileName').value=state.user.display_name;
  renderDepartments();
  $('profileFeedback').textContent='';$('passwordForm').reset();$('passwordFeedback').textContent='';$('profileDialog').showModal();
});
$('closeProfile').addEventListener('click',()=>$('profileDialog').close());
async function logout(){
  if(state.saving){toast('請先等候儲存完成。',true);return;}
  const dirtyDialog=document.querySelector('#itemDialog[open], #accountDialog[open]');
  if(dirtyDialog&&!confirm('登出會關閉目前尚未送出的表單，確定登出嗎？'))return;
  $('logout').disabled=true;$('sidebarLogout').disabled=true;
  try{await api('/api/auth/logout',{method:'POST',body:'{}'});showLogin('已登出。');}
  catch(error){if(state.user)toast(error.message,true);}
  finally{$('logout').disabled=false;$('sidebarLogout').disabled=false;}
}
$('logout').addEventListener('click',logout);
$('sidebarLogout').addEventListener('click',logout);
$('profileForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!$('profileForm').reportValidity())return;
  $('saveProfile').disabled=true;$('profileFeedback').textContent='';
  try{
    const result=await api('/api/auth/profile',{method:'PATCH',body:JSON.stringify({display_name:$('profileName').value.trim()})});
    setUser(result.user||result);$('profileInfo').textContent=`${state.user.display_name}（${state.user.username}） · ${roleName(state.user.role)}`;
    await loadState(true);$('profileFeedback').textContent='個人資料已儲存。';saved('個人資料已更新');
  }catch(error){$('profileFeedback').textContent=error.message;}
  finally{$('saveProfile').disabled=false;}
});
$('passwordForm').addEventListener('submit',async e=>{
  e.preventDefault();$('passwordFeedback').textContent='';
  if($('newPassword').value!==$('confirmPassword').value){$('passwordFeedback').textContent='兩次輸入的新密碼不一致。';return;}
  $('savePassword').disabled=true;
  try{
    await api('/api/auth/password',{method:'POST',body:JSON.stringify({current_password:$('currentPassword').value,password:$('newPassword').value})});
    showLogin('密碼已更新，請使用新密碼登入。');
  }catch(error){$('passwordFeedback').textContent=error.message;}
  finally{$('savePassword').disabled=false;}
});

let accounts=[], editingAccount=null;
async function loadAccounts() {
  const result=await api('/api/users');accounts=result.users;
  $('accountsCount').textContent=`${accounts.length} 個帳號`;
  $('accountsRows').innerHTML=accounts.map(u=>`<div class="account-entry"><div class="account-identity"><strong>${esc(u.display_name)}</strong><span>${esc(u.username)}${u.id===state.user?.id?' · 你':''}${u.role==='admin'?'':' · '+esc(departmentLabel(u.department_id))}</span></div><span class="role-badge ${u.role}">${roleName(u.role)}</span><span class="account-state ${u.active?'':'inactive'}">${u.active?'啟用':'停用'}</span><div class="account-actions">${u.username.toLowerCase()==='root'&&!isRoot()?'<span class="field-hint">受保護</span>':`<button class="secondary" data-edit-account="${u.id}" aria-label="編輯帳號${esc(u.username)}">編輯</button>`}${isRoot()&&u.username.toLowerCase()!=='root'&&u.id!==state.user?.id?`<button class="icon-button danger-icon" data-delete-account="${u.id}" title="永久刪除帳號" aria-label="永久刪除帳號${esc(u.username)}">${icon('trash')}</button>`:''}</div></div>`).join('');
}
$('manageAccounts').addEventListener('click',async()=>{
  $('accountsFeedback').textContent='';$('accountsRows').textContent='正在載入帳號…';$('accountsDialog').showModal();
  try{await loadAccounts();}catch(error){$('accountsFeedback').textContent=error.message;}
});
$('closeAccounts').addEventListener('click',()=>$('accountsDialog').close());
function openAccount(user=null) {
  editingAccount=user;$('accountForm').reset();$('accountFeedback').textContent='';
  $('accountTitle').textContent=user?'編輯帳號':'新增帳號';
  $('accountSubtitle').textContent=user?'修改權限、停用或重設密碼後，該帳號需重新登入。':'建立可登入這個工作空間的帳號。';
  $('accountUsername').value=user?.username||'';$('accountUsername').disabled=!!user;
  $('accountDisplayName').value=user?.display_name||'';
  $('accountRole').value=user?.role||'member';$('accountActive').checked=user?!!user.active:true;
  prepareAccountDepartments(user);
  const self=user?.id===state.user?.id;
  $('accountRole').disabled=self;$('accountActive').disabled=self;
  $('accountPassword').value='';$('accountPassword').required=!user;
  $('accountPasswordLabel').textContent=user?'重設密碼（選填）':'登入密碼 *';
  $('accountPasswordHint').textContent=user?'留空保留原密碼；填入至少 4 個字的新密碼。':'密碼至少 4 個字。';
  $('saveAccount').textContent=user?'儲存變更':'建立帳號';$('saveAccount').disabled=false;
  $('accountDialog').showModal();$('accountDisplayName').focus();
}
$('addAccount').addEventListener('click',()=>openAccount());
$('accountsRows').addEventListener('click',async e=>{
  const edit=e.target.closest('[data-edit-account]');if(edit){openAccount(accounts.find(u=>u.id===Number(edit.dataset.editAccount)));return;}
  const button=e.target.closest('[data-delete-account]');if(!button||!isRoot())return;
  const user=accounts.find(u=>u.id===Number(button.dataset.deleteAccount));if(!user)return;
  if(!confirm(`永久刪除帳號「${user.display_name}（${user.username}）」？\n\n此人的項目會保留並改為未指派，登入狀態會失效。帳號刪除後無法復原。`))return;
  button.disabled=true;
  try{await api('/api/users/'+user.id,{method:'DELETE',body:JSON.stringify({version:user.version})});await loadAccounts();await loadState(true);saved('帳號已永久刪除');}
  catch(error){$('accountsFeedback').textContent=error.message;button.disabled=false;}
});
for(const id of ['closeAccountEditor','cancelAccount'])$(id).addEventListener('click',()=>$('accountDialog').close());
$('accountForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!$('accountForm').reportValidity())return;
  $('saveAccount').disabled=true;$('accountFeedback').textContent='';
  const payload={display_name:$('accountDisplayName').value.trim(),role:$('accountRole').value,active:$('accountActive').checked,...accountDepartmentPayload()};
  if(editingAccount)payload.version=editingAccount.version;else payload.username=$('accountUsername').value.trim();
  if($('accountPassword').value)payload.password=$('accountPassword').value;
  try{
    const result=await api(editingAccount?'/api/users/'+editingAccount.id:'/api/users',{method:editingAccount?'PATCH':'POST',body:JSON.stringify(payload)});
    const self=result.id===state.user?.id;
    $('accountDialog').close();$('accountPassword').value='';
    if(self&&payload.password){showLogin('密碼已重設，請重新登入。');return;}
    if(self)setUser(result);
    await loadAccounts();await loadState(true);saved(editingAccount?'帳號已更新':'帳號已建立');
  }catch(error){$('accountFeedback').textContent=error.message;}
  finally{$('saveAccount').disabled=false;}
});

let registerMode=false;
function setAuthMode(register) {
  registerMode=register;
  $('loginForm').hidden=register;$('registerForm').hidden=!register;
  $('authTitle').textContent=register?'註冊帳號':'登入專案管理';
  $('authDescription').textContent=register?'用一個帳號管理工作，也讓團隊找得到你。':'讓每一件工作，都有清楚的下一步。';
  $('authSwitchLabel').textContent=register?'已經有帳號？':'第一次使用？';
  $('switchAuth').textContent=register?'返回登入':'註冊帳號';
  $('switchAuth').setAttribute('aria-expanded',String(register));
  if(!register){$('registerPassword').value='';$('registerConfirm').value='';}
}
function rememberAccount(username,remember) {
  try{localStorage.setItem('pm-login',JSON.stringify({username:remember?username:'',remember}));}catch{}
}
$('switchAuth').addEventListener('click',()=>{
  setAuthMode(!registerMode);$('loginFeedback').textContent='';$('registerFeedback').textContent='';
  $(registerMode?'registerUsername':'loginUsername').focus();
});
$('registerForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!$('registerForm').reportValidity())return;
  $('registerFeedback').textContent='';
  if($('registerPassword').value!==$('registerConfirm').value){$('registerFeedback').textContent='兩次輸入的密碼不一致。';return;}
  $('registerSubmit').disabled=true;$('registerSubmit').textContent='正在註冊…';
  try{
    const username=$('registerUsername').value.trim();
    const session=await api('/api/auth/register',{method:'POST',body:JSON.stringify({username,display_name:$('registerName').value.trim(),password:$('registerPassword').value,remember:true,department_id:registrationDepartmentValue()})});
    $('loginUsername').value=username;$('rememberLogin').checked=true;rememberAccount(username,true);
    await enterWorkspace(session);toast('帳號已建立，歡迎加入工作空間');
  }catch(error){$('registerFeedback').textContent=error.message;}
  finally{$('registerSubmit').disabled=false;$('registerSubmit').textContent='註冊並登入';}
});

let updateTimer=null,updateInFlight=false,updateInstalling=false,updateInfo=null,updateRequestRunning=false;
const updateBusyPhases=new Set(['queued','checking','downloading','testing','installing','starting']);
function stopUpdatePolling(){clearTimeout(updateTimer);updateTimer=null;updateInstalling=false;updateInfo=null;}
function renderUpdateStatus(info){
  updateInfo=info;
  const busy=updateBusyPhases.has(info.phase)||updateRequestRunning;
  $('currentVersion').textContent=info.version||info.current?.slice(0,12)||'開發版本';
  $('latestVersion').textContent=info.latest?.version||(info.phase==='idle'?'已是最新版本':'—');
  $('updateMessage').textContent=info.message||'尚未檢查更新。';
  $('updateMessage').classList.toggle('is-busy',busy);
  $('updateMessage').classList.toggle('is-error',info.phase==='error'||info.phase==='unavailable');
  $('updateNotesSection').hidden=!info.latest?.notes;
  $('updateNotes').textContent=info.latest?.notes||'';
  $('checkUpdates').disabled=!info.supported||busy;
  $('installUpdate').disabled=!info.supported||!info.available||!info.latest||busy;
  $('installUpdate').textContent=['downloading','testing','installing'].includes(info.phase)?'更新中…':'立即更新';
  $('reloadUpdated').hidden=info.phase!=='complete';
  if(['downloading','testing','installing'].includes(info.phase))updateInstalling=true;
  if(info.phase==='complete'||info.phase==='error')updateInstalling=false;
}
async function pollUpdateStatus(){
  if(updateInFlight||state.user?.role!=='admin')return;
  updateInFlight=true;
  try{
    const info=await api('/api/system/update');
    if(state.user?.role==='admin')renderUpdateStatus(info);
  }catch(error){
    if(state.user){
      $('updateMessage').textContent=updateInstalling?'伺服器正在切換版本，等待重新連線…':error.message;
      $('checkUpdates').disabled=true;$('installUpdate').disabled=true;
    }
  }finally{
    updateInFlight=false;clearTimeout(updateTimer);
    if(state.user?.role==='admin'&&($('updatesDialog').open||updateInstalling))updateTimer=setTimeout(pollUpdateStatus,1000);
  }
}
$('systemUpdates').addEventListener('click',()=>{
  if(state.user?.role!=='admin')return;
  if(document.querySelector('#itemDialog[open],#accountDialog[open],#profileDialog[open]')){toast('請先儲存或關閉正在填寫的表單。',true);return;}
  $('updateMessage').textContent='正在讀取更新狀態…';$('checkUpdates').disabled=true;$('installUpdate').disabled=true;
  $('updatesDialog').showModal();pollUpdateStatus();
});
$('closeUpdates').addEventListener('click',()=>$('updatesDialog').close());
$('updatesDialog').addEventListener('close',()=>{if(!updateInstalling){clearTimeout(updateTimer);updateTimer=null;}});
$('checkUpdates').addEventListener('click',async()=>{
  updateRequestRunning=true;if(updateInfo)renderUpdateStatus(updateInfo);
  try{await api('/api/system/update/check',{method:'POST',body:'{}'});$('updateMessage').textContent='已收到要求，正在檢查更新…';}
  catch(error){$('updateMessage').textContent=error.message;}
  finally{updateRequestRunning=false;await pollUpdateStatus();}
});
$('installUpdate').addEventListener('click',async()=>{
  const latest=updateInfo?.latest;if(!latest||$('installUpdate').disabled)return;
  if(state.saving||document.querySelector('#itemDialog[open],#accountDialog[open],#profileDialog[open]')){toast('請先儲存或關閉正在填寫的表單，再安裝更新。',true);return;}
  if(!confirm(`安裝版本 ${latest.version}？\n\n系統會先備份資料庫，更新期間所有人的連線會短暫中斷。請確認團隊已儲存手邊的資料。`))return;
  updateRequestRunning=true;renderUpdateStatus(updateInfo);
  try{await api('/api/system/update/install',{method:'POST',body:JSON.stringify({release:latest.release})});updateInstalling=true;$('updateMessage').textContent='已收到更新要求，正在準備…';}
  catch(error){$('updateMessage').textContent=error.message;}
  finally{updateRequestRunning=false;await pollUpdateStatus();}
});
$('reloadUpdated').addEventListener('click',()=>location.reload());
try{
  const remembered=JSON.parse(localStorage.getItem('pm-login')||'null');
  if(remembered){$('loginUsername').value=remembered.username||'';$('rememberLogin').checked=remembered.remember!==false;}
}catch{}

async function bootstrap() {
  try{const session=await api('/api/auth/me');if(session.user)await enterWorkspace(session);else showLogin();}
  catch(error){showLogin(error.message);}
}
$('serverAddress').textContent=location.host;
window.addEventListener('resize',updateDetailsPosition);
if(typeof ResizeObserver!=='undefined'){
  const detailsObserver=new ResizeObserver(updateDetailsPosition);
  for(const selector of ['.main','.filter-row','.details-panel']){
    const surface=document.querySelector(selector);if(surface)detailsObserver.observe(surface);
  }
}
bootstrap();
setInterval(()=>{if(state.user&&!document.hidden){if(!state.saving)loadState();if(state.detailsId!==null)loadDiscussion(state.detailsId);}},5000);
document.addEventListener('visibilitychange',()=>{if(state.user&&!document.hidden){loadState();if(state.detailsId!==null)loadDiscussion(state.detailsId,true);}});
