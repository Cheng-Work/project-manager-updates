'use strict';

const $ = id => document.getElementById(id);
const labels = {project:'專案',work:'內容',task:'任務',urgent:'緊急',high:'高',medium:'中',low:'低',not_started:'未開始',in_progress:'進行中',pending_review:'待審核',on_hold:'擱置',completed:'已完成',developing:'開發中',maintenance:'維護中',closed:'結案',abandoned:'廢案'};
const state = {items:[],owners:[],departments:[],revision:null,today:'',connected:false,loading:false,editing:null,saving:false,collapsed:new Set(),filteredCollapsed:null,lastSaved:null,user:null,csrf:null,authGeneration:0,detailsId:null,view:'list',timelineStart:null};
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const ownerName = id => state.owners.find(o=>o.id===id)?.name || '';
const itemById = id => state.items.find(i=>i.id===Number(id));
const overdue = item => item.level === 'task' && !!item.due_date && item.due_date < state.today && item.status !== 'completed';
const isRoot = () => state.user?.username?.toLowerCase() === 'root';
const isAdmin = () => state.user?.role === 'admin';
const roleName = role => ({admin:'管理員',supervisor:'主管',member:'一般人員'}[role]||'一般人員');
const departmentLabel = id => state.departments.find(d=>d.id===id)?.name||'未指定部門';
const itemDepartmentLabel = id => id==null?'所有部門':departmentLabel(id);
const userEditableDepartments = () => new Set([state.user?.department_id,...(state.user?.editable_department_ids||[])].filter(id=>Number.isInteger(id)));
const userAccessKey = user => JSON.stringify([user.id,user.role,user.department_id??null,[...(user.visible_department_ids||[])].sort((a,b)=>a-b),[...(user.editable_department_ids||[])].sort((a,b)=>a-b)]);
const canEditProjects = () => isAdmin() || state.user?.role === 'supervisor';
const canEditItem = item => !!item && (isAdmin() || (state.user?.role==='supervisor' && item.can_edit===true));
const canAddChildren = item => !!item && item.level!=='task' && (isAdmin() || (state.user?.role==='supervisor' && item.can_add_child===true));
const canClaimItem = item => !!item && state.user?.role==='supervisor' && item.can_claim===true;
const statuses = ['not_started','in_progress','pending_review','on_hold','completed'];
const lifecycleStatuses = ['not_started','developing','maintenance','closed','abandoned'];
const effectiveDue = item => item.level==='work'?(item.effective_due_date||item.due_date):item.due_date;
const statusSaving = new Set();
const canChangeStatus = item => !!state.user && !!item && (canEditItem(item) || (state.user.role==='member'&&item.level==='task'&&item.can_change_status===true&&item.status!=='completed'));
const allowedStatuses = item => item?.level !== 'task' ? canEditItem(item)?lifecycleStatuses:[] : canEditItem(item) ? statuses : canChangeStatus(item) ? statuses.filter(value=>value!=='completed') : [];
let toastTimer;
let detailsReturnFocus=null,detailsRenderedKey='';
const discussionRecords=new Map(),commentDrafts=new Map();
let discussionVisibleId=null;
const subtaskDrafts=new Map(),subtaskAdds=new Set(),subtaskSaves=new Map();
const subtaskReorders=new Set();
let subtaskVisibleId=null,subtaskMarkup='',subtaskDrag=null;

let pendingMutations=0,stateRequest=null,stateForceQueued=false;
const formBaselines=new Map();
function formSnapshot(form){return JSON.stringify([...form.querySelectorAll('input,select,textarea')].map(input=>[input.id,input.value,input.checked]));}
function rememberForm(id){const form=$(id);if(form)formBaselines.set(id,formSnapshot(form));}
function hasUnsavedChanges(){
  if(state.saving||pendingMutations||statusSaving.size)return true;
  if(typeof workspaceViews!=='undefined'&&(workspaceViews.draggingId!==null||workspaceViews.busy.size))return true;
  if([...discussionRecords.values()].some(record=>record.commentSending||record.deleting.size))return true;
  if([...commentDrafts.values()].some(value=>value.length)||$('commentBody').value)return true;
  if([...subtaskDrafts.values()].some(subtaskDraftChanged)||subtaskAdds.size||subtaskSaves.size||subtaskReorders.size||subtaskDrag)return true;
  if($('feedbackSubject').value||$('feedbackBody').value)return true;
  if(typeof departmentSaves!=='undefined'&&departmentSaves.size)return true;
  if($('departmentsDialog').open&&typeof departmentDrafts!=='undefined'&&[...departmentDrafts].some(([id,draft])=>draft.name!==state.departments.find(value=>value.id===id)?.name))return true;
  const forms=[...document.querySelectorAll('dialog[open] form')];
  if(!state.user)forms.push($(registerMode?'registerForm':'loginForm'));
  for(const form of forms){
    const baseline=formBaselines.get(form.id);
    if(baseline!==undefined&&formSnapshot(form)!==baseline)return true;
    if(baseline===undefined&&[...form.querySelectorAll('input,textarea')].some(input=>input.value!==input.defaultValue))return true;
  }
  const focused=document.activeElement?.closest('[data-inline-field]');
  if(focused&&!focused.disabled){
    const original=focused.tagName==='SELECT'?[...focused.options].find(option=>option.defaultSelected)?.value??focused.options[0]?.value:focused.defaultValue;
    if(focused.value!==original)return true;
  }
  return false;
}
function prepareLiveReload(){
  if(!state.user)return;
  try{sessionStorage.setItem('pm-live-view',JSON.stringify({...captureWorkspacePreferences(),userId:state.user.id,detailsId:state.detailsId,scroll:['listView','boardView','timelineView'].map(id=>[id,$(id).scrollTop,$(id).scrollLeft])}));}catch{}
}
function restoreLiveView(){
  let saved;
  try{saved=JSON.parse(sessionStorage.getItem('pm-live-view')||'null');sessionStorage.removeItem('pm-live-view');}catch{return;}
  if(!saved||saved.userId!==state.user?.id)return;
  applyWorkspacePreferences({...captureWorkspacePreferences(),...saved});
  saveWorkspacePreferences();
  render();
  const details=itemById(saved.detailsId);if(details)openDetails(details);
  setTimeout(()=>{for(const [id,top,left] of saved.scroll||[]){const control=$(id);if(control){control.scrollTop=top;control.scrollLeft=left;}}},0);
}
async function api(path, options={}) {
  const generation=state.authGeneration,writing=!['GET','HEAD'].includes((options.method||'GET').toUpperCase());
  const controller=typeof AbortController==='function'?new AbortController():null;
  const timeout=controller?setTimeout(()=>controller.abort(),writing?30000:12000):null;
  if(writing)pendingMutations++;
  try{
    let response;
    try{
      response=await fetch(path,{...options,cache:'no-store',credentials:'same-origin',signal:options.signal||controller?.signal,headers:{'Content-Type':'application/json',...(state.csrf?{'X-CSRF-Token':state.csrf}:{}),...options.headers}});
    }catch{
      if(generation===state.authGeneration)setConnection(false);
      throw new Error(controller?.signal.aborted?'連線逾時，系統會自動重新同步。':'無法連接 server，請確認伺服器仍在執行。');
    }
    const data=await response.json();
    if(generation!==state.authGeneration){const error=new Error('權限或登入狀態已更新，已忽略先前的回應。');error.code='STALE_RESPONSE';throw error;}
    if(!response.ok){
      const error=new Error(data.error||'操作失敗，請重試。');error.code=data.code;
      if(error.code==='AUTH_REQUIRED')showLogin('登入已到期或帳號已更新，請重新登入。');
      if(['CONFLICT','FORBIDDEN'].includes(error.code))await loadState(true);
      throw error;
    }
    setConnection(true);return data;
  }finally{if(timeout!==null)clearTimeout(timeout);if(writing)pendingMutations--;}
}

function setConnection(connected) {
  state.connected = connected;
  $('connectionText').textContent = connected ? '已連線' : '連線中斷';
  $('connectionDot').classList.toggle('offline', !connected);
  $('connectionError').hidden = connected;
}

function loadState(force=false){
  if(!state.user)return Promise.resolve();
  if(stateRequest){if(force)stateForceQueued=true;return stateRequest;}
  state.loading=true;
  stateRequest=(async()=>{
    let full=force;
    do{
      stateForceQueued=false;
      const generation=state.authGeneration;
      try{
        const query=!full&&state.revision!==null?'?since='+state.revision:'';
        const data=await api('/api/state'+query);
        if(generation!==state.authGeneration)continue;
        if(data.current_user)setUser(data.current_user);
        if(!data.unchanged){
          state.items=data.items;state.owners=data.owners;state.departments=data.departments||[];state.today=data.today;state.revision=data.revision;
          if(typeof renderDepartments==='function')renderDepartments();
          restoreWorkspacePreferences();render();restoreLiveView();
          if($('accountsDialog').open&&isAdmin())loadAccounts().catch(error=>{if(isAdmin())$('accountsFeedback').textContent=error.message;});
          if($('ownersDialog').open)renderOwners();
        }
      }catch(error){if(generation===state.authGeneration&&!state.items.length)$('itemRows').innerHTML=`<tr><td colspan="7" class="empty-cell">${esc(error.message)}</td></tr>`;}
      finally{full=stateForceQueued;}
    }while(stateForceQueued&&state.user);
  })().finally(()=>{state.loading=false;stateRequest=null;});
  return stateRequest;
}

const workspaceFilterIds=['departmentFilter','projectFilter','contentFilter','lifecycleFilter','statusFilter','ownerFilter'];
const accountPreferenceIds=['accountsSearch','accountsRoleFilter','accountsDepartmentFilter','accountsActiveFilter','accountsSort'];
const workspacePreferenceDefaults={search:'',sortBy:'position',accountsSearch:'',accountsRoleFilter:'',accountsDepartmentFilter:'',accountsActiveFilter:'',accountsSort:'role'};
let workspacePreferencesLoaded=false;
const workspacePreferenceKey=()=>`pm-workspace-settings:${state.user.id}`;

function captureWorkspacePreferences(){
  return {
    view:state.view,
    collapsed:[...state.collapsed],
    filteredCollapsed:state.filteredCollapsed?[...state.filteredCollapsed]:null,
    timelineStart:state.timelineStart,
    filters:Object.fromEntries([
      ...workspaceFilterIds.map(id=>[id,filterValues(id)]),
      ...Object.keys(workspacePreferenceDefaults).map(id=>[id,$(id).value])
    ])
  };
}

function saveWorkspacePreferences(){
  if(!state.user||!workspacePreferencesLoaded)return false;
  try{
    localStorage.setItem(workspacePreferenceKey(),JSON.stringify(captureWorkspacePreferences()));
    return true;
  }catch{return false;}
}

function savedCollapsed(values){
  return new Set(Array.isArray(values)?values.filter(id=>Number.isInteger(id)&&id>0):[]);
}

function applyWorkspacePreferences(saved={}){
  const filters=saved.filters&&typeof saved.filters==='object'?saved.filters:{};
  state.view=['list','board','timeline'].includes(saved.view)?saved.view:'list';
  state.collapsed=savedCollapsed(saved.collapsed);
  state.filteredCollapsed=Array.isArray(saved.filteredCollapsed)?savedCollapsed(saved.filteredCollapsed):null;
  state.timelineStart=Number.isInteger(saved.timelineStart)&&Math.abs(saved.timelineStart)<1_000_000?saved.timelineStart:null;
  for(const [id,defaultValue] of Object.entries(workspacePreferenceDefaults)){
    const control=$(id),value=filters[id];
    control.value=typeof value==='string'?value:defaultValue;
    if(control.selectedIndex===-1)control.value=defaultValue;
  }
  refreshWorkspaceFilters();
  for(const id of workspaceFilterIds){
    if(id==='contentFilter'||id==='ownerFilter')continue;
    setFilterValues(id,filters[id]??[]);
  }
  // Older live reload snapshots stored project and content states in statusFilter.
  if(typeof filters.lifecycleFilter==='undefined'&&typeof filters.statusFilter==='string'&&lifecycleStatuses.includes(filters.statusFilter)){
    setFilterValues('lifecycleFilter',[filters.statusFilter]);setFilterValues('statusFilter',[]);
  }
  refreshWorkspaceFilters();
  setFilterValues('contentFilter',filters.contentFilter??[]);
  setFilterValues('ownerFilter',filters.ownerFilter??[]);
}

function restoreWorkspacePreferences(){
  if(!state.user||workspacePreferencesLoaded)return;
  let saved={},legacy=false;
  try{
    const raw=localStorage.getItem(workspacePreferenceKey());
    if(raw){
      const parsed=JSON.parse(raw);
      if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed))saved=parsed;
    }else{
      const view=localStorage.getItem('pm-workspace-view'),collapsed=localStorage.getItem('pm-collapsed');
      legacy=!!(view||collapsed);
      saved={view,collapsed:JSON.parse(collapsed||'[]')};
    }
  }catch{/* Private browsing or a damaged preference still allows the defaults. */}
  applyWorkspacePreferences(saved);
  workspacePreferencesLoaded=true;
  if(legacy&&saveWorkspacePreferences()){
    try{localStorage.removeItem('pm-workspace-view');localStorage.removeItem('pm-collapsed');}catch{}
  }
}

function filterValues(id){
  const control=$(id);
  return control.multiple?[...control.selectedOptions].map(option=>option.value).filter(Boolean):control.value?[control.value]:[];
}
function setFilterValues(id,values){
  const selected=new Set((Array.isArray(values)?values:[values]).filter(value=>value!==null&&value!==undefined&&value!=='').map(String));
  const control=$(id);
  for(const option of control.options||[])option.selected=selected.has(option.value);
  if(!control.multiple)control.value=[...selected][0]||'';
}
function setFilterOptions(id,options){
  const control=$(id),selected=filterValues(id);
  const markup=options.map(option=>`<option value="${esc(option.value)}"${option.pinned?' data-pinned="true"':''}>${esc(option.label)}</option>`).join('');
  if(control.innerHTML!==markup)control.innerHTML=markup;
  setFilterValues(id,selected);
}
function refreshProjectFilter(){
  setFilterOptions('projectFilter',state.items.filter(item=>item.level==='project').sort(compareItems).map(item=>({value:String(item.id),label:item.name})));
}
function refreshContentFilter(){
  const projects=new Set(filterValues('projectFilter'));
  const contents=state.items.filter(item=>item.level==='work'&&projects.has(String(item.parent_id))).sort(compareItems);
  setFilterOptions('contentFilter',contents.map(item=>({value:String(item.id),label:projects.size>1?(itemById(item.parent_id)?.name||'專案')+' / '+item.name:item.name})));
  $('contentFilter').dataset.filterVisible=projects.size?'true':'false';
  if(!projects.size)setFilterValues('contentFilter',[]);
}
function pinFilterOption(options,id,tag){
  const own=options.find(option=>option.value===String(id??''));
  return own?[{...own,pinned:true,label:own.label+'（'+tag+'）'},...options.filter(option=>option!==own)]:options;
}
function refreshWorkspaceFilters(){
  const departmentOptions=state.departments.map(department=>({value:String(department.id),label:department.name}));
  setFilterOptions('departmentFilter',[...pinFilterOption(departmentOptions,state.user?.department_id,'你的部門'),{value:'unassigned',label:'共用項目（所有部門）'}]);
  refreshProjectFilter();refreshContentFilter();
  setFilterOptions('lifecycleFilter',lifecycleStatuses.map(value=>({value,label:labels[value]})));
  setFilterOptions('statusFilter',statuses.map(value=>({value,label:labels[value]})));
  const departments=new Set(filterValues('departmentFilter'));
  const sharedOnly=departments.size===1&&departments.has('unassigned');
  const owners=state.owners.filter(owner=>!departments.size||sharedOnly||departments.has(owner.department_id==null?'unassigned':String(owner.department_id)));
  const own=state.user?owners.find(owner=>owner.user_id===state.user.id):null;
  const ownerOptions=owners.map(owner=>({value:String(owner.id),label:owner.name+(owner.active?'':'（停用）')}));
  setFilterOptions('ownerFilter',[...pinFilterOption(ownerOptions,own?.id,'你自己'),{value:'unassigned',label:'未指派'}]);
  if(typeof renderFilterMenus==='function')renderFilterMenus();
}

function compareItems(a,b) {
  const sort=$('sortBy').value;
  let result=0;
  if(sort==='due_date'&&a.level!=='project'&&b.level!=='project') result=(effectiveDue(a)||'9999').localeCompare(effectiveDue(b)||'9999');
  if(sort==='priority'){
    const aTask=a.level==='task',bTask=b.level==='task';
    const rank={urgent:0,high:1,medium:2,low:3};
    result=aTask&&bTask?rank[a.priority]-rank[b.priority]:Number(aTask)-Number(bTask);
  }
  if(sort==='name') result=a.name.localeCompare(b.name,'zh-TW');
  return result || a.position-b.position || a.id-b.id;
}

function matchingItems(){
  const byId=new Map(state.items.map(item=>[item.id,item]));
  const query=$('search').value.trim().toLocaleLowerCase(),projects=new Set(filterValues('projectFilter')),contents=new Set(filterValues('contentFilter')),departments=new Set(filterValues('departmentFilter')),owners=new Set(filterValues('ownerFilter')),lifecycle=new Set(filterValues('lifecycleFilter')),taskStatuses=new Set(filterValues('statusFilter'));
  return state.items.filter(item=>{
    const ancestors=[];let current=item;
    while(current){ancestors.push(current);current=byId.get(current.parent_id);}
    if(projects.size&&!ancestors.some(parent=>parent.level==='project'&&projects.has(String(parent.id))))return false;
    if(contents.size&&!ancestors.some(parent=>parent.level==='work'&&contents.has(String(parent.id))))return false;
    if(departments.size&&item.effective_department_id!=null&&!departments.has(String(item.effective_department_id)))return false;
    if(owners.size&&!owners.has(item.owner_id===null?'unassigned':String(item.owner_id)))return false;
    if(query&&!ancestors.map(parent=>`${parent.name} ${ownerName(parent.owner_id)}`).join(' ').toLocaleLowerCase().includes(query))return false;
    if(item.level==='task'){
      if(taskStatuses.size&&!taskStatuses.has(item.status))return false;
      if(lifecycle.size&&!ancestors.some(parent=>parent.level!=='task'&&lifecycle.has(parent.status)))return false;
    }else{
      if(taskStatuses.size)return false;
      if(lifecycle.size&&!lifecycle.has(item.status))return false;
    }
    return true;
  });
}

function visibleItems(matches=matchingItems()) {
  const byId=new Map(state.items.map(i=>[i.id,i])),children=new Map(),included=new Set();
  const collapsed=currentCollapsed();
  for(const item of state.items){
    if(!children.has(item.parent_id))children.set(item.parent_id,[]);
    children.get(item.parent_id).push(item);
  }
  for(const list of children.values())list.sort(compareItems);
  for(const item of matches){
    let current=item;
    while(current){included.add(current.id);current=byId.get(current.parent_id);}
  }
  const rows=[];
  function visit(item,depth) {
    if(!included.has(item.id)) return;
    const kids=children.get(item.id)||[];
    rows.push({item,depth,hasChildren:kids.length>0});
    if(!collapsed.has(item.id)) kids.forEach(child=>visit(child,depth+1));
  }
  (children.get(null)||[]).forEach(i=>visit(i,0));
  return rows;
}

function render() {
  refreshWorkspaceFilters();
  const filtering=$('search').value.trim()||workspaceFilterIds.some(id=>filterValues(id).length);
  // Reveal matches without changing the saved, unfiltered tree.
  state.filteredCollapsed=filtering?(state.filteredCollapsed??new Set()):null;
  const tasks=state.items.filter(i=>i.level==='task'), projects=state.items.filter(i=>i.level==='project');
  $('totalTasks').textContent=tasks.length;
  $('activeTasks').textContent=tasks.filter(i=>i.status==='in_progress').length;
  $('doneTasks').textContent=tasks.filter(i=>i.status==='completed').length;
  $('reviewTasks').textContent=tasks.filter(i=>i.status==='pending_review').length;
  $('overdueTasks').textContent=tasks.filter(overdue).length;
  $('projectCount').textContent=projects.length;
  $('ownerCount').textContent=state.owners.filter(o=>o.active).length;
  $('overviewCount').textContent=`${projects.length} 個專案 · ${state.items.filter(i=>i.level==='work').length} 項內容 · ${tasks.length} 個任務`;
  const matches=matchingItems(),rows=visibleItems(matches),taskMatches=matches.filter(i=>i.level==='task').sort(compareItems);
  $('visibleCount').textContent=state.view&&state.view!=='list'?`顯示 ${taskMatches.length} 個任務`:`顯示 ${rows.length} 筆，共 ${state.items.length} 筆項目`;
  const editor=document.activeElement?.closest('#itemRows [data-inline-field], #itemRows select[data-status-id]');
  const editorItem=editor&&itemById(editor.dataset.inlineId??editor.dataset.statusId);
  const editorAllowed=editor?.dataset.statusId!==undefined?canChangeStatus(editorItem):canEditItem(editorItem);
  const preserve=editor&&!editor.disabled&&editorAllowed&&!statusSaving.has(editorItem.id)&&rows.some(row=>row.item.id===editorItem.id)?editor.closest('tr'):null;
  const markup=rows.length?rows.map(renderRow).join(''):`<tr><td colspan="7" class="empty-cell">${state.items.length?'沒有符合條件的項目，請調整篩選。':canEditProjects()?'還沒有專案，按右上方「新增」建立第一個專案。':'目前尚未建立專案。'}</td></tr>`;
  if(preserve){
    const staging=document.createElement('tbody');staging.innerHTML=markup;
    for(const row of [...$('itemRows').children])if(row!==preserve)row.remove();
    let passed=false;
    for(const row of [...staging.children]){if(row.dataset.itemId===preserve.dataset.itemId){passed=true;preserve.className=row.className;for(let index=0;index<row.children.length;index++){if(!preserve.children[index].contains(editor))preserve.children[index].innerHTML=row.children[index].innerHTML;}if(row.dataset.branchId)preserve.dataset.branchId=row.dataset.branchId;else delete preserve.dataset.branchId;}else if(passed)$('itemRows').appendChild(row);else $('itemRows').insertBefore(row,preserve);}
  }else $('itemRows').innerHTML=markup;
  if(typeof renderViews==='function')renderViews(taskMatches.map(item=>({item,context:!!item.context_only})));
  renderDetails();
}

function renderRow({item:i,depth,hasChildren}) {
  const editable=canEditItem(i),isTask=i.level==='task';
  const owner=ownerName(i.owner_id), isOverdue=overdue(i);
  const collapsed=currentCollapsed().has(i.id);
  const subtaskProgress=isTask?`<span class="subtask-count">${remainingSubtaskLabel(i.subtasks||[])} 個子任務</span>`:'';
  const toggle=hasChildren ? `<button class="tree-toggle ${collapsed?'':'expanded'}" data-action="toggle" data-id="${i.id}" aria-label="${collapsed?'展開':'收合'}${esc(i.name)}" aria-expanded="${!collapsed}">${icon('chevron')}</button>` : '<span class="tree-spacer"></span>';
  const dateText=effectiveDue(i) ? `<span class="due-cell ${isOverdue?'overdue':''}">${effectiveDue(i).replaceAll('-','/')}${i.due_date_inherited?'<span class="inherited-date">依任務日期</span>':''}${isOverdue?'<span class="overdue-note">已逾期</span>':''}</span>` : '<span class="muted">未設定</span>';
  const statusOptions=allowedStatuses(i).map(s=>`<option value="${s}" ${i.status===s?'selected':''}>${labels[s]}</option>`).join('');
  const childLabel=i.level==='project'?'內容或任務':'任務';
  const add=!canAddChildren(i) ? '' : `<button class="icon-button" data-action="child" data-id="${i.id}" title="新增${childLabel}" aria-label="在${esc(i.name)}下新增${childLabel}">${icon('plus')}</button>`;
  const remove=isRoot()?`<button class="icon-button danger-icon" data-action="delete" data-id="${i.id}" title="永久刪除" aria-label="永久刪除${esc(i.name)}">${icon('trash')}</button>`:'';
  const claim=canClaimItem(i)?`<button type="button" class="secondary claim-item" data-action="claim" data-id="${i.id}" data-version="${i.version}" ${statusSaving.has(i.id)?'disabled':''} title="取得至${esc(departmentLabel(state.user.department_id))}" aria-label="將${esc(i.name)}取得至本部門">取得</button>`:'';
  return `<tr class="${i.level}-row depth-${depth}${hasChildren?' branch-row':''}${state.detailsId===i.id?' selected-item':''}" data-item-id="${i.id}"${hasChildren?` data-branch-id="${i.id}"`:''}>
    <td><div class="item-title">${toggle}<span class="type-label">${labels[i.level]}</span><div><button class="item-name" data-action="view" data-id="${i.id}" aria-controls="detailsPanel" aria-expanded="${state.detailsId===i.id}">${esc(i.name)}</button>${subtaskProgress}</div></div></td>
    <td>${editable?inlineField(i,'owner_id'):owner?`<span class="owner-cell">${esc(owner)}</span>`:'<span class="muted">未指派</span>'}</td>
    <td>${editable?inlineField(i,'department_id'):esc(itemDepartmentLabel(i.effective_department_id))}</td>
    <td>${i.level==='project'?'':editable?inlineField(i,'due_date'):dateText}</td><td>${isTask?(editable?inlineField(i,'priority'):`<span class="priority ${i.priority}">${labels[i.priority]}</span>`):''}</td>
    <td>${canChangeStatus(i)?`<select class="status-select ${i.status}" data-status-id="${i.id}" ${statusSaving.has(i.id)?'disabled':''} aria-label="${esc(i.name)}的狀態" title="${editable?'更新狀態':'完成由管理員確認'}">${statusOptions}</select>`:`<span class="status-label ${i.status}">${labels[i.status]}</span>`}</td>
    <td><div class="row-actions"><button class="icon-button" data-action="view" data-id="${i.id}" title="查看詳情" aria-label="查看${esc(i.name)}" aria-controls="detailsPanel">${icon('list')}</button>${add}${claim}${editable?`<button class="icon-button" data-action="edit" data-id="${i.id}" title="編輯" aria-label="編輯${esc(i.name)}">${icon('edit')}</button>`:''}${isAdmin()?`<button class="icon-button" data-action="archive" data-id="${i.id}" title="封存" aria-label="封存${esc(i.name)}">${icon('archive')}</button>${remove}`:''}</div></td></tr>`;
}

function itemOwnerOptions(departmentId,selectedId=null,existingId=null){
  const options=['<option value="">未指派</option>'];
  for(const owner of state.owners){
    const matchesDepartment=departmentId==null||owner.department_id===departmentId;
    const eligible=owner.active&&matchesDepartment;
    const selected=owner.id===selectedId;
    if(!eligible&&!(selected&&owner.id===existingId))continue;
    const notes=[];
    if(!matchesDepartment)notes.push('其他部門');
    if(!owner.active)notes.push('停用');
    const label=owner.name+(notes.length?'（'+notes.join('、')+'）':'');
    options.push(`<option value="${owner.id}"${selected?' selected':''}${eligible?'':' disabled'}>${esc(label)}</option>`);
  }
  return options.join('');
}

function inlineField(item,field) {
  const fieldName={owner_id:'負責人',department_id:'部門',due_date:'預計完成日期',priority:'優先度'}[field];
  const attributes=`data-inline-id="${item.id}" data-inline-field="${field}" data-version="${item.version}" aria-label="${esc(item.name)}的${fieldName}" ${statusSaving.has(item.id)?'disabled':''}`;
  if(field==='due_date')return `<input type="date" class="inline-field inline-date${overdue(item)?' overdue':''}" ${attributes} value="${esc(effectiveDue(item)||'')}">${item.due_date_inherited?'<span class="inherited-date">依任務自動帶入</span>':''}`;
  if(field==='owner_id')return `<select class="inline-field inline-owner" ${attributes}>${itemOwnerOptions(item.effective_department_id,item.owner_id,item.owner_id)}</select>`;
  if(field==='department_id'){
    const parent=itemById(item.parent_id),inherited=parent?.effective_department_id??null,supervisor=state.user?.role==='supervisor';
    const editDepartments=userEditableDepartments();
    const choices=state.departments.filter(d=>!supervisor||editDepartments.has(d.id));
    const blankDisabled=supervisor&&!editDepartments.has(inherited);
    const defaultDepartment=parent?'沿用：'+itemDepartmentLabel(inherited):itemDepartmentLabel(null);
    return `<select class="inline-field inline-department" ${attributes}><option value=""${item.department_id===null?' selected':''}${blankDisabled?' disabled':''}>${esc(defaultDepartment)}</option>${choices.map(d=>`<option value="${d.id}"${d.id===item.department_id?' selected':''}>${esc(d.name)}</option>`).join('')}</select>`;
  }
  return `<select class="inline-field inline-priority priority ${item.priority}" ${attributes}>${['urgent','high','medium','low'].map(value=>`<option value="${value}"${value===item.priority?' selected':''}>${labels[value]}</option>`).join('')}</select>`;
}

function renderDetailFields(item) {
  const isTask=item.level==='task';
  $('detailsDueRow').hidden=item.level==='project';$('detailsPriorityRow').hidden=!isTask;$('detailsStatusRow').hidden=false;
  const focused=document.activeElement?.closest('#detailsPanel [data-inline-field]');
  if(canEditItem(item)){
    for(const [id,field,visible] of [['detailsOwner','owner_id',true],['detailsDepartment','department_id',true],['detailsDue','due_date',item.level!=='project'],['detailsPriority','priority',isTask]]){
      const target=$(id);if(focused&&!focused.disabled&&focused.dataset.inlineId===String(item.id)&&!statusSaving.has(item.id)&&target.contains(focused))continue;
      target.className='';target.innerHTML=visible?inlineField(item,field):'';
    }
  }else{
    $('detailsOwner').textContent=ownerName(item.owner_id)||'未指派';
    $('detailsDepartment').textContent=itemDepartmentLabel(item.effective_department_id);
    $('detailsDue').textContent=effectiveDue(item)?effectiveDue(item).replaceAll('-','/')+(item.due_date_inherited?'（依任務）':''):'未設定';
    $('detailsPriority').textContent=labels[item.priority];$('detailsPriority').className='priority '+item.priority;
  }
  $('detailsDue').classList.toggle('overdue',overdue(item));
}

async function saveInlineField(control) {
  if(!canEditProjects()||control.disabled)return;
  const item=itemById(control.dataset.inlineId),field=control.dataset.inlineField,generation=state.authGeneration;
  if(!canEditItem(item)||!['owner_id','department_id','due_date','priority'].includes(field))return;
  if((item.level==='project'&&!['owner_id','department_id'].includes(field))||(item.level==='work'&&field==='priority'))return;
  if(control.reportValidity&&!control.reportValidity())return;
  const value=['owner_id','department_id'].includes(field)?(control.value?Number(control.value):null):control.value||null;
  if(item[field]===value)return;
  if(statusSaving.has(item.id)){toast('此項目正在儲存，請稍候。',true);return;}
  statusSaving.add(item.id);control.disabled=true;render();
  try{
    const updated=await api('/api/items/'+item.id,{method:'PATCH',body:JSON.stringify({version:Number(control.dataset.version),[field]:value})});
    if(generation!==state.authGeneration)return;
    updateLocal(updated);if(['due_date','department_id'].includes(field))await loadState(true);if(generation!==state.authGeneration)return;saved('已更新'+{owner_id:'負責人',department_id:'部門',due_date:'預計完成日期',priority:'優先度'}[field]);
  }catch(error){if(generation===state.authGeneration)toast(error.message,true);}
  finally{if(generation===state.authGeneration){statusSaving.delete(item.id);render();}}
}

async function claimItem(item,button){
  if(!canClaimItem(item)||statusSaving.has(item.id))return;
  const generation=state.authGeneration;
  statusSaving.add(item.id);button.disabled=true;render();
  try{
    const updated=await api('/api/items/'+item.id,{method:'PATCH',body:JSON.stringify({version:Number(button.dataset.version),department_id:state.user.department_id})});
    if(generation!==state.authGeneration)return;
    updateLocal(updated);await loadState(true);if(generation===state.authGeneration)saved('已取得至'+departmentLabel(state.user.department_id));
  }catch(error){if(generation===state.authGeneration)toast(error.message,true);}
  finally{if(generation===state.authGeneration){statusSaving.delete(item.id);render();}}
}

function currentCollapsed() {
  return state.filteredCollapsed??state.collapsed;
}

function toast(message,error=false) {
  clearTimeout(toastTimer);$('toast').hidden=false;$('toast').classList.toggle('error',error);$('toast').querySelector('span').textContent=message;
  toastTimer=setTimeout(()=>$('toast').hidden=true,4000);
}

function saved(message) {
  state.lastSaved=Date.now();$('lastSaved').textContent='剛剛已儲存';toast(message);
}

function updateLocal(item) {
  const index=state.items.findIndex(i=>i.id===item.id);
  if(index<0) state.items.push(item);else state.items[index]={...state.items[index],...item};
  const collapsed=currentCollapsed();
  let parent=item.parent_id;
  while(parent!==null){collapsed.delete(parent);parent=itemById(parent)?.parent_id??null;}
  render();
}

function openDetails(item,trigger=document.activeElement) {
  if(!state.user||!item)return;
  const panel=$('detailsPanel');
  if(panel.hidden||!panel.contains(trigger))detailsReturnFocus=trigger;
  const changed=state.detailsId!==item.id;
  if(changed)saveCommentDraft();
  state.detailsId=item.id;
  panel.hidden=false;$('workspace').classList.add('has-details');
  if(changed){detailsRenderedKey='';$('detailsFeedback').textContent='';}
  render();
  if(!document.querySelector('dialog[open]'))$('detailsTitle').focus({preventScroll:true});
}

function closeDetails(restoreFocus=true) {
  saveCommentDraft();discussionVisibleId=null;
  clearSubtaskDrag();
  subtaskVisibleId=null;
  $('commentBody').value='';
  const previousId=state.detailsId;
  state.detailsId=null;detailsRenderedKey='';
  $('detailsPanel').hidden=true;$('workspace').classList.remove('has-details');$('workspace').classList.remove('details-push');
  for(const row of $('itemRows').querySelectorAll('.selected-item'))row.classList.remove('selected-item');
  for(const button of $('itemRows').querySelectorAll('.item-name[data-action="view"]'))button.setAttribute('aria-expanded','false');
  if(restoreFocus){
    const fallback=$('itemRows').querySelector(`[data-action="view"][data-id="${previousId}"]`);
    const target=detailsReturnFocus?.isConnected&&!detailsReturnFocus.closest('#detailsPanel')?detailsReturnFocus:fallback||$('search');
    target.focus({preventScroll:true});
  }
  detailsReturnFocus=null;
}

function renderDetails() {
  if(state.detailsId===null)return;
  const item=itemById(state.detailsId);
  if(!item){closeDetails($('detailsPanel').contains(document.activeElement));return;}
  const ancestors=[];let parent=itemById(item.parent_id);
  while(parent){ancestors.unshift(parent);parent=itemById(parent.parent_id);}
  $('detailsLevel').textContent=labels[item.level];
  $('detailsTitle').textContent=item.name;
  $('detailsBreadcrumb').textContent=ancestors.length?ancestors.map(i=>i.name).join(' / '):'專案總覽';
  renderDetailFields(item);
  $('detailsNotes').textContent=item.notes||'尚無說明';
  $('detailsNotes').classList.toggle('empty-description',!item.notes);
  renderSubtasks(item);
  $('editDetails').hidden=!canEditItem(item);
  $('claimDetails').hidden=!canClaimItem(item);$('claimDetails').disabled=statusSaving.has(item.id);$('claimDetails').dataset.version=item.version;
  const status=$('detailsStatus'),options=allowedStatuses(item);
  const disabled=!canChangeStatus(item)||statusSaving.has(item.id);
  const key=JSON.stringify([item.id,item.status,options]);
  const keepStatus=status===document.activeElement&&!disabled&&status.dataset.itemId===String(item.id);
  if(key!==detailsRenderedKey&&!keepStatus){
    status.innerHTML=options.length?options.map(value=>`<option value="${value}"${value===item.status?' selected':''}>${labels[value]}</option>`).join(''):`<option value="${item.status}" selected disabled>${labels[item.status]}</option>`;
    status.value=item.status;
    status.dataset.itemId=String(item.id);
    detailsRenderedKey=key;
  }
  if(status.disabled!==disabled)status.disabled=disabled;
  const statusClass='status-select details-status '+item.status;
  if(!keepStatus&&status.className!==statusClass)status.className=statusClass;
  $('detailsStatusHint').textContent=state.user?.role==='supervisor'&&!canEditItem(item)?'此項目僅供查看，尚未授權修改此部門。':item.level!=='task'?'專案與內容的狀態由管理員或獲授權的主管調整。':canEditItem(item)?'待審核任務可確認為已完成。':item.status==='completed'?'此任務已完成，僅管理員或獲授權的主管可以調整。':canChangeStatus(item)?'完成任務後請設為待審核，也可將任務設為擱置。':'此項目僅供查看。';
  const children=state.items.filter(i=>i.parent_id===item.id).sort(compareItems);
  $('detailsChildrenSection').hidden=!children.length;
  $('detailsChildren').innerHTML=children.map(child=>`<button type="button" class="details-child" data-detail-id="${child.id}"><span><span class="details-child-type">${labels[child.level]}</span><strong>${esc(child.name)}</strong></span><span class="status-label ${child.status}">${labels[child.status]}</span>${icon('chevron')}</button>`).join('');
  updateDetailsPosition();
  syncDiscussionItem(item.id);
}

function remainingSubtaskLabel(subtasks){
  const member=state.user?.role==='member';
  const remaining=subtasks.filter(subtask=>member
    ?!subtask.completed||subtask.checked_by_user_id!==state.user.id
    :!subtask.confirmed).length;
  const label=member?'你尚未勾選':'未確認';
  return `${label} ${remaining}/${subtasks.length}`;
}

function subtaskDraftChanged(draft){
  return draft.title.trim()!==draft.originalTitle;
}

function renderSubtaskEntry(subtask,editable){
  const title=esc(subtask.title);
  const edit=editable?`<button type="button" class="icon-button" data-edit-subtask="${subtask.id}" aria-label="修改子任務：${title}" title="修改名稱">${icon('edit')}</button>`:'';
  const review=editable?'<button type="button" class="subtask-review" data-review-subtask hidden></button>':'';
  const remove=editable?`<button type="button" class="icon-button danger-icon" data-remove-subtask aria-label="移除子任務：${title}" title="移除">${icon('trash')}</button>`:'';
  const grip=editable?`<button type="button" class="icon-button subtask-grip" data-reorder-subtask="${subtask.id}" aria-label="排序子任務：${title}" title="拖曳排序，也可用上下方向鍵" draggable="true">${icon('grip')}</button>`:'';
  const editor=editable?`<div class="subtask-editor" data-subtask-editor="${subtask.id}"></div>`:'';
  return `<li><div class="subtask-row" data-subtask-row="${subtask.id}"><div class="subtask-main"><label><input type="checkbox" data-subtask-id="${subtask.id}" aria-label="勾選完成：${title}"><span class="subtask-name">${title}</span></label>${editor}</div><div class="subtask-actions"><span class="subtask-stage" hidden></span>${review}${edit}${remove}${grip}</div></div></li>`;
}

function renderSubtasks(item){
  const isTask=item.level==='task',editable=canEditItem(item);
  $('subtaskSection').hidden=!isTask;
  const visibleId=isTask?item.id:null;
  if(subtaskDrag){
    if(subtaskDrag.taskId===visibleId&&editable)return;
    clearSubtaskDrag();
  }
  if(subtaskVisibleId!==visibleId){
    subtaskVisibleId=visibleId;
    $('subtaskTitle').value=subtaskDrafts.get(visibleId)?.title||'';
    $('subtaskFeedback').textContent='';
  }
  if(!isTask)return;
  const subtasks=item.subtasks||[];
  $('subtaskCount').textContent=remainingSubtaskLabel(subtasks);
  $('subtaskEmpty').hidden=!!subtasks.length;
  const byId=new Map(subtasks.map(subtask=>[subtask.id,subtask]));
  const markup=subtasks.map(subtask=>renderSubtaskEntry(subtask,editable)).join('');
  const list=$('subtaskList'),form=$('subtaskForm'),home=$('subtaskFormHome');
  const formFocused=document.activeElement===$('subtaskTitle');
  if(markup!==subtaskMarkup){
    if(list.contains(form))home.append(form);
    list.innerHTML=markup;subtaskMarkup=markup;
  }
  let draft=editable?subtaskDrafts.get(item.id):null;
  if(draft?.id!=null&&!byId.has(draft.id)){
    subtaskDrafts.delete(item.id);draft=null;
    $('subtaskTitle').value='';
    $('subtaskFeedback').textContent='這個子任務已被移除。';
  }
  const editing=draft?.id!=null;
  const target=(editing&&list.querySelector(`[data-subtask-editor="${draft.id}"]`))||home;
  if(form.parentElement!==target)target.append(form);
  form.hidden=!draft;
  if(draft&&formFocused&&document.activeElement!==$('subtaskTitle'))$('subtaskTitle').focus({preventScroll:true});
  const busy=subtaskAdds.has(item.id)||(editing&&subtaskSaves.has(draft.id));
  $('subtaskTitle').readOnly=busy;
  $('newSubtask').hidden=!editable||!!draft;
  $('addSubtask').textContent=editing?'儲存':'新增';
  $('addSubtask').disabled=busy||!draft?.title.trim()||!subtaskDraftChanged(draft);
  $('cancelSubtask').disabled=busy;
  const reorderBlocked=subtaskReorders.has(item.id)||subtaskAdds.has(item.id)||editing;
  for(const row of list.querySelectorAll('[data-subtask-row]')){
    const id=Number(row.dataset.subtaskRow),subtask=byId.get(id),pending=subtaskSaves.get(id);
    const editingRow=draft?.id===id;
    const completed=pending?.completed??subtask.completed,confirmed=pending?.confirmed??subtask.confirmed;
    const checkbox=row.querySelector('[data-subtask-id]'),stage=row.querySelector('.subtask-stage');
    checkbox.checked=completed;
    checkbox.disabled=!!pending||confirmed||editingRow;
    row.classList.toggle('is-confirmed',confirmed);
    row.classList.toggle('is-editing',editingRow);
    row.querySelector('.subtask-actions').hidden=editingRow;
    stage.hidden=editable||!completed;
    stage.textContent=confirmed?'已確認':'待確認';
    const review=row.querySelector('[data-review-subtask]');
    if(review){
      review.hidden=!completed;review.disabled=!!pending;
      review.textContent=confirmed?'已確認':'確認';
      review.title=confirmed?'取消確認':'確認完成';
      review.setAttribute('aria-label',review.title+'：'+subtask.title);
      row.querySelector('[data-edit-subtask]').disabled=!!pending;
      row.querySelector('[data-remove-subtask]').disabled=!!pending;
      const grip=row.querySelector('[data-reorder-subtask]');
      grip.hidden=subtasks.length<2;
      grip.disabled=reorderBlocked||!!pending;
      grip.draggable=!grip.disabled;
    }
  }
}

function openSubtaskForm(item,subtask=null){
  if(item?.level!=='task'||!canEditItem(item)||subtaskAdds.has(item.id))return;
  const previous=subtaskDrafts.get(item.id),id=subtask?.id??null;
  if(previous?.id===id){$('subtaskTitle').focus();return;}
  if(previous&&(subtaskDraftChanged(previous)||subtaskSaves.has(previous.id))){
    toast('請先儲存或取消目前的子任務修改。',true);
    return;
  }
  const title=subtask?.title||'';
  subtaskDrafts.set(item.id,{id,title,originalTitle:title});
  $('subtaskTitle').value=title;
  $('subtaskFeedback').textContent='';
  renderSubtasks(item);
  $('subtaskTitle').focus();
}

async function saveSubtask(item,method,subtaskId=null,payload={}){
  const generation=state.authGeneration,adding=method==='POST',renaming=method==='PATCH'&&'title' in payload;
  if(adding?subtaskAdds.has(item.id):subtaskSaves.has(subtaskId))return;
  if(adding)subtaskAdds.add(item.id);else subtaskSaves.set(subtaskId,payload);
  $('subtaskFeedback').textContent='';
  renderSubtasks(item);
  const path='/api/items/'+item.id+'/subtasks'+(adding?'':'/'+subtaskId);
  try{
    await api(path,{method,body:JSON.stringify(payload)});
    if(generation!==state.authGeneration)return;
    const draft=subtaskDrafts.get(item.id);
    if((adding||renaming)&&draft?.id===subtaskId&&draft.title.trim()===payload.title){
      if(renaming)subtaskDrafts.delete(item.id);else draft.title='';
      if(state.detailsId===item.id)$('subtaskTitle').value='';
    }
    await loadState(true);
  }catch(error){
    if(generation===state.authGeneration&&state.detailsId===item.id)$('subtaskFeedback').textContent=error.message;
  }finally{
    if(generation===state.authGeneration){
      if(adding)subtaskAdds.delete(item.id);else subtaskSaves.delete(subtaskId);
      const current=itemById(item.id);
      if(current&&state.detailsId===item.id)renderSubtasks(current);
    }
  }
}

$('subtaskTitle').addEventListener('input',()=>{
  const draft=subtaskDrafts.get(subtaskVisibleId);
  if(!draft)return;
  draft.title=$('subtaskTitle').value;
  $('addSubtask').disabled=subtaskAdds.has(subtaskVisibleId)||subtaskSaves.has(draft.id)||!draft.title.trim()||!subtaskDraftChanged(draft);
});
$('newSubtask').addEventListener('click',()=>openSubtaskForm(itemById(subtaskVisibleId)));
$('cancelSubtask').addEventListener('click',()=>{
  const item=itemById(subtaskVisibleId),draft=subtaskDrafts.get(subtaskVisibleId);
  if(!item||!draft||subtaskAdds.has(item.id)||subtaskSaves.has(draft.id))return;
  subtaskDrafts.delete(item.id);
  $('subtaskTitle').value='';
  $('subtaskFeedback').textContent='';
  renderSubtasks(item);
  const trigger=draft.id===null?$('newSubtask'):$('subtaskList').querySelector(`[data-edit-subtask="${draft.id}"]`);
  trigger?.focus({preventScroll:true});
});
$('subtaskForm').addEventListener('submit',event=>{
  event.preventDefault();
  const item=itemById(subtaskVisibleId),draft=subtaskDrafts.get(subtaskVisibleId),title=draft?.title.trim();
  if(title&&subtaskDraftChanged(draft)&&item?.level==='task'&&canEditItem(item)){
    saveSubtask(item,draft.id===null?'POST':'PATCH',draft.id,{title});
  }
});
$('subtaskForm').addEventListener('keydown',event=>{
  if(event.key!=='Escape'||event.isComposing)return;
  event.preventDefault();event.stopPropagation();
  if(!$('cancelSubtask').disabled)$('cancelSubtask').click();
});
$('subtaskList').addEventListener('change',event=>{
  const input=event.target.closest('[data-subtask-id]'),item=itemById(subtaskVisibleId);
  if(input&&item?.level==='task')saveSubtask(item,'PATCH',Number(input.dataset.subtaskId),{completed:input.checked});
});
$('subtaskList').addEventListener('click',event=>{
  const button=event.target.closest('[data-edit-subtask],[data-review-subtask],[data-remove-subtask]'),item=itemById(subtaskVisibleId);
  if(!button||item?.level!=='task'||!canEditItem(item))return;
  const id=Number(button.closest('[data-subtask-row]').dataset.subtaskRow);
  const subtask=item.subtasks?.find(entry=>entry.id===id);
  if(!subtask)return;
  if(button.hasAttribute('data-edit-subtask'))openSubtaskForm(item,subtask);
  else if(button.hasAttribute('data-review-subtask'))saveSubtask(item,'PATCH',id,{confirmed:!subtask.confirmed});
  else if(confirm(`要移除子任務「${subtask.title}」嗎？`))saveSubtask(item,'DELETE',id);
});

function clearSubtaskDrag(){
  if(!subtaskDrag)return;
  subtaskDrag.source.classList.remove('is-dragging');
  subtaskDrag.target?.classList.remove('drop-before','drop-after');
  subtaskDrag=null;
}

function nextSubtaskOrder(ids,sourceId,targetId,after){
  if(sourceId===targetId||!ids.includes(sourceId)||!ids.includes(targetId))return ids;
  const sorted=ids.filter(id=>id!==sourceId);
  sorted.splice(sorted.indexOf(targetId)+(after?1:0),0,sourceId);
  return sorted;
}

async function reorderSubtasks(item,expected,ordered,keyboardId=null){
  if(!canEditItem(item)||subtaskReorders.has(item.id)||ordered.every((id,index)=>expected[index]===id))return;
  const generation=state.authGeneration;
  subtaskReorders.add(item.id);
  $('subtaskFeedback').textContent='';
  renderSubtasks(item);
  try{
    await api('/api/items/'+item.id+'/subtasks/order',{method:'PATCH',body:JSON.stringify({expected_ids:expected,ordered_ids:ordered})});
    if(generation===state.authGeneration)await loadState(true);
  }catch(error){
    if(generation===state.authGeneration&&error.code==='CONFLICT')await loadState(true);
    if(generation===state.authGeneration&&state.detailsId===item.id)$('subtaskFeedback').textContent=error.message;
  }finally{
    if(generation===state.authGeneration){
      subtaskReorders.delete(item.id);
      const current=itemById(item.id);
      if(current&&state.detailsId===item.id){
        renderSubtasks(current);
        const list=$('subtaskList');
        if(keyboardId!==null&&(document.activeElement===document.body||list.contains(document.activeElement))){
          list.querySelector(`[data-reorder-subtask="${keyboardId}"]`)?.focus({preventScroll:true});
        }
      }
    }
  }
}

$('subtaskList').addEventListener('dragstart',event=>{
  const grip=event.target.closest('[data-reorder-subtask]'),item=itemById(subtaskVisibleId);
  if(!grip||grip.disabled||!canEditItem(item)||!event.dataTransfer)return;
  const source=grip.closest('[data-subtask-row]');
  subtaskDrag={taskId:item.id,source,id:Number(grip.dataset.reorderSubtask),ids:item.subtasks.map(entry=>entry.id),target:null,after:false};
  source.classList.add('is-dragging');
  event.dataTransfer.effectAllowed='move';
  event.dataTransfer.setData('application/x-project-manager-subtask',String(subtaskDrag.id));
});
$('subtaskList').addEventListener('dragover',event=>{
  if(!subtaskDrag)return;
  const row=event.target.closest('[data-subtask-row]');
  subtaskDrag.target?.classList.remove('drop-before','drop-after');
  subtaskDrag.target=null;
  if(!row||row===subtaskDrag.source)return;
  event.preventDefault();event.dataTransfer.dropEffect='move';
  const bounds=row.getBoundingClientRect();
  subtaskDrag.target=row;
  subtaskDrag.after=event.clientY>bounds.top+bounds.height/2;
  row.classList.add(subtaskDrag.after?'drop-after':'drop-before');
});
$('subtaskList').addEventListener('drop',event=>{
  const drag=subtaskDrag;
  if(!drag)return;
  event.preventDefault();
  const target=event.target.closest('[data-subtask-row]');
  const item=itemById(drag.taskId);
  clearSubtaskDrag();
  if(!item||state.detailsId!==item.id)return;
  if(!target||target===drag.source){renderSubtasks(item);return;}
  const bounds=target.getBoundingClientRect();
  const ordered=nextSubtaskOrder(drag.ids,drag.id,Number(target.dataset.subtaskRow),event.clientY>bounds.top+bounds.height/2);
  if(ordered.every((id,index)=>drag.ids[index]===id))renderSubtasks(item);
  else reorderSubtasks(item,drag.ids,ordered);
});
$('subtaskList').addEventListener('dragend',()=>{
  const item=itemById(subtaskDrag?.taskId);
  clearSubtaskDrag();
  if(item&&state.detailsId===item.id)renderSubtasks(item);
});
$('subtaskList').addEventListener('keydown',event=>{
  const grip=event.target.closest('[data-reorder-subtask]'),item=itemById(subtaskVisibleId);
  if(!grip||grip.disabled||!item||!['ArrowUp','ArrowDown'].includes(event.key))return;
  event.preventDefault();
  const ids=item.subtasks.map(entry=>entry.id),id=Number(grip.dataset.reorderSubtask);
  const after=event.key==='ArrowDown',targetId=ids[ids.indexOf(id)+(after?1:-1)];
  if(targetId!==undefined)reorderSubtasks(item,ids,nextSubtaskOrder(ids,id,targetId,after),id);
});

function resetSubtasks(){
  clearSubtaskDrag();subtaskReorders.clear();
  subtaskDrafts.clear();subtaskAdds.clear();subtaskSaves.clear();subtaskVisibleId=null;
  $('subtaskTitle').value='';
}

function updateDetailsPosition() {
  const panel=$('detailsPanel'),workspace=$('workspace'),main=document.querySelector('.main'),filters=document.querySelector('.filter-row');
  if(panel.hidden||!main||!filters)return;
  const width=panel.getBoundingClientRect().width,mainStyle=getComputedStyle(main),filterStyle=getComputedStyle(filters);
  const controls=[...filters.querySelectorAll('.filter-field'),...filters.querySelectorAll('select')].filter(control=>control.getClientRects().length);
  const controlsWidth=controls.reduce((sum,control)=>sum+control.getBoundingClientRect().width,0);
  const gap=parseFloat(filterStyle.columnGap)||0;
  const minimum=Math.max(640,controlsWidth+gap*Math.max(0,controls.length-1));
  const available=workspace.clientWidth-main.getBoundingClientRect().left-(parseFloat(mainStyle.paddingLeft)||0)-(parseFloat(mainStyle.paddingRight)||0)-width;
  const push=window.innerWidth>1200&&available>=minimum;
  const nextWidth=Math.round(width)+'px';
  if(workspace.style.getPropertyValue('--details-width')!==nextWidth)workspace.style.setProperty('--details-width',nextWidth);
  if(workspace.classList.contains('details-push')!==push)workspace.classList.toggle('details-push',push);
  if(panel.style.getPropertyValue('--details-top')!=='0px')panel.style.setProperty('--details-top','0px');
}

function discussionRecord(id) {
  if(!discussionRecords.has(id))discussionRecords.set(id,{comments:[],loaded:false,error:'',fetchedAt:0,fetching:null,request:0,commentSending:false,commentFeedback:'',deleting:new Set(),commentsMarkup:null});
  return discussionRecords.get(id);
}

function saveCommentDraft() {
  if(discussionVisibleId===null)return;
  const value=$('commentBody').value;
  if(value)commentDrafts.set(discussionVisibleId,value);else commentDrafts.delete(discussionVisibleId);
}

function resetDiscussion() {
  discussionRecords.clear();commentDrafts.clear();discussionVisibleId=null;
  $('commentBody').value='';
  $('commentList').replaceChildren();
  $('commentFeedback').textContent='';
}

function syncDiscussionItem(id) {
  if(discussionVisibleId!==id){
    saveCommentDraft();discussionVisibleId=id;
    $('commentBody').value=commentDrafts.get(id)||'';
    const record=discussionRecord(id);record.commentsMarkup=null;
    renderDiscussion(id);loadDiscussion(id);
  }else renderDiscussion(id);
}

function discussionTime(value) {
  const parsed=new Date(typeof value==='number'?value*1000:value);
  return Number.isNaN(parsed.getTime())?'':parsed.toLocaleString('zh-TW',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
}

function commentTextWithLinks(body) {
  const text=String(body??'');
  const candidates=/(?:https?:\/\/|www\.)[^\s<>"'，。！？；：、）］｝」』》〉】]+/giu;
  const closing={'(':')','[':']','{':'}'};
  let markup='',offset=0;
  for(const match of text.matchAll(candidates)){
    if(match.index>0&&/[\w@/.]/.test(text[match.index-1]))continue;
    const candidate=match[0].replace(/[.,!?;:]+$/,'');
    const extra={')':0,']':0,'}':0};
    for(const char of candidate){
      if(closing[char])extra[closing[char]]--;
      else if(char in extra)extra[char]++;
    }
    let end=candidate.length;
    while(extra[candidate[end-1]]>0)extra[candidate[--end]]--;
    const label=candidate.slice(0,end);
    try{
      const url=new URL(/^www\./i.test(label)?'https://'+label:label);
      if((url.protocol!=='http:'&&url.protocol!=='https:')||!url.hostname||url.username||url.password)continue;
      markup+=esc(text.slice(offset,match.index));
      markup+=`<a href="${esc(url.href)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>`;
      offset=match.index+label.length;
    }catch{ /* Keep malformed URLs as plain text. */ }
  }
  return markup+esc(text.slice(offset));
}

function renderDiscussion(id) {
  if(!state.user||state.detailsId!==id||discussionVisibleId!==id||$('detailsPanel').hidden)return;
  const record=discussionRecord(id);
  const placeholder=record.error||(!record.loaded?'正在載入…':'');
  const comments=[...record.comments].sort((a,b)=>String(a.created_at).localeCompare(String(b.created_at))||a.id-b.id);
  const commentMarkup=comments.map(comment=>`<article class="comment-entry"><div class="comment-heading"><strong>${esc(comment.author_name)}</strong><time datetime="${esc(comment.created_at)}">${esc(discussionTime(comment.created_at))}</time>${comment.can_delete?`<button type="button" class="icon-button danger-icon" data-delete-comment="${comment.id}" ${record.deleting.has('comment:'+comment.id)?'disabled':''} aria-label="刪除${esc(comment.author_name)}的留言" title="刪除留言">${icon('trash')}</button>`:''}</div><p class="comment-body">${commentTextWithLinks(comment.body)}</p></article>`).join('')+(placeholder?`<p class="collaboration-empty ${record.error?'collaboration-error':''}">${esc(placeholder)}</p>`:!comments.length?'<p class="collaboration-empty">還沒有留言，開始和團隊討論吧。</p>':'');
  if(record.commentsMarkup!==commentMarkup){$('commentList').innerHTML=commentMarkup;record.commentsMarkup=commentMarkup;}
  renderDiscussionControls(id);
}

function renderDiscussionControls(id) {
  if(state.detailsId!==id||discussionVisibleId!==id)return;
  const record=discussionRecord(id);
  $('sendComment').disabled=record.commentSending||!(commentDrafts.get(id)||'').trim();
  $('sendComment').textContent=record.commentSending?'送出中…':'送出留言';
  $('commentFeedback').textContent=record.commentFeedback;
}

async function loadDiscussion(id,force=false) {
  if(!state.user||!itemById(id))return;
  const record=discussionRecord(id);
  if(record.fetching)return record.fetching;
  if(!force&&record.loaded&&Date.now()-record.fetchedAt<1800)return;
  const generation=state.authGeneration,request=++record.request;
  const pending=(async()=>{
    try{
      const result=await api('/api/items/'+id+'/discussion');
      if(generation!==state.authGeneration||request!==record.request)return;
      record.comments=result.comments;record.loaded=true;record.error='';record.fetchedAt=Date.now();
      renderDiscussion(id);
    }catch(error){
      if(generation===state.authGeneration&&request===record.request){record.error=error.message;record.fetchedAt=Date.now();renderDiscussion(id);}
    }finally{
      if(record.fetching===pending)record.fetching=null;
      if(generation===state.authGeneration&&request!==record.request&&state.detailsId===id)loadDiscussion(id,true);
    }
  })();
  record.fetching=pending;return pending;
}

$('commentBody').addEventListener('input',()=>{
  saveCommentDraft();
  if(discussionVisibleId!==null){discussionRecord(discussionVisibleId).commentFeedback='';renderDiscussionControls(discussionVisibleId);}
});
$('commentBody').addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key==='Enter'&&!e.isComposing){e.preventDefault();$('commentForm').requestSubmit();}
});
$('commentForm').addEventListener('submit',async e=>{
  e.preventDefault();const id=discussionVisibleId;
  if(!state.user||id===null||!itemById(id))return;
  saveCommentDraft();
  const record=discussionRecord(id),draft=commentDrafts.get(id)||'',body=draft.trim(),generation=state.authGeneration;
  if(record.commentSending)return;
  if(!body){record.commentFeedback='請先輸入留言。';renderDiscussionControls(id);return;}
  if(body.length>8000){record.commentFeedback='留言最多 8,000 個字。';renderDiscussionControls(id);return;}
  record.commentSending=true;record.commentFeedback='';renderDiscussionControls(id);
  try{
    const comment=await api('/api/items/'+id+'/comments',{method:'POST',body:JSON.stringify({body})});
    if(generation!==state.authGeneration)return;
    record.request++;record.comments=record.comments.filter(old=>old.id!==comment.id).concat(comment);record.loaded=true;record.error='';
    if(commentDrafts.get(id)===draft){commentDrafts.delete(id);if(discussionVisibleId===id)$('commentBody').value='';}
    record.commentFeedback='留言已送出。';renderDiscussion(id);
  }catch(error){if(generation===state.authGeneration){record.commentFeedback=error.message;renderDiscussionControls(id);}}
  finally{record.commentSending=false;if(generation===state.authGeneration)renderDiscussionControls(id);}
});

async function deleteComment(entryId) {
  const id=discussionVisibleId;if(!state.user||id===null)return;
  const record=discussionRecord(id),entry=record.comments.find(value=>value.id===entryId),generation=state.authGeneration;
  if(!entry?.can_delete||record.deleting.has('comment:'+entryId))return;
  if(!confirm('確定刪除這則留言？刪除後無法復原。'))return;
  record.deleting.add('comment:'+entryId);renderDiscussion(id);
  try{
    await api('/api/comments/'+entryId,{method:'DELETE',body:'{}'});
    if(generation!==state.authGeneration)return;
    record.request++;record.comments=record.comments.filter(value=>value.id!==entryId);
    renderDiscussion(id);
  }catch(error){if(generation===state.authGeneration){record.commentFeedback=error.message;renderDiscussionControls(id);}}
  finally{record.deleting.delete('comment:'+entryId);if(generation===state.authGeneration)renderDiscussion(id);}
}
$('commentList').addEventListener('click',e=>{const button=e.target.closest('[data-delete-comment]');if(button)deleteComment(Number(button.dataset.deleteComment));});

async function saveWorkStatus(item,value) {
  const current=itemById(item?.id),generation=state.authGeneration;
  if(!current||!allowedStatuses(current).includes(value)||!canChangeStatus(current))throw new Error('只能調整自己負責且尚未完成的項目；完成須由管理員確認。');
  if(statusSaving.has(current.id))throw new Error('此項目正在儲存，請稍候。');
  if(current.status===value)return false;
  if(state.user?.role==='member'&&value==='pending_review'){
    const remaining=(current.subtasks||[]).filter(subtask=>!subtask.completed).length;
    if(remaining&&!confirm(`尚有 ${remaining} 個子任務未完成，確定要送交審核嗎？`))return false;
  }
  statusSaving.add(current.id);render();
  try{
    const updated=await api('/api/items/'+current.id,{method:'PATCH',body:JSON.stringify({version:current.version,status:value})});
    if(generation!==state.authGeneration)return false;
    updateLocal(updated);
    saved(value==='pending_review'?'已送交管理員審核':'狀態已更新');
    return true;
  }finally{
    if(generation===state.authGeneration){statusSaving.delete(current.id);render();}
  }
}

async function saveItemStatus(item,value,select,feedback=null) {
  const generation=state.authGeneration;
  if(feedback)feedback.textContent='正在儲存狀態…';
  try{
    const changed=await saveWorkStatus(item,value);
    if(generation!==state.authGeneration)return;
    if(!changed)select.value=itemById(item.id)?.status||item.status;
    if(feedback&&state.detailsId===item.id)feedback.textContent=changed?'狀態已儲存。':'';
  }catch(error){
    if(generation!==state.authGeneration)return;
    select.value=itemById(item.id)?.status||item.status;
    if(feedback&&state.detailsId===item.id)feedback.textContent=error.message;
    toast(error.message,true);
  }
}

$('closeDetails').addEventListener('click',()=>closeDetails());
$('editDetails').addEventListener('click',()=>{
  if(!canEditProjects())return;
  const item=itemById(state.detailsId);if(item)openItem({item});
});
$('claimDetails').addEventListener('click',()=>{const item=itemById(state.detailsId);if(item)claimItem(item,$('claimDetails'));});
$('detailsChildren').addEventListener('click',e=>{
  const button=e.target.closest('[data-detail-id]');if(!button)return;
  const item=itemById(button.dataset.detailId);if(item)openDetails(item,button);
});
$('detailsStatus').addEventListener('change',async e=>{
  const item=itemById(state.detailsId);if(item)await saveItemStatus(item,e.target.value,e.target,$('detailsFeedback'));
});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&!e.defaultPrevented&&!$('detailsPanel').hidden&&!document.querySelector('dialog[open]')){
    e.preventDefault();closeDetails();
  }
});

function updateTaskFields() {
  const level=$('itemLevel').value,isTask=level==='task',current=$('itemStatus').value,options=isTask?statuses:lifecycleStatuses;
  $('itemDueField').hidden=level==='project';$('itemPriorityField').hidden=!isTask;
  $('itemDueField').parentElement?.classList.toggle('single-column',level==='project');
  $('itemTaskFields').classList.toggle('single-column',!isTask);
  $('itemDue').disabled=level==='project';$('itemPriority').disabled=!isTask;$('itemStatus').disabled=false;
  $('itemDueHint').hidden=level!=='work';
  $('itemStatus').innerHTML=options.map(value=>`<option value="${value}">${labels[value]}</option>`).join('');
  $('itemStatus').value=options.includes(current)?current:'not_started';
}

function updateParentOptions(selected='') {
  const level=$('itemLevel').value,needsParent=level!=='project',isTask=level==='task';
  const select=$('itemParent');
  $('parentLabel').textContent=isTask?'所屬專案或內容':needsParent?'所屬專案':'上層';
  $('parentRequired').hidden=!needsParent;
  select.disabled=!needsParent;select.required=needsParent;
  const placeholder=isTask?'選擇專案或內容':needsParent?'選擇專案':'專案不需上層';
  const optionsFor=parentLevel=>state.items.filter(item=>item.level===parentLevel&&(canAddChildren(item)||item.id===state.editing?.parent_id)).map(item=>{
    const project=itemById(item.parent_id);
    const name=project?project.name+' / '+item.name:item.name;
    return `<option value="${item.id}">${esc(name)}</option>`;
  }).join('');
  let options='';
  if(isTask){
    options=['project','work'].map(parentLevel=>{
      const choices=optionsFor(parentLevel);
      return choices?`<optgroup label="${labels[parentLevel]}">${choices}</optgroup>`:'';
    }).join('');
  }else if(needsParent){
    options=optionsFor('project');
  }
  select.innerHTML=`<option value="">${placeholder}</option>`+options;
  select.value=String(selected??'');
  if(select.selectedIndex<0)select.value='';
  updateTaskFields();
}

function openItem({item=null,parent=null}={}) {
  if(!canEditProjects()||(item&&!canEditItem(item))||(parent&&!canAddChildren(parent)))return;
  state.editing=item;state.saving=false;
  $('itemForm').reset();$('formFeedback').textContent='';$('formFeedback').classList.remove('error');
  $('saveItem').disabled=false;$('saveItem').classList.remove('saving');
  $('itemDialogTitle').textContent=item?'編輯項目':'新增項目';
  $('itemDialogSubtitle').textContent=item?'修改父級會連同子項目一起移動。':'選擇層級及所屬專案或內容。';
  $('saveItem').querySelector('span').textContent=item?'儲存變更':'新增';
  $('saveItem').querySelector('svg').toggleAttribute('hidden',!!item);
  const level=item?.level||(parent||state.items.some(canAddChildren)?'task':'project');
  $('itemLevel').value=level;$('itemLevel').disabled=!!item;
  updateParentOptions(item?.parent_id??parent?.id??'');
  $('itemName').value=item?.name||'';
  $('itemDue').value=item?.due_date||'';$('itemPriority').value=item?.priority||'medium';
  $('itemStatus').value=item?.status||'not_started';$('itemNotes').value=item?.notes||'';
  for(const id of ['itemName','itemDue','itemNotes'])$(id).readOnly=false;
  for(const id of ['itemOwner','itemPriority','itemStatus'])$(id).disabled=false;
  updateTaskFields();
  prepareItemDepartment(item,parent);
  $('saveItem').hidden=false;$('cancelItem').textContent='取消';
  rememberForm('itemForm');$('itemDialog').showModal();
  $('itemName').focus();
}

$('itemLevel').addEventListener('change',()=>updateParentOptions($('itemParent').value));
$('addItem').addEventListener('click',()=>openItem());
$('cancelItem').addEventListener('click',()=>$('itemDialog').close());
$('closeItemDialog').addEventListener('click',()=>$('itemDialog').close());
$('itemDialog').addEventListener('cancel',e=>{if(state.saving)e.preventDefault();});
$('itemForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!canEditProjects()||state.saving||!$('itemForm').reportValidity())return;
  if(state.editing&&!canEditItem(itemById(state.editing.id))){$('formFeedback').textContent='目前沒有修改此項目的權限，請關閉視窗後重新確認。';return;}
  const generation=state.authGeneration;
  state.saving=true;$('saveItem').disabled=true;$('saveItem').classList.add('saving');
  $('saveItem').querySelector('span').textContent='儲存中…';$('formFeedback').textContent='正在儲存到 server…';$('formFeedback').classList.remove('error');
  $('cancelItem').disabled=true;$('closeItemDialog').disabled=true;
  const payload={level:$('itemLevel').value,parent_id:$('itemParent').value?Number($('itemParent').value):null,name:$('itemName').value,owner_id:$('itemOwner').value?Number($('itemOwner').value):null,notes:$('itemNotes').value};
  payload.status=$('itemStatus').value;payload.department_id=itemDepartmentValue();
  if(payload.level!=='project')payload.due_date=$('itemDue').value||null;
  if(payload.level==='task')payload.priority=$('itemPriority').value;
  if(state.editing)payload.version=state.editing.version;
  try {
    const result=await api(state.editing?'/api/items/'+state.editing.id:'/api/items',{method:state.editing?'PATCH':'POST',body:JSON.stringify(payload)});
    if(generation!==state.authGeneration)return;
    updateLocal(result);await loadState(true);$('itemDialog').close();saved(state.editing?'變更已儲存':'已新增「'+result.name+'」');
  } catch(error) {
    if(generation!==state.authGeneration)return;
    $('formFeedback').textContent=error.code==='CONFLICT'?'其他人已更新這筆資料，請關閉視窗後重新編輯。':error.message;
    $('formFeedback').classList.add('error');
    $('saveItem').disabled=error.code==='CONFLICT';
  } finally {
    if(generation!==state.authGeneration)return;
    state.saving=false;$('saveItem').classList.remove('saving');$('saveItem').querySelector('span').textContent=state.editing?'儲存變更':'新增';
    if(!$('formFeedback').classList.contains('error')||!$('formFeedback').textContent.includes('其他人'))$('saveItem').disabled=false;
    $('cancelItem').disabled=false;$('closeItemDialog').disabled=false;
  }
});

function branchIds(id) {
  const result=[id];for(const item of state.items)if(item.parent_id===id)result.push(...branchIds(item.id));return result;
}

function toggleBranch(id) {
  if(!state.items.some(item=>item.parent_id===id))return;
  const collapsed=currentCollapsed();
  collapsed.has(id)?collapsed.delete(id):collapsed.add(id);
  saveWorkspacePreferences();render();
}

$('itemRows').addEventListener('click',async e=>{
  const button=e.target.closest('button[data-action]');
  if(!button){
    if(e.defaultPrevented||e.target.closest('button,a,input,select,textarea,label,[contenteditable],[role="button"],[role="link"]')||window.getSelection?.()?.toString())return;
    const row=e.target.closest('tr[data-branch-id]');
    if(row)toggleBranch(Number(row.dataset.branchId));
    return;
  }
  const item=itemById(button.dataset.id);if(!item)return;
  if(button.dataset.action==='toggle'){
    toggleBranch(item.id);
  }
  if(button.dataset.action==='view')openDetails(item,button);
  if(button.dataset.action==='claim'){await claimItem(item,button);return;}
  if(!canEditProjects())return;
  if(button.dataset.action==='edit')openItem({item});
  if(button.dataset.action==='child')openItem({parent:item});
  if(button.dataset.action==='archive'||button.dataset.action==='delete'){
    if(!isAdmin())return;
    const permanent=button.dataset.action==='delete';
    if(permanent&&!isRoot())return;
    const ids=branchIds(item.id), suffix=ids.length>1?`及其${permanent?'目前顯示的':''} ${ids.length-1} 個子項目`:'';
    if(!confirm(permanent?`永久刪除「${item.name}」${suffix}？\n\n所有下層資料（包含已封存的項目）也會刪除，這項操作無法復原。`:`要封存「${item.name}」${suffix}嗎？`))return;
    button.disabled=true;
    try{
      await api('/api/items/'+item.id,{method:'DELETE',body:JSON.stringify({version:item.version,cascade:true,...(permanent?{permanent:true}:{})})});
      state.items=state.items.filter(i=>!ids.includes(i.id));await loadState(true);render();saved(permanent?'項目已永久刪除':'項目已封存');
    }catch(error){toast(error.message,true);button.disabled=false;}
  }
});

$('itemRows').addEventListener('change',async e=>{
  const inline=e.target.closest('[data-inline-field]');
  if(inline){await saveInlineField(inline);return;}
  const select=e.target.closest('select[data-status-id]');if(!select)return;
  const item=itemById(select.dataset.statusId);if(item)await saveItemStatus(item,select.value,select);
});
$('detailsPanel').addEventListener('change',async e=>{
  const inline=e.target.closest('[data-inline-field]');if(inline)await saveInlineField(inline);
});
for(const container of [$('itemRows'),$('detailsPanel')])container.addEventListener('focusout',e=>{
  if(e.target.closest('[data-inline-field], select[data-status-id], #detailsStatus'))setTimeout(()=>{if(state.user)render();},0);
});

for(const id of ['search','sortBy',...workspaceFilterIds])$(id).addEventListener(id==='search'?'input':'change',()=>{
  render();saveWorkspacePreferences();
});
$('collapseAll').addEventListener('click',()=>{
  const collapsed=currentCollapsed();
  collapsed.clear();
  for(const item of state.items)if(item.level!=='task')collapsed.add(item.id);
  saveWorkspacePreferences();render();
});
$('expandAll').addEventListener('click',()=>{currentCollapsed().clear();saveWorkspacePreferences();render();});
$('refresh').addEventListener('click',async()=>{await loadState(true);if(state.connected)toast('已同步最新資料');});
$('overview').addEventListener('click',()=>{window.scrollTo({top:0,behavior:'smooth'});});

function renderOwners(){
  $('ownersAccounts').hidden=state.user?.role!=='admin';
  const rank={admin:0,supervisor:1,member:2};
  const people=[...state.owners].sort((a,b)=>(rank[a.role]??2)-(rank[b.role]??2)||a.name.localeCompare(b.name,'zh-TW')||a.id-b.id);
  $('ownerRows').innerHTML=people.map(o=>`<div class="person-entry"><div class="account-identity"><strong>${esc(o.name)}</strong><span>${esc(o.username||'')}${o.role==='admin'?'':' · '+esc(departmentLabel(o.department_id))}</span></div><span class="role-badge ${esc(o.role)}">${roleName(o.role)}</span><span class="account-state ${o.active?'':'inactive'}">${o.active?'啟用':'停用'}</span></div>`).join('')||'<p class="muted">尚無人員。</p>';
}
$('manageOwners').addEventListener('click',()=>{renderOwners();$('ownerFeedback').textContent='';$('ownersDialog').showModal();});
$('closeOwners').addEventListener('click',()=>$('ownersDialog').close());
$('ownersAccounts').addEventListener('click',()=>{$('ownersDialog').close();$('manageAccounts').click();});

function setUser(user) {
  const accessChanged=!!state.user&&userAccessKey(state.user)!==userAccessKey(user);
  if(accessChanged){
    // Keep the authenticated session while retiring responses from the old scope.
    state.authGeneration++;closeDetails(false);resetDiscussion();resetSubtasks();statusSaving.clear();
    state.items=[];state.revision=null;state.editing=null;state.saving=false;
    workspacePreferencesLoaded=false;
    accounts=[];editingAccount=null;$('accountsRows').replaceChildren();
    if(typeof resetViews==='function')resetViews();
    for(const id of ['itemDialog','accountDialog','accountsDialog','updatesDialog','departmentsDialog'])if($(id).open)$(id).close();
    $('accountPassword').value='';$('saveItem').disabled=false;$('cancelItem').disabled=false;$('closeItemDialog').disabled=false;
    stopUpdatePolling();
  }
  state.user=user;
  $('addItem').hidden=!canEditProjects();
  $('signedInName').textContent=user.display_name;
  if($('profileDialog').open)$('profileInfo').textContent=`${user.display_name}（${user.username}） · ${roleName(user.role)}`;
  $('myAccount').title=`${user.username} · ${roleName(user.role)}`;
  $('manageAccounts').hidden=user.role!=='admin';
  $('systemUpdates').hidden=user.role!=='admin';
  if(typeof renderDepartments==='function')renderDepartments();
  if(typeof renderFeedbackAccess==='function')renderFeedbackAccess();
  if(accessChanged){render();toast('權限已更新，已同步目前可查看及修改的內容。');}
}

function showLogin(message='') {
  closeDetails(false);
  state.authGeneration++;
  statusSaving.clear();
  resetDiscussion();
  resetSubtasks();
  state.user=null;state.csrf=null;state.items=[];state.owners=[];state.departments=[];state.revision=null;state.editing=null;
  workspacePreferencesLoaded=false;
  state.lastSaved=null;accounts=[];editingAccount=null;
  for(const dialog of document.querySelectorAll('dialog[open]')) dialog.close();
  for(const id of ['itemForm','accountForm','passwordForm','profileForm','registerForm']) $(id).reset();
  $('itemRows').replaceChildren();$('ownerRows').replaceChildren();$('accountsRows').replaceChildren();
  if(typeof resetViews==='function')resetViews();
  applyWorkspacePreferences();
  $('lastSaved').textContent='資料儲存在 server';
  $('toast').hidden=true;$('workspace').hidden=true;$('authLoading').hidden=true;$('loginPanel').hidden=false;
  $('loginFeedback').textContent=message;$('loginPassword').value='';
  $('manageAccounts').hidden=true;
  $('systemUpdates').hidden=true;
  setAuthMode(false);formBaselines.clear();rememberForm('loginForm');rememberForm('registerForm');
  stopUpdatePolling();
  if(typeof renderDepartments==='function')renderDepartments();
  if(typeof renderFeedbackAccess==='function')renderFeedbackAccess();
  if(typeof loadRegistrationDepartments==='function')loadRegistrationDepartments();
}

async function enterWorkspace(session) {
  state.authGeneration++;
  workspacePreferencesLoaded=false;
  state.csrf=session.csrf_token;setUser(session.user);
  $('loginPanel').hidden=true;$('authLoading').hidden=true;$('workspace').hidden=false;
  $('loginPassword').value='';
  $('registerPassword').value='';$('registerConfirm').value='';
  await loadState(true);
}

$('loginForm').addEventListener('submit',async e=>{
  e.preventDefault();const button=$('loginSubmit');button.disabled=true;button.textContent='登入中…';$('loginFeedback').textContent='';
  try {
    const username=$('loginUsername').value.trim(),remember=$('rememberLogin').checked;
    const session=await api('/api/auth/login',{method:'POST',body:JSON.stringify({username,password:$('loginPassword').value,remember})});
    rememberAccount(username,remember);
    await enterWorkspace(session);
  }catch(error){$('loginFeedback').textContent=error.message;}
  finally{button.disabled=false;button.textContent='登入';}
});

$('myAccount').addEventListener('click',()=>{
  if(!state.user)return;
  $('profileInfo').textContent=`${state.user.display_name}（${state.user.username}） · ${roleName(state.user.role)}`;
  $('profileUsername').value=state.user.username;$('profileName').value=state.user.display_name;
  renderDepartments();
  $('profileFeedback').textContent='';$('passwordForm').reset();$('passwordFeedback').textContent='';rememberForm('profileForm');rememberForm('passwordForm');$('profileDialog').showModal();
});
$('closeProfile').addEventListener('click',()=>$('profileDialog').close());
async function logout(){
  if(state.saving){toast('請先等候儲存完成。',true);return;}
  const dirtyDialog=document.querySelector('#itemDialog[open], #accountDialog[open]');
  if(dirtyDialog&&!confirm('登出會關閉目前尚未送出的表單，確定登出嗎？'))return;
  $('logout').disabled=true;$('sidebarLogout').disabled=true;
  try{await api('/api/auth/logout',{method:'POST',body:'{}'});showLogin('已登出。');}
  catch(error){if(state.user)toast(error.message,true);}
  finally{$('logout').disabled=false;$('sidebarLogout').disabled=false;}
}
$('logout').addEventListener('click',logout);
$('sidebarLogout').addEventListener('click',logout);
$('profileForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!$('profileForm').reportValidity())return;
  const generation=state.authGeneration;
  $('saveProfile').disabled=true;$('profileFeedback').textContent='';
  try{
    const result=await api('/api/auth/profile',{method:'PATCH',body:JSON.stringify({display_name:$('profileName').value.trim()})});
    if(generation!==state.authGeneration)return;
    setUser(result.user||result);$('profileInfo').textContent=`${state.user.display_name}（${state.user.username}） · ${roleName(state.user.role)}`;
    await loadState(true);rememberForm('profileForm');$('profileFeedback').textContent='個人資料已儲存。';saved('個人資料已更新');
  }catch(error){if(generation===state.authGeneration)$('profileFeedback').textContent=error.message;}
  finally{$('saveProfile').disabled=false;}
});
$('passwordForm').addEventListener('submit',async e=>{
  e.preventDefault();$('passwordFeedback').textContent='';
  if($('newPassword').value!==$('confirmPassword').value){$('passwordFeedback').textContent='兩次輸入的新密碼不一致。';return;}
  $('savePassword').disabled=true;
  try{
    await api('/api/auth/password',{method:'POST',body:JSON.stringify({current_password:$('currentPassword').value,password:$('newPassword').value})});
    showLogin('密碼已更新，請使用新密碼登入。');
  }catch(error){$('passwordFeedback').textContent=error.message;}
  finally{$('savePassword').disabled=false;}
});

let accounts=[], editingAccount=null;
let accountsRequest=null,accountsReloadQueued=false;
function loadAccounts(force=true){
  if(!isAdmin())return Promise.resolve();
  if(accountsRequest){if(force)accountsReloadQueued=true;return accountsRequest;}
  const generation=state.authGeneration;
  accountsRequest=(async()=>{
    do{
      accountsReloadQueued=false;
      const result=await api('/api/users');if(generation!==state.authGeneration||!isAdmin())return;
      accounts=result.users;renderAccounts();
    }while(accountsReloadQueued);
  })().finally(()=>{accountsRequest=null;});
  return accountsRequest;
}

function filteredAccounts(){
  const query=$('accountsSearch').value.trim().toLocaleLowerCase(),role=$('accountsRoleFilter').value,department=$('accountsDepartmentFilter').value,active=$('accountsActiveFilter').value,sort=$('accountsSort').value;
  const rank={admin:0,supervisor:1,member:2};
  const byName=(a,b)=>a.display_name.localeCompare(b.display_name,'zh-TW')||a.username.localeCompare(b.username,'zh-TW')||a.id-b.id;
  return accounts.filter(user=>(!query||`${user.display_name} ${user.username}`.toLocaleLowerCase().includes(query))&&(!role||user.role===role)&&(!department||String(user.department_id)===department)&&(!active||!!user.active===(active==='active'))).sort((a,b)=>{
    if(sort==='name')return byName(a,b);
    if(sort==='username')return a.username.localeCompare(b.username,'zh-TW')||byName(a,b);
    if(sort==='department')return departmentLabel(a.department_id).localeCompare(departmentLabel(b.department_id),'zh-TW')||byName(a,b);
    if(sort==='newest')return b.created_at-a.created_at||b.id-a.id;
    if(sort==='oldest')return a.created_at-b.created_at||a.id-b.id;
    return (rank[a.role]??2)-(rank[b.role]??2)||byName(a,b);
  });
}

function renderAccounts(){
  if(!isAdmin()){$('accountsRows').replaceChildren();return;}
  const visible=filteredAccounts();
  $('accountsCount').textContent=visible.length===accounts.length?`${accounts.length} 個帳號`:`顯示 ${visible.length} / ${accounts.length} 個帳號`;
  $('accountsRows').innerHTML=visible.map(u=>`<div class="account-entry"><div class="account-identity"><strong>${esc(u.display_name)}</strong><span>${esc(u.username)}${u.id===state.user?.id?' · 你':''}${u.role==='admin'?'':' · '+esc(departmentLabel(u.department_id))}</span></div><span class="role-badge ${u.role}">${roleName(u.role)}</span><span class="account-state ${u.active?'':'inactive'}">${u.active?'啟用':'停用'}</span><div class="account-actions">${u.username.toLowerCase()==='root'&&!isRoot()?'<span class="field-hint">受保護</span>':`<button class="secondary" data-edit-account="${u.id}" aria-label="編輯帳號${esc(u.username)}">編輯</button>`}${isRoot()&&u.username.toLowerCase()!=='root'&&u.id!==state.user?.id?`<button class="icon-button danger-icon" data-delete-account="${u.id}" title="永久刪除帳號" aria-label="永久刪除帳號${esc(u.username)}">${icon('trash')}</button>`:''}</div></div>`).join('')||'<p class="muted">沒有符合條件的帳號，請調整搜尋或篩選。</p>';
}
for(const id of accountPreferenceIds)$(id).addEventListener(id==='accountsSearch'?'input':'change',()=>{
  renderAccounts();saveWorkspacePreferences();
});
$('manageAccounts').addEventListener('click',async()=>{
  if(!isAdmin())return;
  $('accountsFeedback').textContent='';$('accountsRows').textContent='正在載入帳號…';$('accountsDialog').showModal();
  try{await loadAccounts();}catch(error){$('accountsFeedback').textContent=error.message;}
});
$('closeAccounts').addEventListener('click',()=>$('accountsDialog').close());
function openAccount(user=null) {
  editingAccount=user;$('accountForm').reset();$('accountFeedback').textContent='';
  $('accountTitle').textContent=user?'編輯帳號':'新增帳號';
  $('accountSubtitle').textContent=user?'部門及權限變更會即時生效並保留登入；停用或重設密碼會使既有登入失效。':'建立可登入這個工作空間的帳號。';
  $('accountUsername').value=user?.username||'';$('accountUsername').disabled=!!user;
  $('accountDisplayName').value=user?.display_name||'';
  $('accountRole').value=user?.role||'member';$('accountActive').checked=user?!!user.active:true;
  prepareAccountDepartments(user);
  const self=user?.id===state.user?.id;
  $('accountRole').disabled=self;$('accountActive').disabled=self;
  $('accountPassword').value='';$('accountPassword').required=!user;
  $('accountPasswordLabel').textContent=user?'重設密碼（選填）':'登入密碼 *';
  $('accountPasswordHint').textContent=user?'留空保留原密碼；填入至少 4 個字的新密碼。':'密碼至少 4 個字。';
  $('saveAccount').textContent=user?'儲存變更':'建立帳號';$('saveAccount').disabled=false;
  rememberForm('accountForm');$('accountDialog').showModal();$('accountDisplayName').focus();
}
$('addAccount').addEventListener('click',()=>openAccount());
$('accountsRows').addEventListener('click',async e=>{
  const edit=e.target.closest('[data-edit-account]');if(edit){openAccount(accounts.find(u=>u.id===Number(edit.dataset.editAccount)));return;}
  const button=e.target.closest('[data-delete-account]');if(!button||!isRoot())return;
  const user=accounts.find(u=>u.id===Number(button.dataset.deleteAccount));if(!user)return;
  if(!confirm(`永久刪除帳號「${user.display_name}（${user.username}）」？\n\n此人的項目會保留並改為未指派，登入狀態會失效。帳號刪除後無法復原。`))return;
  button.disabled=true;
  try{await api('/api/users/'+user.id,{method:'DELETE',body:JSON.stringify({version:user.version})});await loadAccounts();await loadState(true);saved('帳號已永久刪除');}
  catch(error){$('accountsFeedback').textContent=error.message;button.disabled=false;}
});
for(const id of ['closeAccountEditor','cancelAccount'])$(id).addEventListener('click',()=>$('accountDialog').close());
$('accountForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!$('accountForm').reportValidity())return;
  const generation=state.authGeneration;
  $('saveAccount').disabled=true;$('accountFeedback').textContent='';
  const payload={display_name:$('accountDisplayName').value.trim(),role:$('accountRole').value,active:$('accountActive').checked,...accountDepartmentPayload()};
  if(editingAccount)payload.version=editingAccount.version;else payload.username=$('accountUsername').value.trim();
  if($('accountPassword').value)payload.password=$('accountPassword').value;
  try{
    const result=await api(editingAccount?'/api/users/'+editingAccount.id:'/api/users',{method:editingAccount?'PATCH':'POST',body:JSON.stringify(payload)});
    if(generation!==state.authGeneration)return;
    const self=result.id===state.user?.id;
    $('accountDialog').close();$('accountPassword').value='';
    if(self&&payload.password){showLogin('密碼已重設，請重新登入。');return;}
    if(self)setUser(result);
    await loadAccounts();await loadState(true);saved(editingAccount?'帳號已更新':'帳號已建立');
  }catch(error){if(generation===state.authGeneration)$('accountFeedback').textContent=error.message;}
  finally{$('saveAccount').disabled=false;}
});

let registerMode=false;
function setAuthMode(register) {
  registerMode=register;
  $('loginForm').hidden=register;$('registerForm').hidden=!register;
  $('authTitle').textContent=register?'註冊帳號':'登入專案管理';
  $('authDescription').textContent=register?'用一個帳號管理工作，也讓團隊找得到你。':'讓每一件工作，都有清楚的下一步。';
  $('authSwitchLabel').textContent=register?'已經有帳號？':'第一次使用？';
  $('switchAuth').textContent=register?'返回登入':'註冊帳號';
  $('switchAuth').setAttribute('aria-expanded',String(register));
  if(!register){$('registerPassword').value='';$('registerConfirm').value='';}
}
function rememberAccount(username,remember) {
  try{localStorage.setItem('pm-login',JSON.stringify({username:remember?username:'',remember}));}catch{}
}
$('switchAuth').addEventListener('click',()=>{
  setAuthMode(!registerMode);$('loginFeedback').textContent='';$('registerFeedback').textContent='';
  $(registerMode?'registerUsername':'loginUsername').focus();
});
$('registerForm').addEventListener('submit',async e=>{
  e.preventDefault();if(!$('registerForm').reportValidity())return;
  $('registerFeedback').textContent='';
  if($('registerPassword').value!==$('registerConfirm').value){$('registerFeedback').textContent='兩次輸入的密碼不一致。';return;}
  $('registerSubmit').disabled=true;$('registerSubmit').textContent='正在註冊…';
  try{
    const username=$('registerUsername').value.trim();
    const session=await api('/api/auth/register',{method:'POST',body:JSON.stringify({username,display_name:$('registerName').value.trim(),password:$('registerPassword').value,remember:true,department_id:registrationDepartmentValue()})});
    $('loginUsername').value=username;$('rememberLogin').checked=true;rememberAccount(username,true);
    await enterWorkspace(session);toast('帳號已建立，歡迎加入工作空間');
  }catch(error){$('registerFeedback').textContent=error.message;}
  finally{$('registerSubmit').disabled=false;$('registerSubmit').textContent='註冊並登入';}
});

let updateTimer=null,updateInFlight=false,updateInstalling=false,updateInfo=null,updateRequestRunning=false;
const updateBusyPhases=new Set(['queued','checking','downloading','testing','installing','starting']);
function stopUpdatePolling(){clearTimeout(updateTimer);updateTimer=null;updateInstalling=false;updateInfo=null;}
function renderUpdateStatus(info){
  updateInfo=info;
  const busy=updateBusyPhases.has(info.phase)||updateRequestRunning;
  $('currentVersion').textContent=info.version||info.current?.slice(0,12)||'開發版本';
  $('latestVersion').textContent=info.latest?.version||(info.phase==='idle'?'已是最新版本':'—');
  $('updateMessage').textContent=info.message||'尚未檢查更新。';
  $('updateMessage').classList.toggle('is-busy',busy);
  $('updateMessage').classList.toggle('is-error',info.phase==='error'||info.phase==='unavailable');
  $('updateNotesSection').hidden=!info.latest?.notes;
  $('updateNotes').textContent=info.latest?.notes||'';
  $('checkUpdates').disabled=!info.supported||busy;
  $('installUpdate').disabled=!info.supported||!info.available||!info.latest||busy;
  $('installUpdate').textContent=['downloading','testing','installing'].includes(info.phase)?'更新中…':'立即更新';
  $('reloadUpdated').hidden=info.phase!=='complete';
  if(['downloading','testing','installing'].includes(info.phase))updateInstalling=true;
  if(info.phase==='complete'||info.phase==='error')updateInstalling=false;
}
async function pollUpdateStatus(){
  if(updateInFlight||state.user?.role!=='admin')return;
  updateInFlight=true;
  try{
    const info=await api('/api/system/update');
    if(state.user?.role==='admin')renderUpdateStatus(info);
  }catch(error){
    if(state.user){
      $('updateMessage').textContent=updateInstalling?'伺服器正在切換版本，等待重新連線…':error.message;
      $('checkUpdates').disabled=true;$('installUpdate').disabled=true;
    }
  }finally{
    updateInFlight=false;clearTimeout(updateTimer);
    if(state.user?.role==='admin'&&($('updatesDialog').open||updateInstalling))updateTimer=setTimeout(pollUpdateStatus,1000);
  }
}
$('systemUpdates').addEventListener('click',()=>{
  if(state.user?.role!=='admin')return;
  if(document.querySelector('#itemDialog[open],#accountDialog[open],#profileDialog[open]')){toast('請先儲存或關閉正在填寫的表單。',true);return;}
  $('updateMessage').textContent='正在讀取更新狀態…';$('checkUpdates').disabled=true;$('installUpdate').disabled=true;
  $('updatesDialog').showModal();pollUpdateStatus();
});
$('closeUpdates').addEventListener('click',()=>$('updatesDialog').close());
$('updatesDialog').addEventListener('close',()=>{if(!updateInstalling){clearTimeout(updateTimer);updateTimer=null;}});
$('checkUpdates').addEventListener('click',async()=>{
  updateRequestRunning=true;if(updateInfo)renderUpdateStatus(updateInfo);
  try{await api('/api/system/update/check',{method:'POST',body:'{}'});$('updateMessage').textContent='已收到要求，正在檢查更新…';}
  catch(error){$('updateMessage').textContent=error.message;}
  finally{updateRequestRunning=false;await pollUpdateStatus();}
});
$('installUpdate').addEventListener('click',async()=>{
  const latest=updateInfo?.latest;if(!latest||$('installUpdate').disabled)return;
  if(state.saving||document.querySelector('#itemDialog[open],#accountDialog[open],#profileDialog[open]')){toast('請先儲存或關閉正在填寫的表單，再安裝更新。',true);return;}
  if(!confirm(`安裝版本 ${latest.version}？\n\n系統會先備份資料庫，更新期間所有人的連線會短暫中斷。請確認團隊已儲存手邊的資料。`))return;
  updateRequestRunning=true;renderUpdateStatus(updateInfo);
  try{await api('/api/system/update/install',{method:'POST',body:JSON.stringify({release:latest.release})});updateInstalling=true;$('updateMessage').textContent='已收到更新要求，正在準備…';}
  catch(error){$('updateMessage').textContent=error.message;}
  finally{updateRequestRunning=false;await pollUpdateStatus();}
});
$('reloadUpdated').addEventListener('click',()=>{if(typeof checkLiveVersion==='function')checkLiveVersion();else if(hasUnsavedChanges())toast('請先儲存或取消尚未送出的內容。',true);else{prepareLiveReload();location.reload();}});
try{
  const remembered=JSON.parse(localStorage.getItem('pm-login')||'null');
  if(remembered){$('loginUsername').value=remembered.username||'';$('rememberLogin').checked=remembered.remember!==false;}
}catch{}

async function bootstrap() {
  const generation=state.authGeneration;
  try{const session=await api('/api/auth/me');if(session.user)await enterWorkspace(session);else showLogin();}
  catch(error){if(generation===state.authGeneration)showLogin(error.message);}
}
$('serverAddress').textContent=location.host;
window.addEventListener('resize',updateDetailsPosition);
if(typeof ResizeObserver!=='undefined'){
  const detailsObserver=new ResizeObserver(updateDetailsPosition);
  for(const selector of ['.main','.filter-row','.details-panel']){
    const surface=document.querySelector(selector);if(surface)detailsObserver.observe(surface);
  }
}
bootstrap();
async function synchronizeData(){
  if(!state.user||document.hidden)return;
  await loadState();
  if(!state.user||document.hidden)return;
  if($('accountsDialog').open&&isAdmin())loadAccounts(false).catch(error=>{if(isAdmin())$('accountsFeedback').textContent=error.message;});
  if(state.detailsId!==null)loadDiscussion(state.detailsId);
  if($('feedbackDialog').open&&typeof loadFeedbackHistory==='function')loadFeedbackHistory();
}
setInterval(synchronizeData,2000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)synchronizeData();});
window.addEventListener('focus',synchronizeData);
window.addEventListener('online',synchronizeData);
