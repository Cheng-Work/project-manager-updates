'use strict';

const mainFilterDefinitions=[
  {id:'departmentFilter',label:'部門',all:'全部部門'},
  {id:'projectFilter',label:'專案',all:'全部專案'},
  {id:'contentFilter',label:'內容',all:'全部內容'},
  {id:'lifecycleFilter',label:'專案／內容狀態',all:'專案／內容狀態',hint:'也會顯示符合狀態項目下的任務'},
  {id:'statusFilter',label:'任務狀態',all:'任務狀態',hint:'只篩選任務，保留所屬專案與內容'},
  {id:'ownerFilter',label:'負責人',all:'全部負責人'}
];
const mainFilterMenus=new Map();

function filterElement(tag,className,text=''){
  const node=document.createElement(tag);if(className)node.className=className;if(text)node.textContent=text;return node;
}

function createFilterMenu(definition){
  const select=document.getElementById(definition.id);if(!select)return null;
  select.multiple=true;select.hidden=true;
  const wrapper=filterElement('details','filter-field'),summary=filterElement('summary','filter-summary'),text=filterElement('span','filter-summary-text'),count=filterElement('span','filter-summary-count');
  wrapper.id='filter-field-'+definition.id;wrapper.dataset.filterId=definition.id;summary.id='filter-summary-'+definition.id;
  const menu=filterElement('div','filter-menu'),actions=filterElement('div','filter-menu-actions'),all=filterElement('button','filter-menu-action','全部'),clear=filterElement('button','filter-menu-action','清除'),options=filterElement('div','filter-menu-options');
  menu.id='filter-menu-'+definition.id;menu.setAttribute('role','group');menu.setAttribute('aria-label',definition.label);summary.setAttribute('aria-controls',menu.id);
  all.type='button';clear.type='button';all.dataset.filterAction='all';clear.dataset.filterAction='clear';
  summary.append(text,count);actions.append(all,clear);menu.append(actions);
  if(definition.hint)menu.append(filterElement('p','filter-menu-hint',definition.hint));
  menu.append(options);select.parentElement.insertBefore(wrapper,select);wrapper.append(summary,menu,select);
  const record={definition,select,wrapper,summary,text,count,menu,options,rows:new Map(),structureKey:null};mainFilterMenus.set(definition.id,record);
  const changed=()=>{select.dispatchEvent(new Event('change',{bubbles:true}));renderFilterMenu(record);};
  all.addEventListener('click',()=>{for(const option of select.options)option.selected=!!option.value&&!option.disabled;changed();});
  clear.addEventListener('click',()=>{for(const option of select.options)option.selected=false;changed();});
  options.addEventListener('change',event=>{
    const input=event.target.closest('input[data-filter-option]');if(!input)return;
    const option=[...select.options].find(value=>value.value===input.dataset.filterOption);
    if(!option||option.disabled||select.disabled){input.checked=!!option?.selected;return;}
    option.selected=input.checked;changed();
  });
  select.addEventListener('change',()=>renderFilterMenu(record));
  wrapper.addEventListener('toggle',()=>{
    summary.setAttribute('aria-expanded',String(wrapper.open));
    if(wrapper.open){
      if(wrapper.hidden||select.disabled){wrapper.open=false;return;}
      for(const other of mainFilterMenus.values())if(other.wrapper!==record.wrapper)other.wrapper.open=false;
      positionFilterMenu(record);
    }
  });
  return record;
}

function renderFilterMenu(record){
  const {definition,select,wrapper,summary,text,count,options,rows}=record;
  select.multiple=true;select.hidden=true;
  wrapper.hidden=record.composite?['lifecycleFilter','statusFilter'].every(id=>mainFilterMenus.get(id).select.dataset.filterVisible==='false'):select.dataset.filterVisible==='false';
  if(wrapper.hidden||select.disabled)wrapper.open=false;
  const disabled=String(!!select.disabled);if(summary.getAttribute('aria-disabled')!==disabled)summary.setAttribute('aria-disabled',disabled);summary.tabIndex=select.disabled?-1:0;
  const values=[...select.options].filter(option=>option.value!==''),selected=values.filter(option=>option.selected);
  const labels=selected.map(option=>option.label||option.textContent);
  const selection=labels.length<=2?labels.join('、'):labels[0]+'、'+labels[1]+' +'+(labels.length-2);
  const combined=record.composite?['lifecycleFilter','statusFilter'].flatMap(id=>[...mainFilterMenus.get(id).select.options].filter(option=>option.value&&option.selected).map(option=>option.label||option.textContent)):null;
  const combinedText=combined?.slice(0,2).join('、')+(combined?.length>2?' +'+(combined.length-2):'');
  const caption=combined?combined.length?'狀態：'+combinedText:'全部狀態':selected.length?definition.label+'：'+selection:definition.all;
  if(text.textContent!==caption)text.textContent=caption;
  const title=combined?['lifecycleFilter','statusFilter'].map(id=>{const part=mainFilterMenus.get(id),names=[...part.select.selectedOptions].map(option=>option.label||option.textContent);return part.definition.label+'：'+(names.join('、')||'全部');}).join('；'):selected.length?definition.label+'：'+labels.join('、'):definition.all+'（不限制）';if(summary.title!==title)summary.title=title;
  const selectedCount=combined?combined.length:selected.length;
  count.hidden=!selectedCount;if(count.textContent!==String(selectedCount))count.textContent=String(selectedCount);wrapper.classList.toggle('has-selection',!!selectedCount);
  const structureKey=JSON.stringify(values.map(option=>[option.value,option.label||option.textContent,!!option.disabled,option.dataset?.pinned]));
  if(structureKey!==record.structureKey){
    const keep=new Set(values.map(option=>option.value));
    for(const [value,row] of rows)if(!keep.has(value)){
      const focused=row.label.contains(document.activeElement);row.label.remove();rows.delete(value);if(focused)summary.focus({preventScroll:true});
    }
    values.forEach((option,index)=>{
      let row=rows.get(option.value);
      if(!row){
        const label=filterElement('label','filter-option'),input=filterElement('input',''),name=filterElement('span','filter-option-name');
        input.type='checkbox';input.dataset.filterOption=option.value;label.append(input,name);row={label,input,name};rows.set(option.value,row);
      }
      const name=option.label||option.textContent;if(row.name.textContent!==name)row.name.textContent=name;
      row.label.classList.toggle('is-disabled',!!option.disabled);
      row.label.classList.toggle('is-pinned',option.dataset?.pinned==='true');
      if(options.children[index]!==row.label)options.insertBefore(row.label,options.children[index]||null);
    });
    const empty=options.querySelector('.filter-options-empty');
    if(!values.length&&!empty)options.append(filterElement('p','filter-options-empty','目前沒有可選項目'));
    if(values.length&&empty)empty.remove();
    record.structureKey=structureKey;
  }
  for(const option of values){const row=rows.get(option.value);row.input.checked=!!option.selected;row.input.disabled=!!option.disabled||!!select.disabled;}
  if(wrapper.open)positionFilterMenu(record);
}

function renderFilterMenus(){
  for(const definition of mainFilterDefinitions){const record=mainFilterMenus.get(definition.id)||createFilterMenu(definition);if(record)renderFilterMenu(record);}
  mergeStatusFilterMenus();
}

function mergeStatusFilterMenus(){
  const left=mainFilterMenus.get('lifecycleFilter'),right=mainFilterMenus.get('statusFilter');
  if(!left||!right||left.composite)return;
  const columns=filterElement('div','filter-status-columns');
  for(const record of [left,right]){
    const column=filterElement('section','filter-status-column');column.append(filterElement('h3','filter-status-heading',record.definition.label));
    while(record.menu.firstChild)column.append(record.menu.firstChild);
    columns.append(column);record.composite=true;
  }
  left.menu.append(columns);left.menu.classList.add('filter-status-menu');left.menu.setAttribute('aria-label','專案／內容與任務狀態');
  left.wrapper.classList.add('filter-status-field');left.wrapper.dataset.filterId='statusFilters';
  left.wrapper.append(right.select);right.wrapper.remove();
  for(const key of ['wrapper','summary','text','count','menu'])right[key]=left[key];
  renderFilterMenu(left);renderFilterMenu(right);
}

function positionFilterMenu(record){
  if(!record.wrapper.open||record.wrapper.hidden)return;
  const rect=record.summary.getBoundingClientRect(),width=Math.min(record.composite?560:320,Math.max(record.composite?560:240,rect.width),window.innerWidth-16),below=window.innerHeight-rect.bottom-14,above=rect.top-14;
  const room=below<160&&above>below?above:below,height=Math.max(100,Math.min(360,room));
  const top=below<160&&above>below?Math.max(8,rect.top-height-6):rect.bottom+6,left=Math.max(8,Math.min(rect.left,window.innerWidth-width-8));
  for(const [key,value] of Object.entries({width:width+'px',left:left+'px',top:top+'px',maxHeight:height+'px'}))if(record.menu.style[key]!==value)record.menu.style[key]=value;
}

function repositionFilterMenus(){for(const record of mainFilterMenus.values())if(record.wrapper.open)positionFilterMenu(record);}
document.addEventListener('pointerdown',event=>{for(const record of mainFilterMenus.values())if(record.wrapper.open&&!record.wrapper.contains(event.target))record.wrapper.open=false;},true);
document.addEventListener('keydown',event=>{
  if(event.key!=='Escape')return;
  const opened=[...mainFilterMenus.values()].find(record=>record.wrapper.open);if(!opened)return;
  event.preventDefault();event.stopPropagation();opened.wrapper.open=false;opened.summary.focus({preventScroll:true});
},true);
window.addEventListener('resize',repositionFilterMenus);
document.addEventListener('scroll',repositionFilterMenus,true);
renderFilterMenus();
if(typeof ResizeObserver!=='undefined'){
  const filterSurface=document.querySelector('.filter-row');if(filterSurface)new ResizeObserver(repositionFilterMenus).observe(filterSurface);
}
